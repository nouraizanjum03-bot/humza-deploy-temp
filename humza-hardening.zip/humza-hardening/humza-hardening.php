<?php
/**
 * Plugin Name:       Humza Hardening
 * Plugin URI:        https://humzamultiservizi.it
 * Description:       Hardening di sicurezza per humzamultiservizi.it: REST utenti nascosta, anti author-enumeration, XML-RPC off, errori di login generici, security header. Mu-plugin: resta attivo anche se si cambia tema.
 * Version:           2.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            Humza Multiservizi
 * Text Domain:       humza-hardening
 *
 * NOTA: questo file va caricato in wp-content/mu-plugins/ (creare la
 * cartella se non esiste). I mu-plugin si caricano PRIMA del tema:
 * la costante HUMZA_HARDENING_LOADED segnala al tema (inc/security.php)
 * che l'hardening è già registrato, evitando hook duplicati.
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'HUMZA_HARDENING_LOADED' ) ) {
	return; // Già caricato altrove: non registrare due volte.
}

define( 'HUMZA_HARDENING_LOADED', true );

/* -------------------------------------------------------------------------
 * 1) REST API: nasconde l'elenco utenti ai visitatori non loggati.
 *    Si rimuovono SOLO gli endpoint /wp/v2/users (niente
 *    rest_authentication_errors: bloccherebbe anche plugin legittimi
 *    che usano la REST API in frontend, come il booking).
 * ---------------------------------------------------------------------- */
if ( ! function_exists( 'humza_rest_hide_users' ) ) {
	/**
	 * Rimuove gli endpoint utenti dalla REST API per i non autenticati.
	 *
	 * @param array $endpoints Endpoint REST registrati.
	 * @return array Endpoint filtrati.
	 */
	function humza_rest_hide_users( $endpoints ) {
		if ( is_user_logged_in() ) {
			return $endpoints;
		}
		unset(
			$endpoints['/wp/v2/users'],
			$endpoints['/wp/v2/users/(?P<id>[\d]+)']
		);
		return $endpoints;
	}
}
add_filter( 'rest_endpoints', 'humza_rest_hide_users' );

/* -------------------------------------------------------------------------
 * 2) Author enumeration: blocca ?author=N il prima possibile e
 *    reindirizza gli archivi autore alla home (301).
 * ---------------------------------------------------------------------- */
if ( ! function_exists( 'humza_block_author_query_string' ) ) {
	/**
	 * Blocca i tentativi di enumerazione via ?author=N prima del routing.
	 */
	function humza_block_author_query_string() {
		if ( is_admin() ) {
			return;
		}
		// Mai sulle richieste REST: qui "?author=N" è un filtro legittimo
		// (es. /wp-json/wp/v2/posts?author=1, block editor, plugin booking);
		// un redirect 301 HTML romperebbe i client JSON. L'enumerazione via
		// REST è già coperta dal filtro rest_endpoints (punto 1).
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( isset( $_GET['rest_route'] ) || false !== strpos( $request_uri, '/' . rest_get_url_prefix() . '/' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$author = isset( $_GET['author'] ) ? sanitize_text_field( wp_unslash( $_GET['author'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( '' !== $author ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}
}
add_action( 'parse_request', 'humza_block_author_query_string', 0 );

if ( ! function_exists( 'humza_block_author_archives' ) ) {
	/**
	 * Reindirizza gli archivi autore (e ogni query con author valorizzato)
	 * alla home page con 301.
	 */
	function humza_block_author_archives() {
		$author_var = get_query_var( 'author' );
		if ( is_author() || ( '' !== $author_var && null !== $author_var ) ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}
}
add_action( 'template_redirect', 'humza_block_author_archives', 0 );

/* -------------------------------------------------------------------------
 * 3) XML-RPC: disattivato (nessuna app remota lo usa) + header
 *    X-Pingback rimosso dalle risposte. Il blocco a livello server
 *    è in .htaccess (vedi htaccess-additions.txt): doppia difesa.
 * ---------------------------------------------------------------------- */
add_filter( 'xmlrpc_enabled', '__return_false' );

if ( ! function_exists( 'humza_remove_pingback_header' ) ) {
	/**
	 * Rimuove l'header X-Pingback dalle risposte HTTP.
	 *
	 * @param array $headers Header in uscita.
	 * @return array Header filtrati.
	 */
	function humza_remove_pingback_header( $headers ) {
		unset( $headers['X-Pingback'] );
		return $headers;
	}
}
add_filter( 'wp_headers', 'humza_remove_pingback_header' );

/* -------------------------------------------------------------------------
 * 4) Login: messaggio d'errore generico (non rivela se esiste l'utente)
 *    + oEmbed senza dati autore (niente user discovery indiretta).
 * ---------------------------------------------------------------------- */
if ( ! function_exists( 'humza_generic_login_error' ) ) {
	/**
	 * Sostituisce ogni errore di login con un messaggio generico.
	 *
	 * @param string $error Messaggio d'errore originale.
	 * @return string Messaggio generico.
	 */
	function humza_generic_login_error( $error ) {
		if ( '' === trim( (string) $error ) ) {
			return $error;
		}
		return esc_html__( 'Credenziali non valide.', 'humza-hardening' );
	}
}
add_filter( 'login_errors', 'humza_generic_login_error' );

if ( ! function_exists( 'humza_oembed_strip_author' ) ) {
	/**
	 * Rimuove nome e URL autore dalle risposte oEmbed.
	 *
	 * @param array $data Dati della risposta oEmbed.
	 * @return array Dati filtrati.
	 */
	function humza_oembed_strip_author( $data ) {
		if ( is_array( $data ) ) {
			unset( $data['author_url'], $data['author_name'] );
		}
		return $data;
	}
}
add_filter( 'oembed_response_data', 'humza_oembed_strip_author' );

/* -------------------------------------------------------------------------
 * 5) Security header sul frontend (non admin). HSTS NON va impostato
 *    qui: si attiva, consapevolmente, in .htaccess (vedi
 *    htaccess-additions.txt, blocco commentato con avvertenza).
 * ---------------------------------------------------------------------- */
if ( ! function_exists( 'humza_security_headers' ) ) {
	/**
	 * Invia gli header di sicurezza sulle risposte frontend.
	 */
	function humza_security_headers() {
		if ( is_admin() || headers_sent() ) {
			return;
		}
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
	}
}
add_action( 'send_headers', 'humza_security_headers' );

/* -------------------------------------------------------------------------
 * 6) Nasconde la versione di WordPress (meta generator + feed).
 * ---------------------------------------------------------------------- */
remove_action( 'wp_head', 'wp_generator' );
add_filter( 'the_generator', '__return_empty_string' );

/* -------------------------------------------------------------------------
 * 7) Pingback disattivati (spam vector); i commenti normali restano
 *    gestibili come sempre da wp-admin.
 * ---------------------------------------------------------------------- */
add_filter( 'pings_open', '__return_false', 20 );
