<?php
/**
 * Archivio "Novità": griglia di post con paginazione e stato vuoto gentile
 * (che offre comunque una via d'uscita utile: servizi, contatti, WhatsApp).
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();

$humza_posts_page_id = (int) get_option( 'page_for_posts' );
$humza_blog_title    = $humza_posts_page_id ? get_the_title( $humza_posts_page_id ) : __( 'Novità', 'hamza-theme' );
?>

<main id="main">

	<section class="page-hero">
		<div class="container">
			<?php if ( function_exists( 'humza_breadcrumb' ) ) : ?>
				<?php humza_breadcrumb(); ?>
			<?php else : ?>
				<nav class="breadcrumb" aria-label="<?php esc_attr_e( 'Percorso di navigazione', 'hamza-theme' ); ?>">
					<ol>
						<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'hamza-theme' ); ?></a></li>
						<li aria-current="page"><?php echo esc_html( $humza_blog_title ); ?></li>
					</ol>
				</nav>
			<?php endif; ?>
			<h1><?php echo esc_html( $humza_blog_title ); ?></h1>
			<p class="page-hero__sub"><?php esc_html_e( 'Scadenze fiscali, avvisi e aggiornamenti utili dai nostri uffici di Brescia.', 'hamza-theme' ); ?></p>
		</div>
	</section>

	<section class="section" aria-labelledby="novita-list-title">
		<div class="container">

			<?php if ( have_posts() ) : ?>

				<h2 id="novita-list-title" class="screen-reader-text"><?php esc_html_e( 'Elenco degli articoli', 'hamza-theme' ); ?></h2>

				<div class="grid grid--2 grid--3">
					<?php while ( have_posts() ) : the_post(); ?>
						<article class="card post-card">
							<?php if ( has_post_thumbnail() ) : ?>
								<figure class="post-card__thumb">
									<?php the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) ); ?>
								</figure>
							<?php endif; ?>
							<div class="post-card__body">
								<p class="post-card__meta">
									<?php $humza_cat = get_the_category(); ?>
									<?php if ( $humza_cat ) : ?>
										<span class="cat"><?php echo esc_html( $humza_cat[0]->name ); ?></span>
									<?php endif; ?>
									<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
								</p>
								<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<p><?php echo esc_html( get_the_excerpt() ); ?></p>
								<span class="card__more" aria-hidden="true"><?php esc_html_e( 'Leggi', 'hamza-theme' ); ?></span>
							</div>
						</article>
					<?php endwhile; ?>
				</div>

				<?php
				the_posts_pagination( array(
					'mid_size'           => 1,
					'prev_text'          => esc_html__( '« Più recenti', 'hamza-theme' ),
					'next_text'          => esc_html__( 'Meno recenti »', 'hamza-theme' ),
					'screen_reader_text' => esc_html__( 'Navigazione articoli', 'hamza-theme' ),
					'aria_label'         => esc_html__( 'Navigazione articoli', 'hamza-theme' ),
					'class'              => 'pagination',
				) );
				?>

			<?php else : ?>

				<div class="aside-box empty-state">
					<h2 id="novita-list-title"><?php esc_html_e( 'Nessuna novità al momento', 'hamza-theme' ); ?></h2>
					<p><?php esc_html_e( 'Qui pubblichiamo scadenze, avvisi e aggiornamenti utili. Torna a trovarci presto: intanto puoi guardare i servizi o farci una domanda su WhatsApp.', 'hamza-theme' ); ?></p>
					<div class="btn-row">
						<a class="btn btn--navy" href="<?php echo esc_url( home_url( '/servizi/' ) ); ?>"><?php esc_html_e( 'Vedi i servizi', 'hamza-theme' ); ?></a>
						<a class="btn btn--wa" href="<?php echo esc_url( humza_wa_href( __( 'Ciao, vorrei fare una domanda su una pratica.', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer">
							<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>WhatsApp<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
						</a>
					</div>
				</div>

			<?php endif; ?>

		</div>
	</section>

</main>

<?php get_footer(); ?>
