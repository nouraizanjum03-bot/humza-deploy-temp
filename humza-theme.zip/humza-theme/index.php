<?php
/**
 * Fallback generico: archivi, ricerche e ogni vista senza template dedicato.
 * Nessun vicolo cieco: c'è sempre il campo di ricerca, il link ai servizi e
 * WhatsApp anche quando non esce nessun risultato.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();

$humza_is_search    = is_search();
$humza_search_query = $humza_is_search ? get_search_query() : '';
?>

<main id="main">
	<header class="page-hero">
		<div class="container">
			<?php
			if ( function_exists( 'humza_breadcrumb' ) ) {
				humza_breadcrumb();
			}
			?>
			<h1>
				<?php
				if ( is_home() ) {
					esc_html_e( 'Novità', 'hamza-theme' );
				} elseif ( is_archive() ) {
					the_archive_title();
				} elseif ( $humza_is_search ) {
					printf(
						/* translators: %s: termine cercato. */
						esc_html__( 'Risultati per: %s', 'hamza-theme' ),
						esc_html( $humza_search_query )
					);
				} else {
					esc_html_e( 'Contenuti', 'hamza-theme' );
				}
				?>
			</h1>
			<?php if ( is_archive() && '' !== trim( (string) get_the_archive_description() ) ) : ?>
				<div class="page-hero__sub"><?php the_archive_description(); ?></div>
			<?php endif; ?>
		</div>
	</header>

	<div class="container section">

		<?php if ( $humza_is_search ) : ?>
			<form class="search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<div class="field">
					<label for="humza-search-field"><?php esc_html_e( 'Cerca nel sito', 'hamza-theme' ); ?></label>
					<input type="search" id="humza-search-field" name="s" value="<?php echo esc_attr( $humza_search_query ); ?>" placeholder="<?php esc_attr_e( 'Es. permesso di soggiorno', 'hamza-theme' ); ?>">
				</div>
				<button type="submit" class="btn btn--navy"><?php esc_html_e( 'Cerca', 'hamza-theme' ); ?></button>
			</form>
		<?php endif; ?>

		<?php if ( have_posts() ) : ?>
			<div class="grid grid--2 grid--3">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article class="card post-card">
						<div class="post-card__body">
							<p class="post-card__meta">
								<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
							</p>
							<h2 class="h3"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
							<p><?php echo esc_html( get_the_excerpt() ); ?></p>
							<span class="card__more" aria-hidden="true"><?php esc_html_e( 'Apri', 'hamza-theme' ); ?></span>
						</div>
					</article>
				<?php endwhile; ?>
			</div>
			<?php
			the_posts_pagination( array(
				'mid_size'           => 1,
				'prev_text'          => esc_html__( '« Precedenti', 'hamza-theme' ),
				'next_text'          => esc_html__( 'Successivi »', 'hamza-theme' ),
				'screen_reader_text' => esc_html__( 'Navigazione dei risultati', 'hamza-theme' ),
				'aria_label'         => esc_html__( 'Navigazione dei risultati', 'hamza-theme' ),
				'class'              => 'pagination',
			) );
			?>
		<?php else : ?>
			<div class="aside-box empty-state">
				<h2>
					<?php
					if ( $humza_is_search ) {
						esc_html_e( 'Nessun risultato', 'hamza-theme' );
					} else {
						esc_html_e( 'Nessun contenuto trovato', 'hamza-theme' );
					}
					?>
				</h2>
				<p><?php esc_html_e( 'Prova con una parola più semplice (per esempio «visto», «ISEE», «traduzione»), guarda l’elenco dei servizi oppure chiedi direttamente a noi.', 'hamza-theme' ); ?></p>

				<?php if ( ! $humza_is_search ) : ?>
					<form class="search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
						<div class="field">
							<label for="humza-search-empty"><?php esc_html_e( 'Cerca nel sito', 'hamza-theme' ); ?></label>
							<input type="search" id="humza-search-empty" name="s" value="" placeholder="<?php esc_attr_e( 'Es. permesso di soggiorno', 'hamza-theme' ); ?>">
						</div>
						<button type="submit" class="btn btn--navy"><?php esc_html_e( 'Cerca', 'hamza-theme' ); ?></button>
					</form>
				<?php endif; ?>

				<div class="btn-row">
					<a class="btn btn--primary" href="<?php echo esc_url( home_url( '/servizi/' ) ); ?>"><?php esc_html_e( 'Vedi i servizi', 'hamza-theme' ); ?></a>
					<a class="btn btn--wa" href="<?php echo esc_url( humza_wa_href( __( 'Ciao, sto cercando un’informazione sul vostro sito: potete aiutarmi?', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>WhatsApp<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
					</a>
				</div>
			</div>
		<?php endif; ?>
	</div>
</main>

<?php get_footer(); ?>
