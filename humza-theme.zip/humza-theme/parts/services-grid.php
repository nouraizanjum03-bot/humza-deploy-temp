<?php
/**
 * Parte riusabile: griglia delle card servizio.
 *
 * Sorgente dati: pagine figlie di /servizi/ (ordinate per menu_order)
 * + pagina /traduzioni/. Icona per card dal post meta `humza_icon`
 * (fallback: ic-altri). Nessun dato inventato: titolo/excerpt dalle pagine.
 *
 * Le descrizioni vengono troncate a 14 parole (~95 caratteri) così che le
 * card abbiano tutte la stessa altezza di testo: la griglia resta ordinata
 * anche se il cliente scrive excerpt di lunghezza molto diversa.
 * L'intera card è cliccabile: il link nel titolo copre la card via
 * `.card h3 a::after` (main.css), quindi niente link annidati.
 *
 * Usata da: front-page.php, page-templates/template-services.php,
 * page-templates/template-about.php.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

// Variabile locale (non costante): il part può essere incluso più volte nella stessa pagina.
$humza_excerpt_words = 14;

$humza_servizi_parent = get_page_by_path( 'servizi' );
$humza_service_pages  = array();

if ( $humza_servizi_parent instanceof WP_Post && 'publish' === $humza_servizi_parent->post_status ) {
	$humza_children = get_pages(
		array(
			'parent'      => $humza_servizi_parent->ID,
			'sort_column' => 'menu_order',
			'sort_order'  => 'asc',
		)
	);
	if ( is_array( $humza_children ) ) {
		$humza_service_pages = $humza_children;
	}
}

$humza_traduzioni = get_page_by_path( 'traduzioni' );
if ( $humza_traduzioni instanceof WP_Post && 'publish' === $humza_traduzioni->post_status
	&& ! in_array( $humza_traduzioni->ID, wp_list_pluck( $humza_service_pages, 'ID' ), true ) ) {
	$humza_service_pages[] = $humza_traduzioni;
}
?>

<?php if ( empty( $humza_service_pages ) ) : ?>
	<p class="services-grid-empty">
		<?php esc_html_e( 'Le pagine dei servizi saranno presto online. Nel frattempo scrivici: ti diciamo subito se possiamo aiutarti con la tua pratica.', 'hamza-theme' ); ?>
		<a href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>"><?php esc_html_e( 'Vai ai contatti', 'hamza-theme' ); ?></a>
	</p>
<?php else : ?>
	<div class="grid grid--2 grid--3">
		<?php
		foreach ( $humza_service_pages as $humza_sp ) :
			$humza_card_icon = get_post_meta( $humza_sp->ID, 'humza_icon', true );
			$humza_card_icon = is_string( $humza_card_icon ) && '' !== $humza_card_icon ? $humza_card_icon : 'ic-altri';

			$humza_card_text = wp_trim_words(
				wp_strip_all_tags( (string) get_the_excerpt( $humza_sp ) ),
				$humza_excerpt_words,
				'…'
			);
			?>
			<article class="card">
				<span class="card__icon"><?php echo humza_icon( $humza_card_icon, 34 ); ?></span>
				<h3><a href="<?php echo esc_url( get_permalink( $humza_sp ) ); ?>"><?php echo esc_html( get_the_title( $humza_sp ) ); ?></a></h3>
				<?php if ( '' !== $humza_card_text ) : ?>
				<p><?php echo esc_html( $humza_card_text ); ?></p>
				<?php endif; ?>
				<span class="card__more" aria-hidden="true"><?php esc_html_e( 'Scopri di più', 'hamza-theme' ); ?></span>
			</article>
		<?php endforeach; ?>
	</div>
<?php endif; ?>
