<?php
/**
 * Selettore lingua — widget GTranslate incapsulato.
 *
 * Il motore di traduzione è GTranslate: le sue librerie vengono accodate
 * SOLO quando il suo widget è presente in pagina, quindi qui si stampa il
 * widget vero (shortcode) invece di una lista di link nostri, che senza
 * quelle librerie resterebbe inerte. Il widget si disegna via JavaScript
 * dentro il div restituito dallo shortcode.
 *
 * Va incluso UNA VOLTA SOLA per pagina (due istanze = due widget e due
 * script): sta nella topbar, visibile a ogni larghezza.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

// Nessun motore di traduzione installato: niente controllo morto in pagina.
if ( ! shortcode_exists( 'gtranslate' ) ) {
	return;
}

// Guardia anti-doppia inclusione (il part è richiamato da più template).
if ( defined( 'HUMZA_LANG_SWITCHER_DONE' ) ) {
	return;
}
define( 'HUMZA_LANG_SWITCHER_DONE', true );
?>
<div class="lang-widget notranslate" translate="no">
	<span class="screen-reader-text" id="humza-lang-label"><?php esc_html_e( 'Scegli la lingua del sito', 'hamza-theme' ); ?></span>
	<?php
	// Markup del plugin: contenitore vuoto riempito dal suo script.
	echo do_shortcode( '[gtranslate]' ); // phpcs:ignore WordPress.Security.EscapeOutput -- output dello shortcode del plugin.
	?>
	<noscript>
		<span class="lang-widget__noscript"><?php esc_html_e( 'Per cambiare lingua serve JavaScript. Scrivici su WhatsApp nella tua lingua: ti rispondiamo noi.', 'hamza-theme' ); ?></span>
	</noscript>
</div>
