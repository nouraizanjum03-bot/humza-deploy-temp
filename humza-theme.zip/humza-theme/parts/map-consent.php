<?php
/**
 * Mappa Google con consenso esplicito (privacy-first).
 *
 * Contratto con assets/js/main.js (classi esatte, non rinominare):
 * - .map-accept-cookies : bottone che concede il consenso e rivela la mappa
 * - .map-placeholder    : box informativo mostrato prima del consenso
 * - .map-container      : contenitore [hidden]; alla reveal il JS toglie
 *   l'attributo hidden e imposta iframe.src da humzaTheme.mapsEmbed.
 *
 * L'iframe parte con src vuoto (= about:blank per specifica HTML) e SENZA
 * data-src: nessuna richiesta verso Google prima del consenso dell'utente.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="map-placeholder">
	<p><?php esc_html_e( 'La mappa è di Google e usa cookie di terze parti. Finché non l’accetti, non inviamo nessun dato a Google.', 'hamza-theme' ); ?></p>
	<button type="button" class="btn btn--primary map-accept-cookies"><?php esc_html_e( 'Mostra la mappa', 'hamza-theme' ); ?></button>
</div>

<div class="map-container" hidden>
	<iframe src="" title="<?php esc_attr_e( 'Mappa: sede di Humza Multiservizi', 'hamza-theme' ); ?>" loading="lazy" allowfullscreen referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
