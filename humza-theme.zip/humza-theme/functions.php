<?php
/**
 * Humza Multiservizi — functions.php (tema v2.0.0)
 */

defined( 'ABSPATH' ) || exit;

define( 'HUMZA_VERSION', '2.0.0' );

require_once get_template_directory() . '/inc/customizer.php';
require_once get_template_directory() . '/inc/meta.php';
require_once get_template_directory() . '/inc/schema.php';
require_once get_template_directory() . '/inc/breadcrumb.php';
require_once get_template_directory() . '/inc/security.php';
require_once get_template_directory() . '/inc/ai-discovery.php';
require_once get_template_directory() . '/inc/admin-ux.php';

/* ---------- Setup ---------- */
add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'hamza-theme', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/editor.css' );
	add_post_type_support( 'page', 'excerpt' );

	register_nav_menus( array(
		'primary'        => __( 'Menu principale', 'hamza-theme' ),
		'footer-servizi' => __( 'Footer: servizi', 'hamza-theme' ),
		'footer-utili'   => __( 'Footer: link utili', 'hamza-theme' ),
	) );
} );

/* ---------- Asset ---------- */
function humza_asset_ver( $rel ) {
	$file = get_template_directory() . $rel;
	return file_exists( $file ) ? (string) filemtime( $file ) : HUMZA_VERSION;
}

/**
 * La pagina corrente mostra il widget prenotazioni?
 *
 * Il CSS del widget pesa quanto tutto il resto del tema: va caricato solo
 * dove serve davvero (pagina Prenota, Area Clienti, o contenuti che
 * includono lo shortcode del plugin).
 *
 * @return bool
 */
function humza_needs_booking_assets() {
	if ( is_page_template( array( 'page-templates/template-booking.php', 'page-templates/template-client-portal.php' ) ) ) {
		return true;
	}
	if ( wp_style_is( 'hamza-booking-frontend', 'enqueued' ) || wp_script_is( 'hamza-booking-frontend', 'enqueued' ) ) {
		return true;
	}
	if ( is_singular() ) {
		$content = (string) get_post_field( 'post_content', get_queried_object_id() );
		foreach ( array( 'hamza_booking', 'hamza-booking', 'hamza_my_appointments' ) as $tag ) {
			if ( has_shortcode( $content, $tag ) ) {
				return true;
			}
		}
	}
	return false;
}

add_action( 'wp_enqueue_scripts', function () {
	// Font serviti dal nostro dominio: nessuna richiesta a Google (privacy e velocità).
	wp_enqueue_style( 'humza-fonts', get_template_directory_uri() . '/assets/css/fonts.css', array(), humza_asset_ver( '/assets/css/fonts.css' ) );
	wp_enqueue_style( 'humza-main', get_template_directory_uri() . '/assets/css/main.css', array( 'humza-fonts' ), humza_asset_ver( '/assets/css/main.css' ) );

	wp_enqueue_script( 'humza-main', get_template_directory_uri() . '/assets/js/main.js', array(), humza_asset_ver( '/assets/js/main.js' ), array( 'strategy' => 'defer', 'in_footer' => true ) );
	wp_enqueue_script( 'humza-consent', get_template_directory_uri() . '/assets/js/cookie-consent.js', array(), humza_asset_ver( '/assets/js/cookie-consent.js' ), array( 'strategy' => 'defer', 'in_footer' => true ) );

	wp_localize_script( 'humza-main', 'humzaTheme', array(
		'mapsEmbed' => humza_maps_embed_url(),
	) );

	if ( humza_needs_booking_assets() ) {
		$deps = wp_style_is( 'hamza-booking-frontend', 'registered' ) ? array( 'hamza-booking-frontend' ) : array( 'humza-main' );
		wp_enqueue_style( 'humza-booking-skin', get_template_directory_uri() . '/assets/css/booking-skin.css', $deps, humza_asset_ver( '/assets/css/booking-skin.css' ) );
	}
}, 20 );

// I due font del testo visibile subito: precaricati per non ritardare il titolo.
add_action( 'wp_head', function () {
	$fonts = array( 'Inter-latin.woff2', 'PlusJakartaSans-latin.woff2' );
	foreach ( $fonts as $font ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( get_template_directory_uri() . '/assets/fonts/' . $font )
		);
	}
}, 2 );

// Hostinger Reach: assets solo dove esiste il blocco iscrizione.
add_action( 'wp_enqueue_scripts', function () {
	if ( is_singular() && ! has_block( 'hostinger-reach/subscription' ) ) {
		wp_dequeue_style( 'hostinger-reach-subscription' );
		wp_dequeue_script( 'hostinger-reach-subscription-view' );
	}
}, 100 );

// Niente emoji script (peso inutile).
add_action( 'init', function () {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
} );

/* ---------- Dati attività (unica fonte per NAP) ---------- */
function humza_biz( $key ) {
	$defaults = array(
		'name'      => 'Humza Multiservizi',
		'legalname' => 'ISHTIAQ HUMZA MULTISERVIZI',
		'street'    => 'Via Milano 7/D',
		'cap'       => '25126',
		'city'      => 'Brescia',
		'prov'      => 'BS',
		'phone1'    => '324 092 0518',
		'phone2'    => '329 128 5317',
		'whatsapp'  => '393240920518',
		'email'     => 'centrovistibrescia@gmail.com',
		'piva'      => '04586710982',
		'hours_am'  => '09:00 - 13:00',
		'hours_pm'  => '15:00 - 19:00',
		'days'      => 'Lun - Sab',
		'tiktok'    => 'https://www.tiktok.com/@hamzamultiservizi',
		'gbp'       => '',
		'maps_q'    => 'Humza Multiservizi, Via Milano, Brescia',
	);
	$value = get_theme_mod( 'humza_' . $key, $defaults[ $key ] ?? '' );
	return is_string( $value ) ? trim( $value ) : $value;
}

/**
 * Costruisce l'href tel: di un numero italiano.
 *
 * Restituisce stringa vuota se il numero non e' configurato: senza questa
 * guardia un campo svuotato nel Personalizza produrrebbe "tel:+39", cioe' un
 * link che avvia una chiamata a un numero inesistente. Chi stampa il link deve
 * comunque verificare il numero prima di emettere l'<a>.
 *
 * @param string $phone Numero come inserito dall'utente.
 * @return string href tel: oppure '' se non c'e' nessuna cifra.
 */
function humza_phone_href( $phone ) {
	$digits = preg_replace( '/\D/', '', (string) $phone );
	return '' === $digits ? '' : 'tel:+39' . $digits;
}

function humza_wa_href( $message = '' ) {
	$url = 'https://wa.me/' . preg_replace( '/\D/', '', humza_biz( 'whatsapp' ) );
	if ( '' !== $message ) {
		$url .= '?text=' . rawurlencode( $message );
	}
	return $url;
}

function humza_maps_embed_url() {
	return 'https://www.google.com/maps?q=' . rawurlencode( humza_biz( 'maps_q' ) ) . '&output=embed';
}

/* ---------- Icone (sprite SVG) ---------- */
function humza_icon( $name, $size = 24, $class = '' ) {
	// L'attributo class viene omesso se vuoto: quasi tutte le chiamate non
	// passano una classe e un class="" su ogni icona e' solo rumore nel markup.
	$class_attr = ( '' !== $class ) ? sprintf( ' class="%s"', esc_attr( $class ) ) : '';

	return sprintf(
		'<svg%s width="%d" height="%d" aria-hidden="true" focusable="false"><use href="#%s"></use></svg>',
		$class_attr,
		(int) $size,
		(int) $size,
		esc_attr( $name )
	);
}

// Sprite iniettato una volta a inizio body.
add_action( 'wp_body_open', function () {
	$sprite = get_template_directory() . '/assets/img/icons-humza.svg';
	if ( is_readable( $sprite ) ) {
		// Sprite statico del tema, già sanificato in build.
		echo file_get_contents( $sprite ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}, 5 );

/* ---------- Excerpt ---------- */
add_filter( 'excerpt_length', fn() => 24, 999 );
// Carattere reale (non entity): gli excerpt passano anche da esc_html() nei template.
add_filter( 'excerpt_more', fn() => '…' );

/* ---------- Corpo pagina: wrapper tabelle responsive ---------- */
add_filter( 'the_content', function ( $content ) {
	if ( is_admin() ) {
		return $content;
	}
	$content = preg_replace( '/<table\b/', '<div class="table-wrap"><table', $content );
	return preg_replace( '/<\/table>/', '</table></div>', $content );
} );
