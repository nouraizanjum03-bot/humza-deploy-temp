<?php
/**
 * Header: topbar contatti + header sticky + menu mobile accessibile.
 *
 * Contratto con assets/js/main.js e assets/css/main.css:
 * - .nav-toggle      : sempre nel markup, mostrato dal CSS sotto 1024px
 * - #mobile-menu     : drawer con backdrop, focus trap gestito dal JS
 * - .header-cta      : CTA "Prenota" nell'header, visibile da 768px in su
 * - .topbar__email   : wrapper email della topbar (nascosto sotto 480px)
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

/*
 * Icona "persona" per Area Clienti: non esiste nello sprite del tema
 * (assets/img/icons-humza.svg), quindi vive qui come stringa statica
 * riusata due volte (topbar + menu mobile). fill="currentColor": eredita
 * il colore del link in entrambi i contesti, chiaro e scuro.
 */
$humza_icon_user = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 12.2a4.1 4.1 0 1 0 0-8.2 4.1 4.1 0 0 0 0 8.2Zm0 1.8c-3.9 0-7.1 1.9-7.1 4.3v1.2c0 .3.2.5.5.5h13.2c.3 0 .5-.2.5-.5v-1.2c0-2.4-3.2-4.3-7.1-4.3Z"/></svg>';
$humza_area_url  = home_url( '/area-clienti/' );
$humza_prenota   = home_url( '/prenota/' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>document.documentElement.classList.add('js');</script><!-- html.js: gli stati nascosti di [data-animate] (main.css) si attivano solo con JS -->
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main"><?php esc_html_e( 'Salta al contenuto', 'hamza-theme' ); ?></a>

<div class="topbar">
	<div class="container topbar__inner">
		<div class="topbar__contacts">
			<?php if ( humza_biz( 'phone1' ) ) : ?>
			<a href="<?php echo esc_url( humza_phone_href( humza_biz( 'phone1' ) ) ); ?>"><?php echo humza_icon( 'ic-tel', 15 ); ?><?php echo esc_html( humza_biz( 'phone1' ) ); ?></a>
			<?php endif; ?>
			<?php if ( humza_biz( 'phone2' ) ) : ?>
			<a class="topbar__phone2" href="<?php echo esc_url( humza_phone_href( humza_biz( 'phone2' ) ) ); ?>"><?php echo humza_icon( 'ic-tel', 15 ); ?><?php echo esc_html( humza_biz( 'phone2' ) ); ?></a>
			<?php endif; ?>
			<span class="topbar__email">
				<a href="mailto:<?php echo esc_attr( humza_biz( 'email' ) ); ?>"><?php echo humza_icon( 'ic-mail', 15 ); ?><?php echo esc_html( humza_biz( 'email' ) ); ?></a>
			</span>
		</div>
		<div class="topbar__end">
			<div class="topbar__lang">
				<?php get_template_part( 'parts/lang-switcher' ); ?>
			</div>
			<a class="topbar__area" href="<?php echo esc_url( $humza_area_url ); ?>">
				<?php echo $humza_icon_user; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup statico del tema. ?>
				<?php esc_html_e( 'Area Clienti', 'hamza-theme' ); ?>
			</a>
		</div>
	</div>
</div>

<header class="site-header" id="site-header">
	<div class="container site-header__inner">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php echo esc_attr( humza_biz( 'name' ) ); ?> — Home">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/logo-humza.svg' ); ?>" alt="<?php echo esc_attr( humza_biz( 'name' ) ); ?>" width="340" height="64">
		</a>

		<nav class="nav-main" aria-label="<?php esc_attr_e( 'Menu principale', 'hamza-theme' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => '',
				'fallback_cb'    => 'humza_nav_fallback',
				'depth'          => 1,
			) );
			?>
		</nav>

		<a class="btn btn--primary header-cta" href="<?php echo esc_url( $humza_prenota ); ?>"><?php esc_html_e( 'Prenota', 'hamza-theme' ); ?></a>

		<button class="nav-toggle" type="button" aria-expanded="false" aria-controls="mobile-menu" aria-label="<?php esc_attr_e( 'Apri il menu', 'hamza-theme' ); ?>">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
		</button>
	</div>
</header>

<div class="mobile-menu" id="mobile-menu" hidden>
	<button class="mobile-menu__backdrop" type="button" tabindex="-1" aria-label="<?php esc_attr_e( 'Chiudi il menu', 'hamza-theme' ); ?>"></button>
	<div class="mobile-menu__panel" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Menu di navigazione', 'hamza-theme' ); ?>">
		<div class="mobile-menu__top">
			<span class="brand"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/logo-humza.svg' ); ?>" alt="" width="240" height="46"></span>
			<button class="mobile-menu__close" type="button" aria-label="<?php esc_attr_e( 'Chiudi il menu', 'hamza-theme' ); ?>">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
			</button>
		</div>

		<?php /* Chi apre il menu da telefono, spesso vuole solo chiamare: i contatti stanno in cima. */ ?>
		<ul class="mobile-menu__contacts">
			<?php if ( humza_biz( 'phone1' ) ) : ?>
			<li>
				<a href="<?php echo esc_url( humza_phone_href( humza_biz( 'phone1' ) ) ); ?>">
					<?php echo humza_icon( 'ic-tel', 20 ); ?><span><?php echo esc_html( humza_biz( 'phone1' ) ); ?></span>
				</a>
			</li>
			<?php endif; ?>
			<?php if ( humza_biz( 'phone2' ) ) : ?>
			<li>
				<a href="<?php echo esc_url( humza_phone_href( humza_biz( 'phone2' ) ) ); ?>">
					<?php echo humza_icon( 'ic-tel', 20 ); ?><span><?php echo esc_html( humza_biz( 'phone2' ) ); ?></span>
				</a>
			</li>
			<?php endif; ?>
			<li>
				<a href="mailto:<?php echo esc_attr( humza_biz( 'email' ) ); ?>">
					<?php echo humza_icon( 'ic-mail', 20 ); ?><span><?php echo esc_html( humza_biz( 'email' ) ); ?></span>
				</a>
			</li>
			<li>
				<a href="<?php echo esc_url( $humza_area_url ); ?>">
					<?php echo $humza_icon_user; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup statico del tema. ?>
					<span><?php esc_html_e( 'Area Clienti', 'hamza-theme' ); ?></span>
				</a>
			</li>
		</ul>

<?php /* Il selettore lingua vive nella topbar, visibile a ogni larghezza: una sola istanza del widget per pagina. */ ?>

		<nav aria-label="<?php esc_attr_e( 'Menu principale', 'hamza-theme' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => '',
				'fallback_cb'    => 'humza_nav_fallback',
				'depth'          => 1,
			) );
			?>
		</nav>

		<div class="mobile-menu__cta">
			<a class="btn btn--primary" href="<?php echo esc_url( $humza_prenota ); ?>"><?php esc_html_e( 'Prenota appuntamento', 'hamza-theme' ); ?></a>
			<a class="btn btn--wa" href="<?php echo esc_url( humza_wa_href( __( 'Ciao, ho bisogno di informazioni.', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer">
				<?php echo humza_icon( 'ic-wa', 20 ); ?>WhatsApp<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
			</a>
		</div>
	</div>
</div>
