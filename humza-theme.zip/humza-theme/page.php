<?php
/**
 * Template pagina generica (privacy, cookie policy, pagine statiche
 * senza template dedicato): hero con breadcrumb + contenuto in .prose
 * con data di ultimo aggiornamento (utile per le pagine legali).
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="main">

	<?php while ( have_posts() ) : the_post(); ?>

		<header class="page-hero">
			<div class="container">
				<?php
				if ( function_exists( 'humza_breadcrumb' ) ) {
					humza_breadcrumb();
				}
				?>
				<h1><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="page-hero__sub"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
			</div>
		</header>

		<div class="container section">
			<div class="prose">
				<?php
				the_content();

				wp_link_pages( array(
					'before' => '<nav class="page-links" aria-label="' . esc_attr__( 'Pagine del contenuto', 'hamza-theme' ) . '">' . esc_html__( 'Pagine:', 'hamza-theme' ) . ' ',
					'after'  => '</nav>',
				) );
				?>
				<p class="last-updated">
					<?php
					printf(
						/* translators: %s: data di ultima modifica della pagina. */
						esc_html__( 'Ultimo aggiornamento: %s', 'hamza-theme' ),
						'<time datetime="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . esc_html( get_the_modified_date( 'j F Y' ) ) . '</time>'
					);
					?>
				</p>
			</div>
		</div>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>
