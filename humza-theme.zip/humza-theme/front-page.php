<?php
/**
 * Homepage: hero + servizi (dinamici) + come funziona + perché Humza + novità
 * + lingue + dove siamo.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();

$humza_prenota = home_url( '/prenota/' );

/*
 * Lingue in cui l'ufficio assiste i clienti: nomi nativi (non traducibili),
 * con codice lingua e direzione di scrittura per screen reader e font stack.
 * Stessa lista del selettore lingua (parts/lang-switcher.php).
 */
$humza_home_langs = array(
	array(
		'name' => 'Italiano',
		'lang' => 'it',
		'rtl'  => false,
	),
	array(
		'name' => 'English',
		'lang' => 'en',
		'rtl'  => false,
	),
	array(
		'name' => 'Français',
		'lang' => 'fr',
		'rtl'  => false,
	),
	array(
		'name' => 'اردو',
		'lang' => 'ur',
		'rtl'  => true,
	),
	array(
		'name' => 'हिन्दी',
		'lang' => 'hi',
		'rtl'  => false,
	),
	array(
		'name' => 'ਪੰਜਾਬੀ',
		'lang' => 'pa',
		'rtl'  => false,
	),
);
?>

<main id="main">

	<!-- Hero -->
	<section class="hero" aria-labelledby="hero-title">
		<div class="container hero__inner">
			<div>
				<span class="hero__badge"><?php echo humza_icon( 'ic-vidimato', 16 ); ?><?php esc_html_e( 'Assistenza in 6 lingue', 'hamza-theme' ); ?></span>
				<h1 id="hero-title"><?php esc_html_e( 'Pratiche, CAF, visti e documenti a Brescia. Nella tua lingua.', 'hamza-theme' ); ?></h1>
				<p class="hero__lead"><?php esc_html_e( 'Humza Multiservizi segue la tua pratica dall’inizio alla fine: fisco e CAF, immigrazione, consolati, visti e traduzioni.', 'hamza-theme' ); ?></p>
				<div class="hero__cta">
					<a class="btn btn--primary btn--block-mobile" href="<?php echo esc_url( $humza_prenota ); ?>"><?php esc_html_e( 'Prenota appuntamento', 'hamza-theme' ); ?></a>
					<a class="btn btn--ghost-light btn--block-mobile" href="<?php echo esc_url( humza_wa_href( __( 'Ciao, ho bisogno di informazioni su una pratica.', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo humza_icon( 'ic-wa', 20 ); ?>WhatsApp<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span></a>
				</div>
				<p class="hero__note"><?php echo humza_icon( 'ic-vidimato', 18 ); ?><?php esc_html_e( 'Ti diciamo subito documenti, tempi e costi.', 'hamza-theme' ); ?></p>
				<ul class="hero__facts">
					<li><?php echo humza_icon( 'ic-orari', 17 ); ?><?php echo esc_html( humza_biz( 'days' ) ); ?></li>
					<li><?php echo humza_icon( 'ic-mappa', 17 ); ?><?php echo esc_html( humza_biz( 'street' ) . ', ' . humza_biz( 'city' ) ); ?></li>
					<li><?php echo humza_icon( 'ic-vidimato', 17 ); ?><?php esc_html_e( 'Prenoti online o su WhatsApp', 'hamza-theme' ); ?></li>
				</ul>
			</div>
			<div class="hero__art" aria-hidden="true">
				<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/hero-pratiche.svg' ); ?>" alt="" width="680" height="540" fetchpriority="high">
			</div>
		</div>
	</section>

	<!-- Servizi: card generate dalle pagine figlie di /servizi/ + pagina Traduzioni -->
	<section class="section" aria-labelledby="servizi-title">
		<div class="container">
			<div class="section-head">
				<span class="stamp"><?php esc_html_e( 'I nostri servizi', 'hamza-theme' ); ?></span>
				<h2 id="servizi-title"><?php esc_html_e( 'Di quale pratica hai bisogno?', 'hamza-theme' ); ?></h2>
				<p><?php esc_html_e( 'Assistenza completa per pratiche fiscali, di immigrazione e consolari.', 'hamza-theme' ); ?></p>
			</div>
			<?php get_template_part( 'parts/services-grid' ); ?>
		</div>
	</section>

	<!-- Come funziona -->
	<section class="section section--paper" aria-labelledby="passi-title">
		<div class="container">
			<div class="section-head">
				<span class="stamp"><?php esc_html_e( 'Come funziona', 'hamza-theme' ); ?></span>
				<h2 id="passi-title"><?php esc_html_e( 'Tre passi, e la pratica è avviata', 'hamza-theme' ); ?></h2>
			</div>
			<div class="grid grid--3 steps">
				<div class="step" data-animate>
					<span class="step__num" aria-hidden="true"></span>
					<h3><?php esc_html_e( 'Prenota', 'hamza-theme' ); ?></h3>
					<p><?php esc_html_e( 'Scegli giorno e ora online, oppure scrivici su WhatsApp: rispondiamo negli orari di apertura.', 'hamza-theme' ); ?></p>
				</div>
				<div class="step" data-animate>
					<span class="step__num" aria-hidden="true"></span>
					<h3><?php esc_html_e( 'Porta i documenti', 'hamza-theme' ); ?></h3>
					<p><?php esc_html_e( 'Prima dell’appuntamento ti mandiamo la lista esatta di ciò che serve, così basta una sola visita.', 'hamza-theme' ); ?></p>
				</div>
				<div class="step" data-animate>
					<span class="step__num" aria-hidden="true"></span>
					<h3><?php esc_html_e( 'Ritira la pratica', 'hamza-theme' ); ?></h3>
					<p><?php esc_html_e( 'Prepariamo e inviamo noi la pratica, e ti avvisiamo appena c’è una risposta o serve altro.', 'hamza-theme' ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<?php
	/*
	 * Perché Humza — due esecuzioni:
	 * 1) con immagine in evidenza reale: impaginato editoriale su due colonne;
	 * 2) senza immagine: griglia "cosa ottieni" a piena larghezza. L'illustrazione
	 *    del hero NON viene ripetuta qui: riusarla svuoterebbe entrambe le sezioni.
	 */
	$humza_has_photo = has_post_thumbnail();
	?>
	<section class="section" aria-labelledby="perche-title">
		<?php if ( $humza_has_photo ) : ?>
		<div class="container why">
			<div class="why__media">
				<?php the_post_thumbnail( 'large', array( 'alt' => esc_attr__( 'L’ufficio di Humza Multiservizi a Brescia', 'hamza-theme' ) ) ); ?>
			</div>
			<div>
				<span class="stamp"><?php esc_html_e( 'Perché Humza', 'hamza-theme' ); ?></span>
				<h2 id="perche-title"><?php esc_html_e( 'Un unico ufficio per tutte le tue pratiche', 'hamza-theme' ); ?></h2>
				<p><?php esc_html_e( 'Humza Multiservizi è un centro pratiche di Brescia al servizio della comunità internazionale e di chi ha bisogno di una mano con la burocrazia italiana.', 'hamza-theme' ); ?></p>
				<ul class="checklist">
					<li><?php echo humza_icon( 'ic-vidimato', 22 ); ?><span><?php esc_html_e( 'Ti assistiamo in 6 lingue: italiano, inglese, francese, urdu, hindi e punjabi.', 'hamza-theme' ); ?></span></li>
					<li><?php echo humza_icon( 'ic-vidimato', 22 ); ?><span><?php esc_html_e( 'Prenotazione online e contatto diretto su WhatsApp.', 'hamza-theme' ); ?></span></li>
					<li><?php echo humza_icon( 'ic-vidimato', 22 ); ?><span><?php esc_html_e( 'Costi chiari prima di iniziare: nessuna sorpresa a fine pratica.', 'hamza-theme' ); ?></span></li>
					<li><?php echo humza_icon( 'ic-vidimato', 22 ); ?><span><?php esc_html_e( 'Ufficio in Via Milano a Brescia, comodo da raggiungere.', 'hamza-theme' ); ?></span></li>
					<li><?php echo humza_icon( 'ic-vidimato', 22 ); ?><span><?php esc_html_e( 'Attività registrata: la P.IVA è in fondo a ogni pagina.', 'hamza-theme' ); ?></span></li>
				</ul>
			</div>
		</div>
		<?php else : ?>
		<div class="container">
			<div class="section-head">
				<span class="stamp"><?php esc_html_e( 'Perché Humza', 'hamza-theme' ); ?></span>
				<h2 id="perche-title"><?php esc_html_e( 'Un unico ufficio per tutte le tue pratiche', 'hamza-theme' ); ?></h2>
				<p><?php esc_html_e( 'Siamo un centro pratiche di Brescia al servizio della comunità internazionale e di chi ha bisogno di una mano con la burocrazia italiana.', 'hamza-theme' ); ?></p>
			</div>
			<div class="grid grid--2 grid--4">
				<div class="mini-card" data-animate>
					<span class="card__icon"><?php echo humza_icon( 'ic-vidimato', 34 ); ?></span>
					<h3 class="h4"><?php esc_html_e( 'Ti parliamo nella tua lingua', 'hamza-theme' ); ?></h3>
					<p><?php esc_html_e( 'Italiano, inglese, francese, urdu, hindi e punjabi: spieghiamo la pratica in modo che sia chiara.', 'hamza-theme' ); ?></p>
				</div>
				<div class="mini-card" data-animate>
					<span class="card__icon"><?php echo humza_icon( 'ic-altri', 34 ); ?></span>
					<h3 class="h4"><?php esc_html_e( 'Tutte le pratiche in un posto solo', 'hamza-theme' ); ?></h3>
					<p><?php esc_html_e( 'Fisco e CAF, immigrazione, consolati, visti e traduzioni: non devi andare in cinque uffici diversi.', 'hamza-theme' ); ?></p>
				</div>
				<div class="mini-card" data-animate>
					<span class="card__icon"><?php echo humza_icon( 'ic-caf', 34 ); ?></span>
					<h3 class="h4"><?php esc_html_e( 'Costi chiari prima di iniziare', 'hamza-theme' ); ?></h3>
					<p><?php esc_html_e( 'Sai quanto costa la pratica prima di avviarla: nessuna sorpresa alla fine.', 'hamza-theme' ); ?></p>
				</div>
				<div class="mini-card" data-animate>
					<span class="card__icon"><?php echo humza_icon( 'ic-orari', 34 ); ?></span>
					<h3 class="h4"><?php esc_html_e( 'Prenoti quando vuoi', 'hamza-theme' ); ?></h3>
					<p><?php esc_html_e( 'Scegli giorno e ora online, anche fuori orario, oppure scrivici su WhatsApp.', 'hamza-theme' ); ?></p>
				</div>
			</div>
			<p class="section-note">
				<?php
				printf(
					/* translators: 1: ragione sociale, 2: partita IVA, 3: indirizzo, 4: città */
					esc_html__( 'Attività registrata: %1$s, P.IVA %2$s — ufficio in %3$s, %4$s.', 'hamza-theme' ),
					esc_html( humza_biz( 'legalname' ) ),
					esc_html( humza_biz( 'piva' ) ),
					esc_html( humza_biz( 'street' ) ),
					esc_html( humza_biz( 'city' ) )
				);
				?>
			</p>
		</div>
		<?php endif; ?>
	</section>

	<!-- Novità -->
	<?php
	$news = new WP_Query( array(
		'posts_per_page'      => 3,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	) );
	if ( $news->have_posts() ) :
		?>
		<section class="section section--paper" aria-labelledby="novita-title">
			<div class="container">
				<div class="section-head">
					<span class="stamp"><?php esc_html_e( 'Novità', 'hamza-theme' ); ?></span>
					<h2 id="novita-title"><?php esc_html_e( 'Ultime notizie e scadenze', 'hamza-theme' ); ?></h2>
				</div>
				<div class="grid grid--3">
					<?php
					while ( $news->have_posts() ) :
						$news->the_post();
						?>
						<article class="card post-card">
							<div class="post-card__body">
								<p class="post-card__meta">
									<?php $cat = get_the_category(); if ( $cat ) : ?><span class="cat"><?php echo esc_html( $cat[0]->name ); ?></span><?php endif; ?>
									<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
								</p>
								<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<p><?php echo esc_html( get_the_excerpt() ); ?></p>
								<span class="card__more" aria-hidden="true"><?php esc_html_e( 'Leggi', 'hamza-theme' ); ?></span>
							</div>
						</article>
					<?php endwhile; wp_reset_postdata(); ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<!-- Lingue: fascia compatta, prima della mappa -->
	<section class="section section--soft lang-strip" aria-labelledby="lingue-title">
		<div class="container lang-strip__inner">
			<div class="lang-strip__text">
				<h2 id="lingue-title" class="h3"><?php esc_html_e( 'Assistenza nella tua lingua', 'hamza-theme' ); ?></h2>
				<p><?php esc_html_e( 'Spieghiamo ogni passaggio della pratica nella lingua che conosci meglio.', 'hamza-theme' ); ?></p>
			</div>
			<ul class="lang-chips">
				<?php foreach ( $humza_home_langs as $humza_home_lang ) : ?>
					<li class="lang-chip" lang="<?php echo esc_attr( $humza_home_lang['lang'] ); ?>"<?php echo $humza_home_lang['rtl'] ? ' dir="rtl"' : ''; ?>><?php echo esc_html( $humza_home_lang['name'] ); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>

	<!-- Dove siamo + contatto (una sola volta) -->
	<section class="section map-section" aria-labelledby="dove-title">
		<div class="container">
			<div class="section-head">
				<span class="stamp"><?php esc_html_e( 'Dove siamo', 'hamza-theme' ); ?></span>
				<h2 id="dove-title"><?php echo esc_html( humza_biz( 'street' ) . ', ' . humza_biz( 'cap' ) . ' ' . humza_biz( 'city' ) ); ?></h2>
				<p><?php echo esc_html( humza_biz( 'days' ) ); ?>: <?php echo esc_html( humza_biz( 'hours_am' ) ); ?> / <?php echo esc_html( humza_biz( 'hours_pm' ) ); ?> &middot; <?php esc_html_e( 'Domenica chiuso', 'hamza-theme' ); ?></p>
			</div>
			<?php get_template_part( 'parts/map-consent' ); ?>
			<div class="btn-row section-actions">
				<a class="btn btn--primary btn--block-mobile" href="<?php echo esc_url( $humza_prenota ); ?>"><?php esc_html_e( 'Prenota appuntamento', 'hamza-theme' ); ?></a>
				<a class="btn btn--ghost btn--block-mobile" href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>"><?php esc_html_e( 'Tutti i contatti', 'hamza-theme' ); ?></a>
			</div>
		</div>
	</section>

</main>

<?php get_footer(); ?>
