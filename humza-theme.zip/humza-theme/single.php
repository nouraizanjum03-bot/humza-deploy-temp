<?php
/**
 * Articolo singolo "Novità": hero con categoria e date leggibili, immagine in
 * evidenza, contenuto in .prose (70ch) + sidebar CTA, altre novità e
 * navigazione precedente/successivo con etichette parlanti.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="main">

	<?php while ( have_posts() ) : the_post(); ?>
		<?php
		$humza_posts_page_id = (int) get_option( 'page_for_posts' );
		$humza_blog_title    = $humza_posts_page_id ? get_the_title( $humza_posts_page_id ) : __( 'Novità', 'hamza-theme' );
		$humza_blog_url      = $humza_posts_page_id ? get_permalink( $humza_posts_page_id ) : home_url( '/' );

		// "Aggiornato il" solo se la modifica è di almeno un giorno dopo la pubblicazione.
		$humza_show_updated = ( get_the_modified_time( 'U' ) - get_the_time( 'U' ) ) > DAY_IN_SECONDS;

		// Tempo di lettura stimato: ~200 parole al minuto, minimo 1.
		$humza_words   = count( preg_split( '/\s+/u', trim( wp_strip_all_tags( get_post_field( 'post_content', get_the_ID() ) ) ), -1, PREG_SPLIT_NO_EMPTY ) );
		$humza_minutes = max( 1, (int) ceil( $humza_words / 200 ) );

		$humza_cat = get_the_category();
		?>

		<article <?php post_class(); ?>>

			<header class="page-hero">
				<div class="container">
					<?php if ( function_exists( 'humza_breadcrumb' ) ) : ?>
						<?php humza_breadcrumb(); ?>
					<?php else : ?>
						<nav class="breadcrumb" aria-label="<?php esc_attr_e( 'Percorso di navigazione', 'hamza-theme' ); ?>">
							<ol>
								<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'hamza-theme' ); ?></a></li>
								<li><a href="<?php echo esc_url( $humza_blog_url ); ?>"><?php echo esc_html( $humza_blog_title ); ?></a></li>
								<li aria-current="page"><?php the_title(); ?></li>
							</ol>
						</nav>
					<?php endif; ?>

					<?php if ( $humza_cat ) : ?>
						<span class="stamp"><?php echo esc_html( $humza_cat[0]->name ); ?></span>
					<?php endif; ?>

					<h1><?php the_title(); ?></h1>

					<ul class="post-meta">
						<li>
							<?php esc_html_e( 'Pubblicato il', 'hamza-theme' ); ?>
							<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
						</li>
						<?php if ( $humza_show_updated ) : ?>
							<li>
								<span class="badge-update">
									<?php esc_html_e( 'Aggiornato il', 'hamza-theme' ); ?>
									<time datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>"><?php echo esc_html( get_the_modified_date( 'j F Y' ) ); ?></time>
								</span>
							</li>
						<?php endif; ?>
						<li>
							<?php
							/* translators: %d: minuti di lettura stimati. */
							echo esc_html( sprintf( _n( 'Lettura: %d minuto', 'Lettura: %d minuti', $humza_minutes, 'hamza-theme' ), $humza_minutes ) );
							?>
						</li>
					</ul>
				</div>
			</header>

			<div class="container layout-sidebar">

				<div class="prose">
					<?php if ( has_post_thumbnail() ) : ?>
						<figure class="post-featured">
							<?php the_post_thumbnail( 'large', array( 'loading' => 'eager' ) ); ?>
							<?php if ( '' !== trim( (string) get_the_post_thumbnail_caption() ) ) : ?>
								<figcaption><?php echo esc_html( get_the_post_thumbnail_caption() ); ?></figcaption>
							<?php endif; ?>
						</figure>
					<?php endif; ?>

					<?php the_content(); ?>
					<?php
					wp_link_pages( array(
						'before' => '<nav class="page-links" aria-label="' . esc_attr__( 'Pagine dell\'articolo', 'hamza-theme' ) . '">' . esc_html__( 'Pagine:', 'hamza-theme' ) . ' ',
						'after'  => '</nav>',
					) );
					?>
				</div>

				<aside aria-labelledby="post-aside-title">
					<h2 id="post-aside-title" class="screen-reader-text"><?php esc_html_e( 'Contatti rapidi e altre novità', 'hamza-theme' ); ?></h2>
					<div class="sticky-aside">

						<div class="aside-box aside-box--navy">
							<h3><?php esc_html_e( 'Hai una pratica simile?', 'hamza-theme' ); ?></h3>
							<p><?php esc_html_e( 'Parliamone: ti diciamo subito documenti, tempi e costi, nella tua lingua.', 'hamza-theme' ); ?></p>
							<?php
							// Servizio correlato opzionale: ID pagina nel meta 'humza_related_service'.
							$humza_related_id = (int) get_post_meta( get_the_ID(), 'humza_related_service', true );
							if ( $humza_related_id && 'publish' === get_post_status( $humza_related_id ) ) :
								?>
								<a class="btn btn--ghost-light" href="<?php echo esc_url( get_permalink( $humza_related_id ) ); ?>">
									<?php
									/* translators: %s: titolo del servizio correlato. */
									echo esc_html( sprintf( __( 'Scopri: %s', 'hamza-theme' ), get_the_title( $humza_related_id ) ) );
									?>
								</a>
							<?php endif; ?>
							<a class="btn btn--primary" href="<?php echo esc_url( home_url( '/prenota/' ) ); ?>"><?php esc_html_e( 'Prenota appuntamento', 'hamza-theme' ); ?></a>
							<a class="btn btn--wa" href="<?php echo esc_url( humza_wa_href( sprintf( /* translators: %s: titolo dell'articolo. */ __( 'Ciao, ho letto "%s" e vorrei informazioni.', 'hamza-theme' ), wp_specialchars_decode( get_the_title(), ENT_QUOTES ) ) ) ); ?>" target="_blank" rel="noopener noreferrer">
								<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>WhatsApp<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
							</a>
						</div>

						<?php
						$humza_recent = new WP_Query( array(
							'posts_per_page'      => 3,
							'post__not_in'        => array( get_the_ID() ),
							'ignore_sticky_posts' => true,
							'no_found_rows'       => true,
						) );
						if ( $humza_recent->have_posts() ) :
							?>
							<div class="aside-box">
								<h3><?php esc_html_e( 'Altre novità', 'hamza-theme' ); ?></h3>
								<ul class="mini-list">
									<?php while ( $humza_recent->have_posts() ) : $humza_recent->the_post(); ?>
										<li>
											<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
											<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
										</li>
									<?php endwhile; wp_reset_postdata(); ?>
								</ul>
							</div>
						<?php endif; ?>

					</div>
				</aside>

			</div>

			<div class="container">
				<div class="btn-row section-note">
					<a class="btn btn--ghost" href="<?php echo esc_url( $humza_blog_url ); ?>">
						<?php
						/* translators: %s: titolo della pagina archivio (di norma "Novità"). */
						echo esc_html( sprintf( __( 'Torna a %s', 'hamza-theme' ), $humza_blog_title ) );
						?>
					</a>
				</div>

				<?php
				the_post_navigation( array(
					'prev_text'          => '<span class="post-nav__label">' . esc_html__( 'Articolo precedente', 'hamza-theme' ) . '</span><span class="post-nav__title">%title</span>',
					'next_text'          => '<span class="post-nav__label">' . esc_html__( 'Articolo successivo', 'hamza-theme' ) . '</span><span class="post-nav__title">%title</span>',
					'aria_label'         => esc_html__( 'Altri articoli', 'hamza-theme' ),
					'screen_reader_text' => esc_html__( 'Continua a leggere', 'hamza-theme' ),
				) );
				?>
			</div>

		</article>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>
