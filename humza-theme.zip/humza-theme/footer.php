<?php
/**
 * Footer: CTA contestuale + colonne + riga legale con P.IVA + barra azioni mobile.
 *
 * Contratto con assets/css/main.css:
 * - .mobile-actions : barra fissa in fondo sotto 768px (Chiama / WhatsApp / Prenota).
 *   Sotto 768px sostituisce .wa-float (che va nascosto) e il body riceve
 *   spazio in fondo; il cookie banner resta sopra la barra.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

// CTA pre-footer: mai su prenota/contatti (autoreferenziale) né su pagine legali.
$humza_hide_cta = is_page( array( 'prenota', 'contatti', 'privacy-policy', 'cookie-policy' ) ) || is_front_page();
$humza_wa_msg   = __( 'Ciao, ho bisogno di informazioni.', 'hamza-theme' );
$humza_contatti = home_url( '/contatti/' );
$humza_prenota  = home_url( '/prenota/' );
?>

<?php if ( ! $humza_hide_cta ) : ?>
<section class="cta-banner" aria-labelledby="cta-banner-title">
	<div class="container cta-banner__inner">
		<h2 id="cta-banner-title"><?php esc_html_e( 'Hai una pratica da sbrigare?', 'hamza-theme' ); ?></h2>
		<p><?php esc_html_e( 'Prenota un appuntamento o scrivici su WhatsApp: ti diciamo subito documenti, tempi e costi.', 'hamza-theme' ); ?></p>
		<div class="cta-banner__actions">
			<a class="btn btn--navy btn--block-mobile" href="<?php echo esc_url( $humza_prenota ); ?>"><?php esc_html_e( 'Prenota appuntamento', 'hamza-theme' ); ?></a>
			<a class="btn btn--wa btn--block-mobile" href="<?php echo esc_url( humza_wa_href( __( 'Ciao, ho bisogno di informazioni su una pratica.', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo humza_icon( 'ic-wa', 20 ); ?>WhatsApp<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span></a>
		</div>
	</div>
</section>
<?php endif; ?>

<footer class="site-footer">
	<div class="container">
		<div class="footer-grid">
			<div class="footer-brand">
				<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/logo-humza-light.svg' ); ?>" alt="<?php echo esc_attr( humza_biz( 'name' ) ); ?>" width="300" height="56">
				<p><?php esc_html_e( 'Centro pratiche a Brescia: assistenza fiscale, immigrazione, consolati, visti e traduzioni. Parliamo la tua lingua.', 'hamza-theme' ); ?></p>
				<ul class="footer-social" aria-label="Social">
					<?php if ( humza_biz( 'tiktok' ) ) : ?>
					<li><a href="<?php echo esc_url( humza_biz( 'tiktok' ) ); ?>" target="_blank" rel="noopener noreferrer">TikTok<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span></a></li>
					<?php endif; ?>
					<?php if ( humza_biz( 'gbp' ) ) : ?>
					<li><a href="<?php echo esc_url( humza_biz( 'gbp' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Recensioni Google', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span></a></li>
					<?php endif; ?>
				</ul>
			</div>

			<nav aria-label="<?php esc_attr_e( 'Servizi', 'hamza-theme' ); ?>">
				<h3><?php esc_html_e( 'Servizi', 'hamza-theme' ); ?></h3>
				<?php
				wp_nav_menu( array(
					'theme_location' => 'footer-servizi',
					'container'      => false,
					'menu_class'     => '',
					'fallback_cb'    => 'humza_footer_services_fallback',
					'depth'          => 1,
				) );
				?>
			</nav>

			<nav aria-label="<?php esc_attr_e( 'Link utili', 'hamza-theme' ); ?>">
				<h3><?php esc_html_e( 'Link utili', 'hamza-theme' ); ?></h3>
				<?php
				wp_nav_menu( array(
					'theme_location' => 'footer-utili',
					'container'      => false,
					'menu_class'     => '',
					'fallback_cb'    => 'humza_footer_links_fallback',
					'depth'          => 1,
				) );
				?>
			</nav>

			<div>
				<h3><?php esc_html_e( 'Contatti e orari', 'hamza-theme' ); ?></h3>
				<ul class="footer-contact">
					<li><?php echo humza_icon( 'ic-mappa', 17 ); ?><span><?php echo esc_html( humza_biz( 'street' ) . ', ' . humza_biz( 'cap' ) . ' ' . humza_biz( 'city' ) . ' (' . humza_biz( 'prov' ) . ')' ); ?></span></li>
					<?php if ( humza_biz( 'phone1' ) ) : ?>
					<li><?php echo humza_icon( 'ic-tel', 17 ); ?><a href="<?php echo esc_url( humza_phone_href( humza_biz( 'phone1' ) ) ); ?>"><?php echo esc_html( humza_biz( 'phone1' ) ); ?></a></li>
					<?php endif; ?>
					<?php if ( humza_biz( 'phone2' ) ) : ?>
					<li><?php echo humza_icon( 'ic-tel', 17 ); ?><a href="<?php echo esc_url( humza_phone_href( humza_biz( 'phone2' ) ) ); ?>"><?php echo esc_html( humza_biz( 'phone2' ) ); ?></a></li>
					<?php endif; ?>
					<li><?php echo humza_icon( 'ic-mail', 17 ); ?><a href="mailto:<?php echo esc_attr( humza_biz( 'email' ) ); ?>"><?php echo esc_html( humza_biz( 'email' ) ); ?></a></li>
					<li><?php echo humza_icon( 'ic-orari', 17 ); ?>
						<span>
							<?php echo esc_html( humza_biz( 'days' ) ); ?>: <?php echo esc_html( humza_biz( 'hours_am' ) ); ?> / <?php echo esc_html( humza_biz( 'hours_pm' ) ); ?><br>
							<?php esc_html_e( 'Domenica: chiuso', 'hamza-theme' ); ?>
						</span>
					</li>
					<li class="footer-directions"><?php echo humza_icon( 'ic-mappa', 17 ); ?><a href="<?php echo esc_url( $humza_contatti ); ?>"><?php esc_html_e( 'Come raggiungerci', 'hamza-theme' ); ?></a></li>
				</ul>
			</div>
		</div>

		<div class="footer-legal">
			<span>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( humza_biz( 'legalname' ) ); ?> &middot; <span class="piva"><?php esc_html_e( 'P.IVA', 'hamza-theme' ); ?> <?php echo esc_html( humza_biz( 'piva' ) ); ?></span></span>
			<span>
				<a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>">Privacy Policy</a>
				&nbsp;&middot;&nbsp;
				<a href="<?php echo esc_url( home_url( '/cookie-policy/' ) ); ?>">Cookie Policy</a>
				&nbsp;&middot;&nbsp;
				<button type="button" class="cookie-reopen link-plain"><?php esc_html_e( 'Impostazioni cookie', 'hamza-theme' ); ?></button>
			</span>
		</div>
	</div>
</footer>

<?php /* Barra azioni mobile: le tre cose che serve fare da telefono, sempre a portata di pollice. */ ?>
<nav class="mobile-actions" aria-label="<?php esc_attr_e( 'Azioni rapide', 'hamza-theme' ); ?>">
	<?php if ( humza_biz( 'phone1' ) ) : ?>
	<a class="mobile-actions__item" href="<?php echo esc_url( humza_phone_href( humza_biz( 'phone1' ) ) ); ?>">
		<?php echo humza_icon( 'ic-tel', 22 ); ?>
		<span><?php esc_html_e( 'Chiama', 'hamza-theme' ); ?></span>
	</a>
	<?php endif; ?>
	<a class="mobile-actions__item" href="<?php echo esc_url( humza_wa_href( $humza_wa_msg ) ); ?>" target="_blank" rel="noopener noreferrer">
		<?php echo humza_icon( 'ic-wa', 22 ); ?>
		<span>WhatsApp</span>
		<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
	</a>
	<a class="mobile-actions__item" href="<?php echo esc_url( $humza_prenota ); ?>">
		<?php echo humza_icon( 'ic-orari', 22 ); ?>
		<span><?php esc_html_e( 'Prenota', 'hamza-theme' ); ?></span>
	</a>
</nav>

<a class="wa-float" href="<?php echo esc_url( humza_wa_href( $humza_wa_msg ) ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Scrivici su WhatsApp (si apre in una nuova scheda)', 'hamza-theme' ); ?>">
	<?php echo humza_icon( 'ic-wa', 30 ); ?>
</a>

<div class="cookie-banner" role="dialog" aria-modal="false" aria-labelledby="cookie-title" aria-describedby="cookie-desc" hidden>
	<div class="cookie-banner__inner">
		<p id="cookie-desc"><span id="cookie-title" class="screen-reader-text"><?php esc_html_e( 'Preferenze cookie', 'hamza-theme' ); ?></span><?php esc_html_e( 'Usiamo cookie tecnici per far funzionare il sito. Con il tuo consenso usiamo anche cookie di terze parti per mostrare la mappa di Google.', 'hamza-theme' ); ?> <a href="<?php echo esc_url( home_url( '/cookie-policy/' ) ); ?>"><?php esc_html_e( 'Scopri di più', 'hamza-theme' ); ?></a></p>
		<div class="cookie-banner__actions">
			<button type="button" class="btn btn--primary cookie-accept-all"><?php esc_html_e( 'Accetta tutti', 'hamza-theme' ); ?></button>
			<button type="button" class="btn btn--ghost-light cookie-accept-necessary"><?php esc_html_e( 'Solo necessari', 'hamza-theme' ); ?></button>
		</div>
	</div>
</div>

<?php wp_footer(); ?>
</body>
</html>
