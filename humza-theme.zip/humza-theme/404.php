<?php
/**
 * Pagina 404: messaggio gentile in italiano semplice, uscite chiare
 * (home, servizi, WhatsApp) e l'elenco reale dei servizi, così chi arriva
 * da un link vecchio trova subito la pagina giusta.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="main">

	<section class="error-404" aria-labelledby="error-404-title">
		<div class="container">
			<span class="stamp"><?php esc_html_e( 'Pagina non trovata', 'hamza-theme' ); ?></span>
			<h1 id="error-404-title"><?php esc_html_e( 'Questa pagina non esiste', 'hamza-theme' ); ?></h1>
			<p><?php esc_html_e( 'Forse il link è vecchio, oppure c’è un piccolo errore nell’indirizzo. Nessun problema: da qui puoi tornare alla home, guardare i nostri servizi o scriverci su WhatsApp.', 'hamza-theme' ); ?></p>
			<div class="btn-row">
				<a class="btn btn--primary btn--block-mobile" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Torna alla home', 'hamza-theme' ); ?></a>
				<a class="btn btn--wa btn--block-mobile" href="<?php echo esc_url( humza_wa_href( __( 'Ciao, non trovo una pagina sul vostro sito: potete aiutarmi?', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer">
					<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>WhatsApp<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
				</a>
				<a class="btn btn--ghost btn--block-mobile" href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>"><?php esc_html_e( 'Contatti e orari', 'hamza-theme' ); ?></a>
			</div>
		</div>
	</section>

	<section class="section section--paper" aria-labelledby="error-404-servizi-title">
		<div class="container">
			<div class="section-head">
				<h2 id="error-404-servizi-title"><?php esc_html_e( 'Forse cercavi uno di questi servizi', 'hamza-theme' ); ?></h2>
				<p><?php esc_html_e( 'Scegli il servizio che ti interessa: trovi documenti, tempi e come prenotare.', 'hamza-theme' ); ?></p>
			</div>
			<?php get_template_part( 'parts/services-grid' ); ?>
		</div>
	</section>

</main>

<?php
get_footer();
