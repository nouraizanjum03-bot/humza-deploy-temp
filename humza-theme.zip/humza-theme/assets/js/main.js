/**
 * Humza Multiservizi — main.js v2.0.0
 * Vanilla JS, zero dipendenze. Ogni modulo si attiva solo se il markup
 * relativo esiste nella pagina; un errore in un modulo non blocca gli altri.
 */
(function () {
	'use strict';

	var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

	var FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

	/* ---------- 1) Menu mobile (drawer accessibile) ---------- */
	function initMobileMenu() {
		var toggle = document.querySelector('.nav-toggle');
		var menu = document.getElementById('mobile-menu');
		if (!toggle || !menu) {
			return;
		}
		var panel = menu.querySelector('.mobile-menu__panel');
		var backdrop = menu.querySelector('.mobile-menu__backdrop');
		var closeBtn = menu.querySelector('.mobile-menu__close');
		if (!panel) {
			return;
		}
		var savedScrollY = 0;

		function isOpen() {
			return menu.classList.contains('is-open');
		}

		function open() {
			// Scroll lock iOS-safe: body fissato alla posizione corrente
			// (vedi body.menu-open in main.css), non solo overflow:hidden.
			savedScrollY = window.scrollY || window.pageYOffset || 0;
			document.body.style.setProperty('--scroll-lock-top', String(-savedScrollY) + 'px');
			document.body.classList.add('menu-open');
			menu.hidden = false;
			menu.classList.add('is-open');
			toggle.setAttribute('aria-expanded', 'true');
			(closeBtn || panel).focus();
		}

		function close() {
			menu.classList.remove('is-open');
			menu.hidden = true;
			toggle.setAttribute('aria-expanded', 'false');
			document.body.classList.remove('menu-open');
			document.body.style.removeProperty('--scroll-lock-top');
			window.scrollTo(0, savedScrollY);
			toggle.focus();
		}

		toggle.addEventListener('click', function () {
			if (isOpen()) {
				close();
			} else {
				open();
			}
		});
		if (backdrop) {
			backdrop.addEventListener('click', close);
		}
		if (closeBtn) {
			closeBtn.addEventListener('click', close);
		}

		// La scelta di una voce (o della lingua) chiude il drawer.
		menu.addEventListener('click', function (e) {
			if (e.target.closest('a')) {
				close();
			}
		});

		document.addEventListener('keydown', function (e) {
			if (!isOpen()) {
				return;
			}
			if (e.key === 'Escape') {
				e.preventDefault();
				close();
				return;
			}
			if (e.key !== 'Tab') {
				return;
			}
			// Focus trap: Tab resta dentro il pannello (aria-modal nel markup).
			var focusables = Array.prototype.filter.call(
				panel.querySelectorAll(FOCUSABLE),
				function (el) { return el.offsetParent !== null; }
			);
			if (!focusables.length) {
				return;
			}
			var first = focusables[0];
			var last = focusables[focusables.length - 1];
			if (!panel.contains(document.activeElement)) {
				e.preventDefault();
				first.focus();
			} else if (e.shiftKey && document.activeElement === first) {
				e.preventDefault();
				last.focus();
			} else if (!e.shiftKey && document.activeElement === last) {
				e.preventDefault();
				first.focus();
			}
		});
	}

	/* ---------- 2) Header sticky: ombra oltre 8px di scroll ---------- */
	function initStickyHeader() {
		var header = document.querySelector('.site-header');
		if (!header) {
			return;
		}
		var ticking = false;

		function update() {
			header.classList.toggle('is-stuck', (window.scrollY || 0) > 8);
			ticking = false;
		}

		window.addEventListener('scroll', function () {
			if (!ticking) {
				ticking = true;
				window.requestAnimationFrame(update);
			}
		}, { passive: true });
		update();
	}

	/* ---------- 3) Reveal on scroll ([data-animate] → .is-inview) ---------- */
	function initReveal() {
		var items = document.querySelectorAll('[data-animate]');
		if (!items.length) {
			return;
		}
		if (reducedMotion.matches || !('IntersectionObserver' in window)) {
			items.forEach(function (el) { el.classList.add('is-inview'); });
			return;
		}
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (entry.isIntersecting) {
					entry.target.classList.add('is-inview');
					io.unobserve(entry.target);
				}
			});
		}, { threshold: 0.15 });
		items.forEach(function (el) { io.observe(el); });

		// Rete di sicurezza: il contenuto non deve MAI restare nascosto
		// (tab in background, observer che non scatta, ecc.).
		window.setTimeout(function () {
			items.forEach(function (el) { el.classList.add('is-inview'); });
			io.disconnect();
		}, 1800);
	}

	/* ---------- 4) FAQ accordion (progressive enhancement) ----------
	 * Il template stampa dentro .faq-source h2 (categorie), h3 (domande) e
	 * paragrafi (risposte), tutto visibile senza JS. Qui il contenuto viene
	 * ristrutturato in accordion: h3 → button.faq-question, fratelli → .faq-answer.
	 */
	var faqUid = 0;

	function buildFaqItem(h3, answerNodes, openNow) {
		var item = document.createElement('div');
		item.className = 'faq-item';

		var btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'faq-question';
		var label = document.createElement('span');
		while (h3.firstChild) {
			label.appendChild(h3.firstChild);
		}
		btn.appendChild(label);
		btn.insertAdjacentHTML('beforeend', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M6 9l6 6 6-6"/></svg>');

		var answer = document.createElement('div');
		answer.className = 'faq-answer';
		faqUid += 1;
		answer.id = 'faq-answer-' + faqUid;
		answerNodes.forEach(function (node) { answer.appendChild(node); });

		btn.setAttribute('aria-expanded', openNow ? 'true' : 'false');
		btn.setAttribute('aria-controls', answer.id);
		answer.hidden = !openNow;

		btn.addEventListener('click', function () {
			var expanded = btn.getAttribute('aria-expanded') === 'true';
			btn.setAttribute('aria-expanded', expanded ? 'false' : 'true');
			answer.hidden = expanded;
		});

		// Il bottone vive dentro un h3: la gerarchia dei titoli resta
		// navigabile da screen reader (pattern accordion ARIA APG).
		var heading = document.createElement('h3');
		heading.className = 'faq-heading';
		heading.appendChild(btn);

		item.appendChild(heading);
		item.appendChild(answer);
		return item;
	}

	function initFaq() {
		document.querySelectorAll('.faq-source').forEach(function (source) {
			var nodes = Array.prototype.slice.call(source.children);
			var frag = document.createDocumentFragment();
			var firstInSource = true;
			var i = 0;
			while (i < nodes.length) {
				var node = nodes[i];
				if (node.tagName === 'H2') {
					// Le categorie restano heading, fuori dagli item.
					node.classList.add('faq-cat');
					frag.appendChild(node);
					i += 1;
					continue;
				}
				if (node.tagName !== 'H3') {
					frag.appendChild(node);
					i += 1;
					continue;
				}
				var answerNodes = [];
				i += 1;
				while (i < nodes.length && nodes[i].tagName !== 'H3' && nodes[i].tagName !== 'H2') {
					answerNodes.push(nodes[i]);
					i += 1;
				}
				frag.appendChild(buildFaqItem(node, answerNodes, firstInSource));
				firstInSource = false;
				node.remove();
			}
			source.appendChild(frag);
		});
	}

	/* ---------- 5) Mappa Google con consenso ---------- */
	function initMapConsent() {
		var containers = document.querySelectorAll('.map-container');
		if (!containers.length) {
			return;
		}

		function reveal(withFocus) {
			var firstFrame = null;
			containers.forEach(function (container) {
				var frame = container.querySelector('iframe');
				if (frame && !frame.getAttribute('src') && window.humzaTheme && window.humzaTheme.mapsEmbed) {
					frame.src = window.humzaTheme.mapsEmbed;
				}
				container.hidden = false;
				if (frame && !firstFrame) {
					firstFrame = frame;
				}
			});
			document.querySelectorAll('.map-placeholder').forEach(function (ph) {
				ph.hidden = true;
			});
			if (withFocus && firstFrame) {
				firstFrame.setAttribute('tabindex', '-1');
				firstFrame.focus();
			}
		}

		document.querySelectorAll('.map-accept-cookies').forEach(function (btn) {
			btn.addEventListener('click', function () {
				if (window.humzaConsent && typeof window.humzaConsent.grant === 'function') {
					window.humzaConsent.grant('functional');
				}
				reveal(true);
			});
		});

		// Consenso già dato in una visita precedente: mappa subito visibile.
		if (window.humzaConsent && typeof window.humzaConsent.has === 'function' && window.humzaConsent.has('functional')) {
			reveal(false);
		}

		// Consenso concesso dal banner in questa stessa visita: rivela senza reload.
		if (window.humzaConsent && typeof window.humzaConsent.onChange === 'function') {
			window.humzaConsent.onChange(function (cat, granted) {
				if (cat === 'functional' && granted) {
					reveal(false);
				}
			});
		}
	}

	/* ---------- 6) Tabs del portale clienti (se presenti) ---------- */
	function initTabs() {
		document.querySelectorAll('.tabs').forEach(function (tablist) {
			var tabs = Array.prototype.slice.call(tablist.querySelectorAll('.tab'));
			if (!tabs.length) {
				return;
			}
			var scope = tablist.parentElement || document;
			var fallbackPanels = Array.prototype.slice.call(scope.querySelectorAll('.tabpanel'));
			var panels = tabs.map(function (tab, i) {
				var id = tab.getAttribute('aria-controls');
				return (id && document.getElementById(id)) || fallbackPanels[i] || null;
			});

			tablist.setAttribute('role', 'tablist');

			function activate(index, focusTab) {
				tabs.forEach(function (tab, i) {
					var selected = i === index;
					tab.setAttribute('aria-selected', selected ? 'true' : 'false');
					tab.tabIndex = selected ? 0 : -1; // roving tabindex
					if (panels[i]) {
						panels[i].hidden = !selected;
					}
					if (selected && focusTab) {
						tab.focus();
					}
				});
			}

			tabs.forEach(function (tab, i) {
				tab.setAttribute('role', 'tab');
				var panel = panels[i];
				if (panel) {
					panel.setAttribute('role', 'tabpanel');
					if (!panel.id) {
						panel.id = 'tabpanel-' + (i + 1);
					}
					if (!tab.id) {
						tab.id = panel.id + '-tab';
					}
					tab.setAttribute('aria-controls', panel.id);
					panel.setAttribute('aria-labelledby', tab.id);
					if (!panel.hasAttribute('tabindex')) {
						panel.tabIndex = 0; // il pannello è raggiungibile da tastiera
					}
				}
				tab.addEventListener('click', function () {
					activate(i, false);
				});
				tab.addEventListener('keydown', function (e) {
					var next = null;
					if (e.key === 'ArrowRight') {
						next = (i + 1) % tabs.length;
					} else if (e.key === 'ArrowLeft') {
						next = (i - 1 + tabs.length) % tabs.length;
					} else if (e.key === 'Home') {
						next = 0;
					} else if (e.key === 'End') {
						next = tabs.length - 1;
					}
					if (next === null) {
						return;
					}
					e.preventDefault();
					activate(next, true);
				});
			});

			var initial = tabs.findIndex(function (tab) {
				return tab.getAttribute('aria-selected') === 'true';
			});
			activate(initial > -1 ? initial : 0, false);
		});
	}

	/* ---------- 7) Riapertura preferenze cookie ---------- */
	function initCookieReopen() {
		document.querySelectorAll('.cookie-reopen').forEach(function (btn) {
			btn.addEventListener('click', function () {
				// Ascoltato da cookie-consent.js.
				document.dispatchEvent(new CustomEvent('humza:cookie-reopen'));
			});
		});
	}

	/* ---------- 8) Smooth scroll per anchor interni ---------- */
	function initSmoothScroll() {
		document.addEventListener('click', function (e) {
			if (reducedMotion.matches) {
				return;
			}
			// Click modificati (nuova scheda/finestra) o non-primari: comportamento nativo.
			if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) {
				return;
			}
			var link = e.target.closest('a[href^="#"]');
			if (!link) {
				return;
			}
			var hash = link.getAttribute('href');
			if (hash.length < 2) {
				return;
			}
			var id;
			try {
				id = decodeURIComponent(hash.slice(1));
			} catch (err) {
				id = hash.slice(1);
			}
			var target = document.getElementById(id);
			if (!target) {
				return;
			}
			e.preventDefault();
			target.scrollIntoView({ behavior: 'smooth' }); // scroll-padding-top in CSS compensa l'header
			if (window.history && window.history.pushState) {
				window.history.pushState(null, '', hash);
			}
			// Focus sulla destinazione per chi naviga da tastiera.
			if (!target.hasAttribute('tabindex')) {
				target.setAttribute('tabindex', '-1');
			}
			target.focus({ preventScroll: true });
		});
	}

	/* ---------- 9) Form AJAX (contatti, login, registrazione) ----------
	 * I form postano ad admin-ajax.php e funzionano anche senza JS (POST
	 * nativo). Qui si intercetta il submit per mostrare l'esito in pagina.
	 * Risposte attese: wp_send_json_success/error ({success, data}), con
	 * tolleranza per body "0"/"-1" (azione non registrata / nonce).
	 */
	function bindAjaxForm(formId, msgId, opts) {
		var form = document.getElementById(formId);
		var msg = msgId ? document.getElementById(msgId) : null;
		if (!form) {
			return;
		}
		opts = opts || {};

		function showMsg(ok, text) {
			if (!msg) {
				window.alert(text);
				return;
			}
			msg.textContent = text;
			msg.classList.remove('form-msg--ok', 'form-msg--err');
			msg.classList.add(ok ? 'form-msg--ok' : 'form-msg--err');
			msg.hidden = false;
			msg.setAttribute('tabindex', '-1');
			msg.focus({ preventScroll: false });
		}

		form.addEventListener('submit', function (e) {
			// Validazione nativa prima dell'invio AJAX.
			if (typeof form.reportValidity === 'function' && !form.reportValidity()) {
				e.preventDefault();
				return;
			}
			e.preventDefault();

			var submit = form.querySelector('[type="submit"]');
			var oldLabel = submit ? submit.textContent : '';
			if (submit) {
				submit.disabled = true;
				submit.textContent = 'Invio in corso…';
			}

			var controller = ('AbortController' in window) ? new AbortController() : null;
			var timer = controller ? window.setTimeout(function () { controller.abort(); }, 20000) : null;

			// getAttribute e non form.action: il campo nascosto chiamato "action"
			// (richiesto da admin-ajax) oscura la proprietà del form.
			var endpoint = form.getAttribute('action') || window.location.href;

			fetch(endpoint, {
				method: 'POST',
				body: new FormData(form),
				credentials: 'same-origin',
				signal: controller ? controller.signal : undefined
			}).then(function (res) {
				return res.text().then(function (body) {
					var data = null;
					try { data = JSON.parse(body); } catch (err) { /* body non JSON */ }
					if (data && data.success) {
						var okText = (data.data && (data.data.message || data.data.msg)) ||
							opts.okMessage || 'Richiesta inviata. Ti risponderemo al più presto.';
						if (opts.onSuccess) {
							opts.onSuccess(data);
						} else {
							showMsg(true, okText);
							form.reset();
						}
						return;
					}
					var errText = (data && data.data && (data.data.message || data.data.msg)) ||
						(body === '0' || body === '-1' || res.status === 403
							? 'La sessione è scaduta: ricarica la pagina e riprova.'
							: 'Qualcosa è andato storto. Riprova, oppure scrivici su WhatsApp.');
					showMsg(false, errText);
				});
			}).catch(function () {
				showMsg(false, 'Connessione non riuscita. Controlla la rete e riprova.');
			}).finally(function () {
				if (timer) {
					window.clearTimeout(timer);
				}
				if (submit) {
					submit.disabled = false;
					submit.textContent = oldLabel;
				}
			});
		});
	}

	function initAjaxForms() {
		bindAjaxForm('hamza-contact-form', 'contact-form-message', {
			okMessage: 'Messaggio inviato. Ti rispondiamo il prima possibile.'
		});
		bindAjaxForm('hamza-register-form', 'register-form-message', {
			okMessage: 'Registrazione completata. Controlla la tua email.'
		});
		bindAjaxForm('hamza-login-form', 'login-error-msg', {
			onSuccess: function (data) {
				var url = (data.data && data.data.redirect) || window.location.href;
				window.location.assign(url);
			}
		});
	}

	/* ---------- Avvio ---------- */
	function initAll() {
		[
			initMobileMenu,
			initStickyHeader,
			initReveal,
			initFaq,
			initMapConsent,
			initTabs,
			initCookieReopen,
			initSmoothScroll,
			initAjaxForms
		].forEach(function (mod) {
			try {
				mod();
			} catch (err) {
				if (window.console && window.console.error) {
					window.console.error('[humza-theme]', err);
				}
			}
		});
	}

	// Con defer questo file gira a readyState 'interactive', PRIMA di
	// cookie-consent.js: si attende DOMContentLoaded (che scatta dopo tutti
	// i defer) così window.humzaConsent esiste quando initMapConsent lo legge.
	var started = false;

	function start() {
		if (started) {
			return;
		}
		started = true;
		initAll();
	}

	if (document.readyState === 'complete') {
		start();
	} else {
		document.addEventListener('DOMContentLoaded', start);
		// Rete di sicurezza: se un ottimizzatore ritarda l'esecuzione di
		// questo script a DOPO DOMContentLoaded (readyState ancora
		// 'interactive'), il listener sopra non scatterebbe mai.
		window.addEventListener('load', start);
	}
})();
