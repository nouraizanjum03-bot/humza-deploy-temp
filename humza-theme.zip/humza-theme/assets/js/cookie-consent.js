/**
 * Humza Multiservizi — Consenso cookie v2 (vanilla, nessuna dipendenza).
 *
 * API globale: window.humzaConsent = { has(cat), grant(cat), revoke(cat), onChange(fn) }
 * Categorie: 'necessary' (sempre attiva) e 'functional' (mappa Google).
 *
 * Persistenza: localStorage 'humzaConsentV2' + cookie specchio omonimo
 * (Secure su https, SameSite=Lax, 180 giorni). Migra la scelta legacy
 * 'hamza_cookie_consent' (cookie) / 'hamzaCookieConsent' (localStorage).
 *
 * Banner: .cookie-banner in footer.php (hidden nel markup). Mostrato solo
 * se non esiste una scelta salvata: rimuove hidden e aggiunge .is-visible.
 * Non ruba mai il focus e non tocca mai aria-hidden (il banner e' in fondo
 * al DOM, role="dialog" non modale: raggiungibile con Tab senza trappole).
 * L'evento 'humza:cookie-reopen' (emesso da main.js sul bottone
 * "Impostazioni cookie" del footer) lo riapre.
 */
(function () {
	'use strict';

	var STORAGE_KEY = 'humzaConsentV2';
	var MAX_AGE = 180 * 24 * 60 * 60; /* 180 giorni in secondi */
	var LEGACY_COOKIE = 'hamza_cookie_consent';
	var LEGACY_STORAGE = 'hamzaCookieConsent';

	var listeners = [];
	var banner = null;
	var currentState = null; /* null = nessuna scelta salvata */

	/* ---------- Storage (sempre in try/catch: private mode, cookie off) ---------- */

	function lsGet(key) {
		try { return window.localStorage.getItem(key); } catch (e) { return null; }
	}

	function lsSet(key, value) {
		try { window.localStorage.setItem(key, value); } catch (e) { /* negato o pieno: resta il cookie specchio */ }
	}

	function lsRemove(key) {
		try { window.localStorage.removeItem(key); } catch (e) { /* ignora */ }
	}

	function cookieGet(name) {
		try {
			var pairs = document.cookie ? document.cookie.split(';') : [];
			for (var i = 0; i < pairs.length; i++) {
				var pair = pairs[i].trim();
				if (pair.indexOf(name + '=') === 0) {
					return decodeURIComponent(pair.substring(name.length + 1));
				}
			}
		} catch (e) { /* decodeURIComponent puo' lanciare su valori corrotti */ }
		return null;
	}

	function cookieSet(name, value) {
		var parts = [
			name + '=' + encodeURIComponent(value),
			'path=/',
			'max-age=' + MAX_AGE,
			'SameSite=Lax'
		];
		/* Secure solo su https: su http (staging locale) il cookie verrebbe rifiutato. */
		if (window.location.protocol === 'https:') {
			parts.push('Secure');
		}
		try { document.cookie = parts.join('; '); } catch (e) { /* cookie negati: resta il localStorage */ }
	}

	function cookieDelete(name) {
		try { document.cookie = name + '=; path=/; max-age=0; SameSite=Lax'; } catch (e) { /* ignora */ }
	}

	/* ---------- Stato ---------- */

	function parseState(raw) {
		if (!raw) { return null; }
		try {
			var data = JSON.parse(raw);
			if (data && typeof data === 'object' && typeof data.functional === 'boolean') {
				return {
					v: 2,
					necessary: true,
					functional: data.functional,
					ts: typeof data.ts === 'number' ? data.ts : Date.now()
				};
			}
		} catch (e) { /* JSON corrotto: trattato come assenza di scelta */ }
		return null;
	}

	function persist(state) {
		var raw = JSON.stringify(state);
		lsSet(STORAGE_KEY, raw);
		cookieSet(STORAGE_KEY, raw);
	}

	/* Migra la scelta del vecchio sito, se leggibile, e pulisce i residui. */
	function migrateLegacy() {
		var raw = cookieGet(LEGACY_COOKIE);
		if (raw === null) { raw = lsGet(LEGACY_STORAGE); }
		if (!raw) { return null; }

		var functional = null;
		if (raw === 'all' || raw === 'accepted' || raw === 'true') {
			functional = true;
		} else if (raw === 'necessary' || raw === 'rejected' || raw === 'false') {
			functional = false;
		} else {
			var parsed = parseState(raw);
			if (parsed) { functional = parsed.functional; }
		}
		if (functional === null) { return null; }

		var state = { v: 2, necessary: true, functional: functional, ts: Date.now() };
		persist(state);
		cookieDelete(LEGACY_COOKIE);
		lsRemove(LEGACY_STORAGE);
		return state;
	}

	function loadState() {
		var state = parseState(lsGet(STORAGE_KEY)) || parseState(cookieGet(STORAGE_KEY));
		if (state) {
			/* Riallinea i due supporti e rinnova la scadenza del cookie specchio. */
			persist(state);
			return state;
		}
		return migrateLegacy();
	}

	function snapshot() {
		return {
			necessary: true,
			functional: !!(currentState && currentState.functional)
		};
	}

	function emit(category, granted) {
		var state = snapshot();
		for (var i = 0; i < listeners.length; i++) {
			try {
				listeners[i](category, granted, state);
			} catch (e) {
				if (window.console && window.console.error) {
					window.console.error('humzaConsent: errore in un listener onChange', e);
				}
			}
		}
		/* Equivalente DOM per chi preferisce addEventListener. */
		try {
			document.dispatchEvent(new CustomEvent('humza:consent-change', {
				detail: { category: category, granted: granted, state: state }
			}));
		} catch (e) { /* CustomEvent assente: nessun danno, i listener sopra bastano */ }
	}

	function setFunctional(granted) {
		var prev = currentState ? currentState.functional : null;
		currentState = { v: 2, necessary: true, functional: granted, ts: Date.now() };
		persist(currentState);
		if (prev !== granted) {
			emit('functional', granted);
		}
	}

	/* Lo stato va letto subito (non a DOM pronto): main.js interroga
	   humzaConsent.has('functional') durante la propria init. */
	currentState = loadState();

	/* ---------- Banner ---------- */

	function showBanner() {
		if (!banner) { return; }
		banner.hidden = false;
		banner.classList.add('is-visible');
		/* Nessun focus() qui: il banner non e' modale e non deve interrompere
		   la navigazione. E' in fondo al DOM, raggiungibile con Tab. */
	}

	function hideBanner() {
		if (!banner) { return; }
		banner.classList.remove('is-visible');
		banner.hidden = true;
	}

	/* ---------- API pubblica ---------- */

	window.humzaConsent = {
		/** true se la categoria e' consentita. 'necessary' e' sempre true. */
		has: function (category) {
			if (category === 'necessary') { return true; }
			if (category === 'functional') { return !!(currentState && currentState.functional); }
			return false;
		},
		/** Concede una categoria e salva la scelta (chiude il banner se aperto). */
		grant: function (category) {
			if (category === 'functional') {
				setFunctional(true);
				hideBanner();
			}
			/* 'necessary' e' sempre attiva: niente da fare. */
		},
		/** Nega una categoria e salva la scelta (chiude il banner se aperto). */
		revoke: function (category) {
			if (category === 'functional') {
				setFunctional(false);
				hideBanner();
			}
			/* 'necessary' non e' revocabile. */
		},
		/** Registra fn(category, granted, state) chiamata a ogni cambio di consenso. */
		onChange: function (fn) {
			if (typeof fn === 'function') {
				listeners.push(fn);
			}
		}
	};

	/* ---------- Init a DOM pronto ---------- */

	function init() {
		banner = document.querySelector('.cookie-banner');

		if (banner) {
			var acceptAll = banner.querySelector('.cookie-accept-all');
			var acceptNecessary = banner.querySelector('.cookie-accept-necessary');

			if (acceptAll) {
				acceptAll.addEventListener('click', function () {
					setFunctional(true);
					hideBanner();
				});
			}
			if (acceptNecessary) {
				acceptNecessary.addEventListener('click', function () {
					setFunctional(false);
					hideBanner();
				});
			}

			/* Banner solo se non esiste una scelta salvata (nemmeno migrata). */
			if (!currentState) {
				showBanner();
			}
		}

		/* "Impostazioni cookie" nel footer: main.js emette questo evento. */
		document.addEventListener('humza:cookie-reopen', showBanner);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
