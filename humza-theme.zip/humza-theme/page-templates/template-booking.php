<?php
/**
 * Template Name: Prenota
 *
 * Pagina di conversione del sito: introduzione minima, widget di
 * prenotazione in evidenza, poi tre schede "cosa serve sapere" e un box
 * per chi preferisce parlare invece di compilare moduli.
 *
 * Il widget arriva dallo shortcode del plugin hamza-booking presente nel
 * contenuto pagina (the_content). Se il contenuto ne è privo, fallback su
 * do_shortcode del primo shortcode di prenotazione registrato.
 * <noscript> con telefono e WhatsApp per chi ha JavaScript disattivato.
 *
 * Il markup del widget appartiene al plugin: il blocco .booking-done qui
 * sotto è del tema e compare solo a prenotazione confermata (regola :has()
 * in booking-skin.css). Senza supporto a :has() resta nascosto e i contatti
 * restano comunque raggiungibili dal box "Preferisci parlare?".
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();

$humza_wa_book   = humza_wa_href( __( 'Ciao! Vorrei prenotare un appuntamento.', 'hamza-theme' ) );
$humza_wa_help   = humza_wa_href( __( 'Ciao! Ho bisogno di aiuto per prenotare un appuntamento.', 'hamza-theme' ) );
$humza_wa_change = humza_wa_href( __( 'Ciao! Devo spostare o disdire il mio appuntamento.', 'hamza-theme' ) );
$humza_phone     = humza_biz( 'phone1' );
$humza_phone_url = humza_phone_href( $humza_phone );
?>

<main id="main">

	<?php while ( have_posts() ) : the_post(); ?>

		<header class="page-hero">
			<div class="container">
				<?php
				if ( function_exists( 'humza_breadcrumb' ) ) {
					humza_breadcrumb();
				}
				?>
				<h1><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="page-hero__sub"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php else : ?>
					<p class="page-hero__sub"><?php esc_html_e( 'Scegli il giorno e l’ora. Ci vogliono due minuti.', 'hamza-theme' ); ?></p>
				<?php endif; ?>
			</div>
		</header>

		<!-- Widget di prenotazione (shortcode nel contenuto pagina) -->
		<section class="section section--paper" aria-labelledby="prenota-widget-title">
			<div class="container">

				<h2 id="prenota-widget-title" class="screen-reader-text"><?php esc_html_e( 'Prenotazione online', 'hamza-theme' ); ?></h2>

				<div class="booking-shell">

					<noscript>
						<div class="form-msg form-msg--err">
							<p>
								<?php esc_html_e( 'Per prenotare online serve JavaScript, che nel tuo browser è disattivato. Nessun problema: fissiamo noi l’appuntamento per te.', 'hamza-theme' ); ?>
								<?php if ( '' !== $humza_phone_url ) : ?>
								<a href="<?php echo esc_url( $humza_phone_url ); ?>">
									<?php
									echo esc_html(
										sprintf(
											/* translators: %s: numero di telefono. */
											__( 'Chiamaci al %s', 'hamza-theme' ),
											$humza_phone
										)
									);
									?>
								</a>
								<?php esc_html_e( 'oppure', 'hamza-theme' ); ?>
								<?php endif; ?>
								<a href="<?php echo esc_url( $humza_wa_book ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'scrivici su WhatsApp', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span></a>.
							</p>
						</div>
					</noscript>

					<?php
					the_content();

					/*
					 * Fallback: se il contenuto pagina non contiene il widget
					 * (né shortcode né markup "hamza"), prova gli shortcode noti
					 * del plugin. Il commento HTML lascia traccia nel sorgente.
					 */
					$humza_booking_raw = (string) get_post_field( 'post_content', get_the_ID() );
					if ( false === stripos( $humza_booking_raw, 'hamza' ) ) {
						foreach ( array( 'hamza_booking', 'hamza-booking', 'booking' ) as $humza_booking_tag ) {
							if ( function_exists( 'shortcode_exists' ) && shortcode_exists( $humza_booking_tag ) ) {
								echo "\n<!-- hamza-theme: shortcode di prenotazione assente nel contenuto pagina; fallback [" . esc_html( $humza_booking_tag ) . "] -->\n";
								echo do_shortcode( '[' . $humza_booking_tag . ']' ); // phpcs:ignore WordPress.Security.EscapeOutput -- output del plugin di prenotazione.
								break;
							}
						}
					}
					?>

					<!-- Visibile solo dopo la conferma (vedi booking-skin.css) -->
					<div class="booking-done">
						<p><?php esc_html_e( 'Ci vediamo presto. Salva il nostro numero: se hai un imprevisto, avvisaci e liberi il posto per un’altra persona.', 'hamza-theme' ); ?></p>
						<div class="booking-done__actions">
							<a class="btn btn--wa btn--block-mobile" href="<?php echo esc_url( $humza_wa_change ); ?>" target="_blank" rel="noopener noreferrer">
								<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>
								<?php esc_html_e( 'Scrivici su WhatsApp', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
							</a>
							<?php if ( '' !== $humza_phone_url ) : ?>
							<a class="btn btn--ghost btn--block-mobile" href="<?php echo esc_url( $humza_phone_url ); ?>">
								<?php echo humza_icon( 'ic-tel', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>
								<?php echo esc_html( $humza_phone ); ?>
							</a>
							<?php endif; ?>
						</div>
					</div>

				</div><!-- /.booking-shell -->
			</div>
		</section>

		<!-- Cosa serve sapere prima di venire -->
		<section class="section" aria-labelledby="prenota-info-title">
			<div class="container">

				<div class="section-head">
					<span class="stamp"><?php esc_html_e( 'Prima di venire', 'hamza-theme' ); ?></span>
					<h2 id="prenota-info-title"><?php esc_html_e( 'Cosa serve sapere', 'hamza-theme' ); ?></h2>
				</div>

				<div class="booking-notes">

					<article class="booking-note" data-animate>
						<span class="booking-note__icon"><?php echo humza_icon( 'ic-altri', 30 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?></span>
						<h3><?php esc_html_e( 'Cosa portare', 'hamza-theme' ); ?></h3>
						<p><?php esc_html_e( 'Un documento d’identità valido, il codice fiscale e i fogli legati alla tua pratica: permesso di soggiorno, lettere ricevute, buste paga.', 'hamza-theme' ); ?></p>
						<p><?php esc_html_e( 'Non sai cosa serve? Scrivici prima: ti prepariamo la lista.', 'hamza-theme' ); ?></p>
					</article>

					<article class="booking-note" data-animate>
						<span class="booking-note__icon"><?php echo humza_icon( 'ic-orari', 30 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?></span>
						<h3><?php esc_html_e( 'Come disdire o spostare', 'hamza-theme' ); ?></h3>
						<p><?php esc_html_e( 'Se non puoi più venire, avvisaci per telefono o su WhatsApp: liberi il posto per un’altra persona e ti troviamo un altro orario.', 'hamza-theme' ); ?></p>
						<p>
							<a href="<?php echo esc_url( $humza_wa_change ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Disdici su WhatsApp', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span></a>
						</p>
					</article>

					<article class="booking-note" data-animate>
						<span class="booking-note__icon booking-note__icon--wa"><?php echo humza_icon( 'ic-wa', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?></span>
						<h3><?php esc_html_e( 'Se ti serve aiuto', 'hamza-theme' ); ?></h3>
						<p><?php esc_html_e( 'Il modulo non funziona o preferisci scrivere nella tua lingua? Mandaci un messaggio su WhatsApp: prenotiamo noi per te.', 'hamza-theme' ); ?></p>
						<p>
							<a href="<?php echo esc_url( $humza_wa_help ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Chiedi aiuto su WhatsApp', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span></a>
						</p>
					</article>

				</div>

				<div class="booking-talk box-narrow">
					<h2><?php esc_html_e( 'Preferisci parlare con una persona?', 'hamza-theme' ); ?></h2>
					<p><?php esc_html_e( 'Nessun problema: chiamaci o scrivici e fissiamo noi l’appuntamento, senza compilare nulla.', 'hamza-theme' ); ?></p>
					<p class="booking-talk__hours">
						<?php
						echo esc_html(
							sprintf(
								/* translators: 1: giorni di apertura, 2: orario mattina, 3: orario pomeriggio. */
								__( 'Siamo aperti %1$s, %2$s e %3$s.', 'hamza-theme' ),
								humza_biz( 'days' ),
								humza_biz( 'hours_am' ),
								humza_biz( 'hours_pm' )
							)
						);
						?>
					</p>
					<div class="btn-row">
						<?php if ( '' !== $humza_phone_url ) : ?>
						<a class="btn btn--navy btn--block-mobile" href="<?php echo esc_url( $humza_phone_url ); ?>">
							<?php echo humza_icon( 'ic-tel', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>
							<?php
							echo esc_html(
								sprintf(
									/* translators: %s: numero di telefono. */
									__( 'Chiama %s', 'hamza-theme' ),
									$humza_phone
								)
							);
							?>
						</a>
						<?php endif; ?>
						<a class="btn btn--wa btn--block-mobile" href="<?php echo esc_url( $humza_wa_book ); ?>" target="_blank" rel="noopener noreferrer">
							<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>
							<?php esc_html_e( 'Prenota su WhatsApp', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
						</a>
					</div>
				</div>

			</div>
		</section>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>
