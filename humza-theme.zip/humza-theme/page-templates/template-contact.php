<?php
/**
 * Template Name: Contatti
 *
 * Pagina contatti: canali diretti (telefono, WhatsApp, email), modulo di
 * contatto AJAX, contenuto editoriale, mappa con consenso e orari.
 *
 * Il form replica ESATTAMENTE il contratto server-side esistente
 * (action hamza_contact_form su admin-ajax, nomi campi hamza_*, nonce
 * "hamza_contact_nonce", honeypot hamza_website): non rinominare i campi.
 *
 * Ordine dei campi pensato per il mobile: nome, telefono (il canale con cui
 * rispondiamo davvero), email, servizio, messaggio, allegati. I campi lunghi
 * restano a tutta larghezza; su tablet la coppia email/servizio va su due
 * colonne (.form-grid--2).
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();

// Numeri effettivamente configurati: senza guardia si generavano link "tel:+39".
$humza_phones = array_values(
	array_filter(
		array( humza_biz( 'phone1' ), humza_biz( 'phone2' ) ),
		static function ( $phone ) {
			return '' !== trim( (string) $phone );
		}
	)
);
$humza_email = trim( (string) humza_biz( 'email' ) );

// Con tre card la griglia va a 3 colonne su desktop, con due resta a due.
$humza_channels      = 1 + ( $humza_phones ? 1 : 0 ) + ( '' !== $humza_email ? 1 : 0 );
$humza_channels_grid = ( $humza_channels >= 3 ) ? 'grid grid--2 grid--3' : 'grid grid--2';
?>

<main id="main">

	<?php while ( have_posts() ) : the_post(); ?>

		<header class="page-hero">
			<div class="container">
				<?php
				if ( function_exists( 'humza_breadcrumb' ) ) {
					humza_breadcrumb();
				}
				?>
				<h1><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="page-hero__sub"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php else : ?>
					<p class="page-hero__sub"><?php esc_html_e( 'Telefono, WhatsApp, email e modulo di contatto. Ti rispondiamo in 6 lingue, dal lunedì al sabato.', 'hamza-theme' ); ?></p>
				<?php endif; ?>
			</div>
		</header>

		<!-- Canali di contatto diretti -->
		<section class="section" aria-labelledby="canali-title">
			<div class="container">
				<div class="section-head">
					<span class="stamp"><?php esc_html_e( 'Contatti diretti', 'hamza-theme' ); ?></span>
					<h2 id="canali-title"><?php esc_html_e( 'Come puoi contattarci?', 'hamza-theme' ); ?></h2>
					<p><?php esc_html_e( 'Scegli il canale più comodo per te: ti rispondiamo nella tua lingua.', 'hamza-theme' ); ?></p>
				</div>
				<div class="<?php echo esc_attr( $humza_channels_grid ); ?>">

					<article class="card" data-animate>
						<span class="card__icon"><?php echo humza_icon( 'ic-wa', 34 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?></span>
						<h3>WhatsApp</h3>
						<p><?php esc_html_e( 'Il modo più veloce per farci una domanda o mandarci la foto di un documento. Scrivi pure nella tua lingua.', 'hamza-theme' ); ?></p>
						<a class="btn btn--wa btn--block-mobile" href="<?php echo esc_url( humza_wa_href( __( 'Ciao! Vorrei informazioni sui vostri servizi.', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?><?php esc_html_e( 'Scrivici su WhatsApp', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span></a>
					</article>

					<?php if ( $humza_phones ) : ?>
						<article class="card" data-animate>
							<span class="card__icon"><?php echo humza_icon( 'ic-tel', 34 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?></span>
							<h3><?php esc_html_e( 'Telefono', 'hamza-theme' ); ?></h3>
							<ul class="contact-lines">
								<?php foreach ( $humza_phones as $humza_phone ) : ?>
									<li><a href="<?php echo esc_url( humza_phone_href( $humza_phone ) ); ?>"><?php echo esc_html( $humza_phone ); ?></a></li>
								<?php endforeach; ?>
							</ul>
							<p><?php esc_html_e( 'Chiamaci negli orari di apertura. Se non rispondiamo subito stiamo seguendo un cliente: riprova tra qualche minuto.', 'hamza-theme' ); ?></p>
						</article>
					<?php endif; ?>

					<?php if ( '' !== $humza_email ) : ?>
						<article class="card" data-animate>
							<span class="card__icon"><?php echo humza_icon( 'ic-mail', 34 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?></span>
							<h3>Email</h3>
							<ul class="contact-lines">
								<li><a href="mailto:<?php echo esc_attr( $humza_email ); ?>"><?php echo esc_html( $humza_email ); ?></a></li>
							</ul>
							<p><?php esc_html_e( 'Usa l’email se devi mandarci documenti in PDF o se preferisci avere tutto per iscritto.', 'hamza-theme' ); ?></p>
						</article>
					<?php endif; ?>

				</div>
			</div>
		</section>

		<!-- Modulo di contatto -->
		<section class="section section--paper" aria-labelledby="form-title">
			<div class="container">
				<div class="section-head">
					<span class="stamp"><?php esc_html_e( 'Scrivici', 'hamza-theme' ); ?></span>
					<h2 id="form-title"><?php esc_html_e( 'Inviaci un messaggio', 'hamza-theme' ); ?></h2>
					<p><?php esc_html_e( 'Compila il modulo: ti rispondiamo il prima possibile, nella lingua in cui ci scrivi.', 'hamza-theme' ); ?></p>
				</div>

				<div class="form-wrap">
					<form id="hamza-contact-form" class="contact-form" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" method="post" enctype="multipart/form-data" novalidate>
						<?php
						/*
						 * Nonce: stesso name del form attuale (hamza_contact_nonce).
						 * L'azione del nonce è filtrabile: se il plugin verifica con
						 * una stringa diversa, correggerla via filtro senza toccare
						 * il template.
						 */
						wp_nonce_field( apply_filters( 'humza_contact_nonce_action', 'hamza_contact_form' ), 'hamza_contact_nonce' );
						?>
						<input type="hidden" name="action" value="hamza_contact_form">

						<p class="field-hint form-required-note">
							<?php
							printf(
								/* translators: %s: asterisco che segnala i campi obbligatori. */
								esc_html__( 'I campi con %s sono obbligatori.', 'hamza-theme' ),
								'<span class="req" aria-hidden="true">*</span>'
							);
							?>
						</p>

						<div class="form-grid form-grid--2">
							<div class="field form-span">
								<label for="contact-name"><?php esc_html_e( 'Nome e cognome', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
								<input type="text" id="contact-name" name="hamza_name" required autocomplete="name" placeholder="<?php esc_attr_e( 'Es. Maria Rossi', 'hamza-theme' ); ?>">
							</div>

							<div class="field form-span">
								<label for="contact-phone"><?php esc_html_e( 'Telefono', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
								<div class="phone-row">
									<select name="hamza_phone_prefix" aria-label="<?php esc_attr_e( 'Prefisso internazionale', 'hamza-theme' ); ?>">
										<option value="+39" selected>+39 IT</option>
										<option value="+92">+92 PK</option>
										<option value="+91">+91 IN</option>
										<option value="+880">+880 BD</option>
										<option value="+20">+20 EG</option>
										<option value="+212">+212 MA</option>
										<option value="+234">+234 NG</option>
										<option value="+40">+40 RO</option>
										<option value="+33">+33 FR</option>
										<option value="+44">+44 UK</option>
										<option value="+90">+90 TR</option>
										<option value="+971">+971 AE</option>
										<option value="+966">+966 SA</option>
										<option value="+1">+1 US / CA</option>
									</select>
									<input type="tel" id="contact-phone" name="hamza_phone" required autocomplete="tel-national" inputmode="tel" placeholder="<?php esc_attr_e( 'Es. 324 0000000', 'hamza-theme' ); ?>" aria-describedby="contact-phone-hint">
								</div>
								<p class="field-hint" id="contact-phone-hint"><?php esc_html_e( 'Scegli prima il prefisso del tuo paese. Ti richiamiamo o ti scriviamo su WhatsApp.', 'hamza-theme' ); ?></p>
							</div>

							<div class="field">
								<label for="contact-email"><?php esc_html_e( 'Email', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
								<input type="email" id="contact-email" name="hamza_email" required autocomplete="email" inputmode="email" placeholder="<?php esc_attr_e( 'Es. nome@gmail.com', 'hamza-theme' ); ?>" aria-describedby="contact-email-hint">
								<p class="field-hint" id="contact-email-hint"><?php esc_html_e( 'Ci serve per risponderti per iscritto. Controlla che sia scritta bene.', 'hamza-theme' ); ?></p>
							</div>

							<div class="field">
								<label for="contact-service"><?php esc_html_e( 'Servizio di interesse', 'hamza-theme' ); ?></label>
								<select id="contact-service" name="hamza_service" aria-describedby="contact-service-hint">
									<option value=""><?php esc_html_e( 'Seleziona un servizio', 'hamza-theme' ); ?></option>
									<option value="pratiche-prefettura"><?php esc_html_e( 'Pratiche Prefettura', 'hamza-theme' ); ?></option>
									<option value="pratiche-inps"><?php esc_html_e( 'Pratiche INPS', 'hamza-theme' ); ?></option>
									<option value="consolato-pakistano"><?php esc_html_e( 'Servizi Consolato Pakistano', 'hamza-theme' ); ?></option>
									<option value="consolato-indiano"><?php esc_html_e( 'Servizi Consolato Indiano', 'hamza-theme' ); ?></option>
									<option value="richiesta-visti"><?php esc_html_e( 'Richiesta Visti', 'hamza-theme' ); ?></option>
									<option value="pratiche-caf"><?php esc_html_e( 'Pratiche CAF', 'hamza-theme' ); ?></option>
									<option value="pratiche-tribunale"><?php esc_html_e( 'Pratiche Tribunale', 'hamza-theme' ); ?></option>
									<option value="altri-servizi"><?php esc_html_e( 'Altri Servizi', 'hamza-theme' ); ?></option>
									<option value="altro"><?php esc_html_e( 'Altro', 'hamza-theme' ); ?></option>
								</select>
								<p class="field-hint" id="contact-service-hint"><?php esc_html_e( 'Non sei sicuro? Scegli «Altro»: ci pensiamo noi.', 'hamza-theme' ); ?></p>
							</div>

							<div class="field form-span">
								<label for="contact-message"><?php esc_html_e( 'Messaggio', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
								<textarea id="contact-message" name="hamza_message" rows="5" required placeholder="<?php esc_attr_e( 'Dicci di cosa hai bisogno. Puoi scrivere nella tua lingua.', 'hamza-theme' ); ?>" aria-describedby="contact-message-hint"></textarea>
								<p class="field-hint" id="contact-message-hint"><?php esc_html_e( 'Più dettagli ci dai, più precisa sarà la risposta (documenti, tempi, costi).', 'hamza-theme' ); ?></p>
							</div>

							<div class="field form-span">
								<label for="contact-files"><?php esc_html_e( 'Allegati (facoltativo)', 'hamza-theme' ); ?></label>
								<input type="file" id="contact-files" name="hamza_files[]" multiple accept=".pdf,.jpg,.jpeg,.png,.docx" aria-describedby="contact-files-hint">
								<p class="field-hint" id="contact-files-hint"><?php esc_html_e( 'Puoi allegare anche la foto di un documento. Massimo 5 file da 10 MB ciascuno: PDF, JPG, PNG, DOCX.', 'hamza-theme' ); ?></p>
							</div>

							<div class="field form-span">
								<div class="consent">
									<input type="checkbox" id="contact-privacy" name="hamza_privacy" required>
									<span>
										<label for="contact-privacy"><?php esc_html_e( 'Ho letto e accetto la Privacy Policy. Autorizzo il trattamento dei miei dati personali.', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
										<a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Leggi la Privacy Policy', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span></a>
									</span>
								</div>
							</div>

							<?php /* Honeypot anti-spam: invisibile agli utenti, nome campo invariato. */ ?>
							<div class="hp-field" aria-hidden="true">
								<label for="contact-website">Website</label>
								<input type="text" id="contact-website" name="hamza_website" tabindex="-1" autocomplete="off">
							</div>

							<div class="form-span">
								<button type="submit" id="contact-submit" class="btn btn--navy btn--block-mobile"><?php esc_html_e( 'Invia messaggio', 'hamza-theme' ); ?></button>
							</div>
						</div>

						<div id="contact-form-message" class="form-msg" role="status" aria-live="polite" hidden></div>
					</form>

					<p class="field-hint"><?php esc_html_e( 'I dati che inserisci in questo modulo li usiamo solo per risponderti. Non li usiamo per pubblicità e non li passiamo ad altri. Trovi tutti i dettagli nell’Informativa sulla Privacy.', 'hamza-theme' ); ?></p>
				</div>
			</div>
		</section>

		<!-- Contenuto editoriale della pagina (da wp-admin) -->
		<?php if ( '' !== trim( (string) get_post_field( 'post_content', get_the_ID() ) ) ) : ?>
			<section class="section" aria-labelledby="info-contatti-title">
				<div class="container">
					<h2 id="info-contatti-title" class="screen-reader-text"><?php esc_html_e( 'Altre informazioni utili', 'hamza-theme' ); ?></h2>
					<div class="prose">
						<?php the_content(); ?>
					</div>
				</div>
			</section>
		<?php endif; ?>

		<!-- Dove siamo: mappa con consenso + orari -->
		<section class="section map-section" aria-labelledby="dove-title">
			<div class="container">
				<div class="section-head">
					<span class="stamp"><?php esc_html_e( 'Dove siamo', 'hamza-theme' ); ?></span>
					<h2 id="dove-title"><?php echo esc_html( humza_biz( 'street' ) . ', ' . humza_biz( 'cap' ) . ' ' . humza_biz( 'city' ) . ' (' . humza_biz( 'prov' ) . ')' ); ?></h2>
					<p><?php esc_html_e( 'Se non conosci la zona, scrivici su WhatsApp: ti mandiamo la posizione esatta su Google Maps.', 'hamza-theme' ); ?></p>
				</div>
				<div class="map-grid">
					<div>
						<?php get_template_part( 'parts/map-consent' ); ?>
					</div>
					<div class="aside-box">
						<h3><?php echo humza_icon( 'ic-orari', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?> <?php esc_html_e( 'Orari di apertura', 'hamza-theme' ); ?></h3>
						<table class="hours">
							<tr>
								<td><?php echo esc_html( humza_biz( 'days' ) ); ?></td>
								<td><?php echo esc_html( humza_biz( 'hours_am' ) . ' / ' . humza_biz( 'hours_pm' ) ); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Domenica', 'hamza-theme' ); ?></td>
								<td><?php esc_html_e( 'Chiuso', 'hamza-theme' ); ?></td>
							</tr>
						</table>
						<p class="field-hint"><?php esc_html_e( 'Per le urgenze puoi scriverci su WhatsApp anche fuori orario: ti rispondiamo appena riapriamo.', 'hamza-theme' ); ?></p>
					</div>
				</div>
			</div>
		</section>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>
