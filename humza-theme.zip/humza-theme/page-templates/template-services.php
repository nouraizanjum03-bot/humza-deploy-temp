<?php
/**
 * Template Name: Servizi (hub)
 *
 * Pagina indice dei servizi: intro editoriale breve + griglia card generata
 * dalle pagine figlie di /servizi/ + la pagina Traduzioni (stessa logica
 * della homepage, così le due griglie restano sempre allineate), e in fondo
 * un box per chi non riconosce la propria pratica nell'elenco.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="main">

	<?php while ( have_posts() ) : the_post(); ?>

		<header class="page-hero">
			<div class="container">
				<?php
				if ( function_exists( 'humza_breadcrumb' ) ) {
					humza_breadcrumb();
				}
				?>
				<h1><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="page-hero__sub"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php else : ?>
					<p class="page-hero__sub"><?php esc_html_e( 'Pratiche, CAF, visti, consolati e traduzioni: un unico ufficio a Brescia, nella tua lingua.', 'hamza-theme' ); ?></p>
				<?php endif; ?>
			</div>
		</header>

		<section class="section" aria-labelledby="servizi-grid-title">
			<div class="container">
				<h2 id="servizi-grid-title" class="screen-reader-text"><?php esc_html_e( 'Elenco dei servizi', 'hamza-theme' ); ?></h2>

				<?php if ( '' !== trim( get_the_content() ) ) : ?>
					<div class="prose prose--intro">
						<?php the_content(); ?>
					</div>
				<?php else : ?>
					<div class="prose prose--intro">
						<p><?php esc_html_e( 'Scegli il servizio che ti serve: in ogni pagina trovi cosa facciamo, quali documenti portare e quanto tempo serve. Se hai un dubbio, scrivici prima di venire: ti diciamo subito se possiamo aiutarti.', 'hamza-theme' ); ?></p>
					</div>
				<?php endif; ?>

				<?php get_template_part( 'parts/services-grid' ); ?>
			</div>
		</section>

		<section class="section section--paper" aria-labelledby="servizi-help-title">
			<div class="container">
				<div class="aside-box box-narrow">
					<h2 id="servizi-help-title"><?php esc_html_e( 'Non trovi il tuo caso?', 'hamza-theme' ); ?></h2>
					<p><?php esc_html_e( 'Seguiamo anche pratiche che non sono in questo elenco. Raccontaci in due righe di cosa hai bisogno: ti diciamo subito se possiamo farlo, quanto costa e quanto tempo serve.', 'hamza-theme' ); ?></p>
					<a class="btn btn--wa" href="<?php echo esc_url( humza_wa_href( __( 'Ciao, ho una pratica che non ho trovato nell’elenco dei servizi. Potete aiutarmi?', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?><?php esc_html_e( 'Chiedi su WhatsApp', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
					</a>
					<a class="btn btn--ghost" href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>"><?php esc_html_e( 'Tutti i contatti', 'hamza-theme' ); ?></a>
				</div>
			</div>
		</section>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>
