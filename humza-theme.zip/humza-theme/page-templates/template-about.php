<?php
/**
 * Template Name: Chi Siamo
 *
 * Storia e modo di lavorare (contenuto reale dalla pagina). Se la pagina ha
 * un'immagine in evidenza — la foto vera dell'ufficio — viene usata una sola
 * volta, accanto al testo (griglia .why): niente illustrazioni decorative
 * ripetute. Chiude il richiamo ai servizi + un invito a passare in ufficio.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="main">

	<?php
	while ( have_posts() ) :
		the_post();

		$humza_about_has_media = has_post_thumbnail();
		$humza_about_caption   = $humza_about_has_media ? trim( (string) get_the_post_thumbnail_caption() ) : '';
		?>

		<section class="page-hero">
			<div class="container">
				<?php
				if ( function_exists( 'humza_breadcrumb' ) ) {
					humza_breadcrumb();
				}
				?>
				<h1><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="page-hero__sub"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php else : ?>
					<p class="page-hero__sub"><?php esc_html_e( 'Chi siamo, come lavoriamo e in quali lingue possiamo aiutarti.', 'hamza-theme' ); ?></p>
				<?php endif; ?>
			</div>
		</section>

		<section class="section" aria-labelledby="about-story-title">
			<div class="container">
				<h2 id="about-story-title" class="screen-reader-text"><?php esc_html_e( 'La nostra storia', 'hamza-theme' ); ?></h2>

				<?php if ( $humza_about_has_media ) : ?>
					<div class="why">
						<div class="prose">
							<?php the_content(); ?>
						</div>
						<figure class="why__media">
							<?php the_post_thumbnail( 'large', array( 'loading' => 'lazy' ) ); ?>
							<?php if ( '' !== $humza_about_caption ) : ?>
								<figcaption><?php echo esc_html( $humza_about_caption ); ?></figcaption>
							<?php endif; ?>
						</figure>
					</div>
				<?php else : ?>
					<div class="prose">
						<?php the_content(); ?>
					</div>
				<?php endif; ?>

				<?php
				wp_link_pages( array(
					'before' => '<nav class="page-links" aria-label="' . esc_attr__( 'Pagine del contenuto', 'hamza-theme' ) . '">' . esc_html__( 'Pagine:', 'hamza-theme' ) . ' ',
					'after'  => '</nav>',
				) );
				?>
			</div>
		</section>

		<section class="section section--paper" aria-labelledby="about-servizi-title">
			<div class="container">
				<div class="section-head">
					<span class="stamp"><?php esc_html_e( 'I nostri servizi', 'hamza-theme' ); ?></span>
					<h2 id="about-servizi-title"><?php esc_html_e( 'Cosa possiamo fare per te', 'hamza-theme' ); ?></h2>
					<p><?php esc_html_e( 'Un unico ufficio per pratiche fiscali, di immigrazione, consolari e traduzioni.', 'hamza-theme' ); ?></p>
				</div>
				<?php get_template_part( 'parts/services-grid' ); ?>
			</div>
		</section>

		<section class="section" aria-labelledby="about-visit-title">
			<div class="container">
				<div class="aside-box box-narrow">
					<h2 id="about-visit-title"><?php esc_html_e( 'Vieni a trovarci', 'hamza-theme' ); ?></h2>
					<p>
						<?php
						echo esc_html(
							sprintf(
								/* translators: 1: indirizzo, 2: città, 3: giorni di apertura. */
								__( 'Siamo in %1$s a %2$s, aperti %3$s. Puoi passare in ufficio o prenotare un appuntamento per non aspettare.', 'hamza-theme' ),
								humza_biz( 'street' ),
								humza_biz( 'city' ),
								humza_biz( 'days' )
							)
						);
						?>
					</p>
					<a class="btn btn--primary" href="<?php echo esc_url( home_url( '/prenota/' ) ); ?>"><?php esc_html_e( 'Prenota appuntamento', 'hamza-theme' ); ?></a>
					<a class="btn btn--wa" href="<?php echo esc_url( humza_wa_href( __( 'Ciao, vorrei sapere come lavorate e se potete aiutarmi.', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>WhatsApp<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
					</a>
				</div>
			</div>
		</section>

	<?php endwhile; ?>

</main>

<?php
get_footer();
