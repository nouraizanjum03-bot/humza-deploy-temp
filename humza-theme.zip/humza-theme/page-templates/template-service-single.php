<?php
/**
 * Template Name: Servizio
 *
 * Pagina di dettaglio servizio: è la pagina che deve convertire.
 * Struttura:
 * - hero con breadcrumb e titolo;
 * - blocco "azioni rapide" (.quick-actions) subito sotto il titolo, visibile
 *   solo su mobile/tablet: su schermo piccolo la sidebar finisce in fondo,
 *   quindi WhatsApp e Prenota devono essere raggiungibili subito;
 * - contenuto editoriale + sidebar sticky (desktop) con contatti e orari;
 * - "Altri servizi che potrebbero servirti": 3 pagine fratelle in ordine
 *   menu_order, scorrimento ciclico a partire dalla pagina corrente.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'humza_service_siblings' ) ) {
	/**
	 * Pagine servizio "fratelle" della corrente, già filtrate e ordinate.
	 *
	 * Fonte dati identica a parts/services-grid.php: figlie di /servizi/
	 * (menu_order) più la pagina /traduzioni/, che sta fuori dall'albero.
	 *
	 * @param WP_Post $current Pagina servizio corrente.
	 * @return WP_Post[] Elenco ordinato (può contenere la pagina corrente).
	 */
	function humza_service_siblings( WP_Post $current ): array {
		$parent_id = (int) $current->post_parent;

		if ( ! $parent_id ) {
			$servizi_page = get_page_by_path( 'servizi' );
			$parent_id    = ( $servizi_page instanceof WP_Post ) ? (int) $servizi_page->ID : 0;
		}

		$siblings = array();

		if ( $parent_id ) {
			$children = get_pages(
				array(
					'parent'      => $parent_id,
					'sort_column' => 'menu_order',
					'sort_order'  => 'asc',
				)
			);
			if ( is_array( $children ) ) {
				$siblings = $children;
			}
		}

		$traduzioni = get_page_by_path( 'traduzioni' );
		if ( $traduzioni instanceof WP_Post
			&& ! in_array( (int) $traduzioni->ID, array_map( 'intval', wp_list_pluck( $siblings, 'ID' ) ), true ) ) {
			$siblings[] = $traduzioni;
		}

		return array_values(
			array_filter(
				$siblings,
				static function ( $page ) {
					return $page instanceof WP_Post && 'publish' === $page->post_status;
				}
			)
		);
	}
}

if ( ! function_exists( 'humza_related_service_pages' ) ) {
	/**
	 * Le N pagine servizio successive alla corrente, in modo ciclico.
	 *
	 * Niente ordine casuale: la selezione è stabile (utile per la cache e per
	 * l'utente che torna sulla pagina) e ogni servizio rimanda ai successivi.
	 *
	 * @param WP_Post $current Pagina servizio corrente.
	 * @param int     $limit   Numero massimo di pagine da restituire.
	 * @return WP_Post[]
	 */
	function humza_related_service_pages( WP_Post $current, int $limit = 3 ): array {
		$siblings = humza_service_siblings( $current );
		$total    = count( $siblings );

		if ( $total < 2 || $limit < 1 ) {
			return array();
		}

		$ids      = array_map( 'intval', wp_list_pluck( $siblings, 'ID' ) );
		$position = array_search( (int) $current->ID, $ids, true );
		// Pagina non presente nell'elenco: si parte dalla prima.
		$offset = ( false === $position ) ? -1 : (int) $position;

		$related = array();
		for ( $step = 1; $step <= $total && count( $related ) < $limit; $step++ ) {
			$page = $siblings[ ( $offset + $step ) % $total ];
			if ( (int) $page->ID === (int) $current->ID ) {
				continue;
			}
			$related[] = $page;
		}

		return $related;
	}
}

get_header();
?>

<main id="main">

	<?php
	while ( have_posts() ) :
		the_post();

		$humza_service_title = wp_specialchars_decode( get_the_title(), ENT_QUOTES );
		$humza_service_wa    = humza_wa_href(
			sprintf(
				/* translators: %s: titolo della pagina servizio. */
				__( 'Ciao, ho bisogno di informazioni su: %s', 'hamza-theme' ),
				$humza_service_title
			)
		);
		$humza_booking_url = home_url( '/prenota/' );

		$humza_current_page = get_post();
		$humza_related      = ( $humza_current_page instanceof WP_Post ) ? humza_related_service_pages( $humza_current_page, 3 ) : array();
		?>

		<header class="page-hero">
			<div class="container">
				<?php
				if ( function_exists( 'humza_breadcrumb' ) ) {
					humza_breadcrumb();
				}
				?>
				<h1><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="page-hero__sub"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
			</div>
		</header>

		<div class="container layout-sidebar">

			<div class="prose">

				<?php /* Azioni rapide: solo mobile/tablet, la sidebar arriva troppo in basso. */ ?>
				<section class="quick-actions" aria-labelledby="quick-actions-title">
					<h2 id="quick-actions-title" class="quick-actions__title"><?php esc_html_e( 'Ti serve questo servizio?', 'hamza-theme' ); ?></h2>
					<p class="quick-actions__text"><?php esc_html_e( 'Scrivici su WhatsApp o prenota un appuntamento: ti diciamo subito documenti, tempi e costi.', 'hamza-theme' ); ?></p>
					<div class="quick-actions__btns">
						<a class="btn btn--wa btn--block-mobile" href="<?php echo esc_url( $humza_service_wa ); ?>" target="_blank" rel="noopener noreferrer">
							<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>WhatsApp<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
						</a>
						<a class="btn btn--primary btn--block-mobile" href="<?php echo esc_url( $humza_booking_url ); ?>"><?php esc_html_e( 'Prenota appuntamento', 'hamza-theme' ); ?></a>
					</div>
				</section>

				<?php
				the_content();

				wp_link_pages( array(
					'before' => '<nav class="page-links" aria-label="' . esc_attr__( 'Pagine del contenuto', 'hamza-theme' ) . '">' . esc_html__( 'Pagine:', 'hamza-theme' ) . ' ',
					'after'  => '</nav>',
				) );
				?>

				<p class="last-updated">
					<?php
					printf(
						/* translators: %s: data di ultima modifica della pagina. */
						esc_html__( 'Ultimo aggiornamento: %s', 'hamza-theme' ),
						'<time datetime="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . esc_html( get_the_modified_date( 'j F Y' ) ) . '</time>'
					);
					?>
				</p>
			</div>

			<aside aria-labelledby="service-aside-title">
				<h2 id="service-aside-title" class="screen-reader-text"><?php esc_html_e( 'Contatti rapidi e informazioni utili', 'hamza-theme' ); ?></h2>
				<div class="sticky-aside">

					<div class="aside-box aside-box--navy">
						<h3><?php esc_html_e( 'Parla con noi', 'hamza-theme' ); ?></h3>
						<p><?php esc_html_e( 'Ti diciamo subito documenti, tempi e costi. Rispondiamo negli orari di apertura.', 'hamza-theme' ); ?></p>
						<?php if ( '' !== humza_biz( 'phone1' ) ) : ?>
							<a class="btn btn--ghost-light" href="<?php echo esc_url( humza_phone_href( humza_biz( 'phone1' ) ) ); ?>">
								<?php echo humza_icon( 'ic-tel', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?><?php echo esc_html( humza_biz( 'phone1' ) ); ?>
							</a>
						<?php endif; ?>
						<a class="btn btn--wa" href="<?php echo esc_url( $humza_service_wa ); ?>" target="_blank" rel="noopener noreferrer">
							<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>WhatsApp<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
						</a>
						<a class="btn btn--primary" href="<?php echo esc_url( $humza_booking_url ); ?>"><?php esc_html_e( 'Prenota appuntamento', 'hamza-theme' ); ?></a>
					</div>

					<div class="aside-box">
						<h3><?php esc_html_e( 'Orari di apertura', 'hamza-theme' ); ?></h3>
						<table class="hours">
							<tr>
								<td><?php echo esc_html( humza_biz( 'days' ) ); ?></td>
								<td>
									<?php echo esc_html( humza_biz( 'hours_am' ) ); ?><br>
									<?php echo esc_html( humza_biz( 'hours_pm' ) ); ?>
								</td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Domenica', 'hamza-theme' ); ?></td>
								<td><?php esc_html_e( 'Chiuso', 'hamza-theme' ); ?></td>
							</tr>
						</table>
					</div>

					<div class="aside-box">
						<h3><?php esc_html_e( 'Documenti alla mano?', 'hamza-theme' ); ?></h3>
						<p><?php esc_html_e( 'Non sei sicuro di cosa serve? Scrivici prima dell’appuntamento: controlliamo insieme e ti mandiamo la lista esatta.', 'hamza-theme' ); ?></p>
						<a class="btn btn--ghost" href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>"><?php esc_html_e( 'Vai ai contatti', 'hamza-theme' ); ?></a>
					</div>

				</div>
			</aside>

		</div>

		<?php if ( ! empty( $humza_related ) ) : ?>
			<section class="section section--paper" aria-labelledby="altri-servizi-title">
				<div class="container">
					<div class="section-head">
						<span class="stamp"><?php esc_html_e( 'Un unico ufficio', 'hamza-theme' ); ?></span>
						<h2 id="altri-servizi-title"><?php esc_html_e( 'Altri servizi che potrebbero servirti', 'hamza-theme' ); ?></h2>
						<p><?php esc_html_e( 'Spesso una pratica ne apre un’altra: possiamo seguirti anche su questi.', 'hamza-theme' ); ?></p>
					</div>
					<div class="grid grid--2 grid--3">
						<?php
						foreach ( $humza_related as $humza_related_page ) :
							$humza_related_icon = get_post_meta( $humza_related_page->ID, 'humza_icon', true );
							$humza_related_icon = ( is_string( $humza_related_icon ) && '' !== $humza_related_icon ) ? $humza_related_icon : 'ic-altri';
							?>
							<article class="card">
								<span class="card__icon"><?php echo humza_icon( $humza_related_icon, 34 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?></span>
								<h3><a href="<?php echo esc_url( get_permalink( $humza_related_page ) ); ?>"><?php echo esc_html( get_the_title( $humza_related_page ) ); ?></a></h3>
								<p><?php echo esc_html( get_the_excerpt( $humza_related_page ) ); ?></p>
								<span class="card__more" aria-hidden="true"><?php esc_html_e( 'Scopri di più', 'hamza-theme' ); ?></span>
							</article>
						<?php endforeach; ?>
					</div>
					<div class="btn-row section-note">
						<a class="btn btn--ghost" href="<?php echo esc_url( home_url( '/servizi/' ) ); ?>"><?php esc_html_e( 'Vedi tutti i servizi', 'hamza-theme' ); ?></a>
					</div>
				</div>
			</section>
		<?php endif; ?>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>
