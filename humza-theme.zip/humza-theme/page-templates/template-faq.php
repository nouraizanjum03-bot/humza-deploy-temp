<?php
/**
 * Template Name: FAQ
 *
 * Domande frequenti: il contenuto (h2 = categoria, h3 = domanda, resto =
 * risposta) viene trasformato in accordion accessibile da assets/js/main.js
 * tramite il wrapper .faq-source.
 *
 * Sopra le domande viene stampata, SOLO lato server, una riga di link alle
 * categorie (ancore agli h2) — niente JavaScript, funziona anche con JS
 * disattivato. Le ancore vengono ricavate con parse_blocks() e iniettate
 * negli h2 del contenuto renderizzato; se il numero di h2 non corrisponde
 * (contenuto classico, blocchi di terze parti) la navigazione viene omessa
 * invece di produrre link rotti.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'humza_faq_heading_entry' ) ) {
	/**
	 * Estrae testo e id già presente da un singolo heading HTML.
	 *
	 * @param string $html Markup dell'heading (blocco o frammento renderizzato).
	 * @return array{text:string,anchor:string}|null Null se il titolo è vuoto.
	 */
	function humza_faq_heading_entry( string $html ): ?array {
		$text = trim( wp_specialchars_decode( wp_strip_all_tags( $html ), ENT_QUOTES ) );
		if ( '' === $text ) {
			return null;
		}

		$anchor = '';
		if ( preg_match( '/\sid=["\']([^"\']+)["\']/i', $html, $matches ) ) {
			$anchor = $matches[1];
		}

		return array(
			'text'   => $text,
			'anchor' => $anchor,
		);
	}
}

if ( ! function_exists( 'humza_faq_headings_from_blocks' ) ) {
	/**
	 * Categorie FAQ (heading di livello 2) lette dai blocchi della pagina.
	 *
	 * @param string $content Contenuto grezzo del post.
	 * @return array<int, array{text:string,anchor:string}>
	 */
	function humza_faq_headings_from_blocks( string $content ): array {
		$blocks = parse_blocks( $content );
		if ( function_exists( 'humza_schema_flatten_blocks' ) ) {
			$blocks = humza_schema_flatten_blocks( $blocks );
		}

		$headings = array();
		foreach ( $blocks as $block ) {
			if ( 'core/heading' !== ( $block['blockName'] ?? '' ) ) {
				continue;
			}
			$html = (string) ( $block['innerHTML'] ?? '' );
			// core/heading omette l'attributo level quando è 2 (default).
			$level = isset( $block['attrs']['level'] ) ? (int) $block['attrs']['level'] : 2;
			if ( 2 !== $level || ! preg_match( '/<h2\b/i', $html ) ) {
				continue;
			}
			$entry = humza_faq_heading_entry( $html );
			if ( $entry ) {
				$headings[] = $entry;
			}
		}

		return $headings;
	}
}

if ( ! function_exists( 'humza_faq_headings_from_html' ) ) {
	/**
	 * Fallback per contenuti non a blocchi (editor classico): h2 dal markup.
	 *
	 * @param string $html Contenuto già renderizzato.
	 * @return array<int, array{text:string,anchor:string}>
	 */
	function humza_faq_headings_from_html( string $html ): array {
		if ( ! preg_match_all( '/<h2\b[^>]*>.*?<\/h2>/is', $html, $matches ) ) {
			return array();
		}

		$headings = array();
		foreach ( $matches[0] as $heading_html ) {
			$entry = humza_faq_heading_entry( $heading_html );
			if ( $entry ) {
				$headings[] = $entry;
			}
		}

		return $headings;
	}
}

if ( ! function_exists( 'humza_faq_assign_slugs' ) ) {
	/**
	 * Assegna a ogni categoria uno slug univoco (rispettando gli id esistenti).
	 *
	 * @param array<int, array{text:string,anchor:string}> $headings Categorie.
	 * @return array<int, array{text:string,anchor:string,slug:string}>
	 */
	function humza_faq_assign_slugs( array $headings ): array {
		$used = array();

		foreach ( $headings as $index => $heading ) {
			if ( '' !== $heading['anchor'] ) {
				$slug = $heading['anchor'];
			} else {
				// sanitize_title() può restituire una stringa vuota con titoli
				// non latini (urdu, hindi): si ripiega su un id posizionale.
				$sanitized = sanitize_title( $heading['text'] );
				$slug      = ( '' !== trim( $sanitized, '-' ) ) ? 'faq-' . $sanitized : 'faq-categoria-' . ( (int) $index + 1 );
			}

			$base    = $slug;
			$counter = 2;
			while ( isset( $used[ $slug ] ) ) {
				$slug = $base . '-' . $counter;
				$counter++;
			}
			$used[ $slug ] = true;

			$headings[ $index ]['slug'] = $slug;
		}

		return $headings;
	}
}

if ( ! function_exists( 'humza_faq_inject_anchors' ) ) {
	/**
	 * Aggiunge gli id agli h2 del contenuto renderizzato, nell'ordine dato.
	 * Gli h2 che hanno già un id restano intatti.
	 *
	 * @param string                                             $html     Contenuto renderizzato.
	 * @param array<int, array{text:string,anchor:string,slug:string}> $headings Categorie con slug.
	 * @return string
	 */
	function humza_faq_inject_anchors( string $html, array $headings ): string {
		$index = 0;

		$result = preg_replace_callback(
			'/<h2\b([^>]*)>/i',
			static function ( $matches ) use ( &$index, $headings ) {
				$attrs = $matches[1];
				$entry = $headings[ $index ] ?? null;
				$index++;

				if ( null === $entry || preg_match( '/\sid\s*=/i', $attrs ) ) {
					return $matches[0];
				}

				return '<h2' . $attrs . ' id="' . esc_attr( $entry['slug'] ) . '">';
			},
			$html
		);

		// preg_replace_callback può restituire null in caso di errore PCRE.
		return is_string( $result ) ? $result : $html;
	}
}

get_header();
?>

<main id="main">

	<?php
	while ( have_posts() ) :
		the_post();

		$humza_faq_raw  = get_the_content();
		$humza_faq_html = apply_filters( 'the_content', $humza_faq_raw );
		$humza_faq_html = str_replace( ']]>', ']]&gt;', (string) $humza_faq_html );

		$humza_faq_cats = humza_faq_headings_from_blocks( $humza_faq_raw );
		if ( empty( $humza_faq_cats ) ) {
			$humza_faq_cats = humza_faq_headings_from_html( $humza_faq_html );
		}

		// Ancore attendibili solo se gli h2 renderizzati sono esattamente quelli trovati.
		$humza_faq_h2_count = (int) preg_match_all( '/<h2\b/i', $humza_faq_html );
		$humza_faq_show_nav = count( $humza_faq_cats ) >= 2 && $humza_faq_h2_count === count( $humza_faq_cats );

		if ( $humza_faq_show_nav ) {
			$humza_faq_cats = humza_faq_assign_slugs( $humza_faq_cats );
			$humza_faq_html = humza_faq_inject_anchors( $humza_faq_html, $humza_faq_cats );
		}
		?>

		<section class="page-hero">
			<div class="container">
				<?php
				if ( function_exists( 'humza_breadcrumb' ) ) {
					humza_breadcrumb();
				}
				?>
				<h1><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="page-hero__sub"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php else : ?>
					<p class="page-hero__sub"><?php esc_html_e( 'Le risposte alle domande più comuni su pratiche, documenti, tempi e costi.', 'hamza-theme' ); ?></p>
				<?php endif; ?>
			</div>
		</section>

		<div class="container">
			<div class="section">

				<?php if ( $humza_faq_show_nav ) : ?>
					<nav class="faq-nav" aria-label="<?php esc_attr_e( 'Categorie delle domande', 'hamza-theme' ); ?>">
						<p class="faq-nav__label"><?php esc_html_e( 'Vai alla categoria:', 'hamza-theme' ); ?></p>
						<ul class="faq-nav__list">
							<?php foreach ( $humza_faq_cats as $humza_faq_cat ) : ?>
								<li>
									<a class="faq-nav__link" href="#<?php echo esc_attr( $humza_faq_cat['slug'] ); ?>"><?php echo esc_html( $humza_faq_cat['text'] ); ?></a>
								</li>
							<?php endforeach; ?>
						</ul>
					</nav>
				<?php endif; ?>

				<div class="prose faq-source">
					<?php echo $humza_faq_html; // phpcs:ignore WordPress.Security.EscapeOutput -- contenuto già passato dai filtri di the_content. ?>
				</div>

				<aside class="aside-box box-narrow" aria-labelledby="faq-help-title">
					<h2 id="faq-help-title"><?php esc_html_e( 'Non hai trovato la risposta?', 'hamza-theme' ); ?></h2>
					<p><?php esc_html_e( 'Scrivici su WhatsApp o passa in ufficio: ti rispondiamo con parole semplici, nella tua lingua.', 'hamza-theme' ); ?></p>
					<a class="btn btn--wa" href="<?php echo esc_url( humza_wa_href( __( 'Ciao, ho una domanda che non ho trovato nelle FAQ.', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>WhatsApp<span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
					</a>
					<a class="btn btn--ghost" href="<?php echo esc_url( home_url( '/contatti/' ) ); ?>"><?php esc_html_e( 'Tutti i contatti', 'hamza-theme' ); ?></a>
				</aside>

			</div>
		</div>

	<?php endwhile; ?>

</main>

<?php
get_footer();
