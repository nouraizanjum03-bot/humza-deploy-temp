<?php
/**
 * Template Name: Area Clienti
 *
 * L'area clienti è gestita dal plugin "hamza-client-portal", che fornisce
 * accesso, registrazione, elenco pratiche, messaggi e caricamento documenti
 * tramite lo shortcode [hamza_portal]. Questo template NON riscrive quei
 * moduli: li ospita nel layout del tema e aggiunge intorno solo aiuto e
 * contatti, così chi non riesce ad accedere trova comunque una via d'uscita.
 *
 * Se il plugin non è attivo, il template lo dice chiaramente invece di
 * mostrare una pagina vuota.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();

$humza_phone     = humza_biz( 'phone1' );
$humza_portal_ok = shortcode_exists( 'hamza_portal' );
?>

<main id="main">

	<?php while ( have_posts() ) : the_post(); ?>

		<header class="page-hero">
			<div class="container">
				<?php
				if ( function_exists( 'humza_breadcrumb' ) ) {
					humza_breadcrumb();
				}
				?>
				<h1><?php the_title(); ?></h1>
				<p class="page-hero__sub"><?php esc_html_e( 'Accedi per vedere le tue pratiche e i documenti. Se hai difficoltà, scrivici su WhatsApp: ti aiutiamo noi.', 'hamza-theme' ); ?></p>
			</div>
		</header>

		<div class="container section">
			<div class="auth-wrap">

				<?php if ( '' !== trim( (string) get_post_field( 'post_content', get_the_ID() ) ) ) : ?>
					<div class="prose prose--intro"><?php the_content(); ?></div>
				<?php endif; ?>

				<?php if ( $humza_portal_ok ) : ?>
					<div class="portal-embed">
						<?php echo do_shortcode( '[hamza_portal]' ); // phpcs:ignore WordPress.Security.EscapeOutput -- output dello shortcode del plugin. ?>
					</div>
				<?php else : ?>
					<div class="form-msg form-msg--err" role="alert">
						<?php esc_html_e( 'L’area clienti non è al momento disponibile. Chiamaci o scrivici su WhatsApp: ti diciamo subito a che punto è la tua pratica.', 'hamza-theme' ); ?>
					</div>
				<?php endif; ?>

				<div class="auth-help">
					<h2><?php esc_html_e( 'Non riesci ad accedere?', 'hamza-theme' ); ?></h2>
					<p><?php esc_html_e( 'Nessun problema: scrivici il tuo nome su WhatsApp e ti diciamo noi a che punto è la tua pratica. Non serve nessun profilo per prenotare un appuntamento.', 'hamza-theme' ); ?></p>
					<div class="auth-actions">
						<a class="btn btn--wa btn--block-mobile" href="<?php echo esc_url( humza_wa_href( __( 'Ciao, ho bisogno di aiuto con l’area clienti del sito.', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer">
							<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema. ?>
							<?php esc_html_e( 'Scrivici su WhatsApp', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
						</a>
						<?php if ( $humza_phone ) : ?>
							<a class="btn btn--ghost btn--block-mobile" href="<?php echo esc_url( humza_phone_href( $humza_phone ) ); ?>">
								<?php echo humza_icon( 'ic-tel', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema. ?>
								<?php echo esc_html( $humza_phone ); ?>
							</a>
						<?php endif; ?>
						<a class="btn btn--primary btn--block-mobile" href="<?php echo esc_url( home_url( '/prenota/' ) ); ?>"><?php esc_html_e( 'Prenota appuntamento', 'hamza-theme' ); ?></a>
					</div>
				</div>

			</div>
		</div>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>
