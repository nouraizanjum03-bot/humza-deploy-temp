<?php
/**
 * Humza Multiservizi — Schema.org JSON-LD (@graph) emesso in wp_head.
 *
 * Nodi: LocalBusiness+ProfessionalService (#business, sitewide), WebSite (#website, sitewide),
 * Service (pagine servizio), FAQPage (slug faq), Article (post singoli),
 * BreadcrumbList (mai in front page), ContactPage/AboutPage (#webpage).
 *
 * Niente geo, niente priceRange, niente aggregateRating/review: solo dati verificati via humza_biz().
 */

defined( 'ABSPATH' ) || exit;

/* ---------- Helper: intervallo orario "09:00 - 13:00" → opens/closes ---------- */
function humza_schema_hours_interval( $range ) {
	$range = str_replace( '.', ':', (string) $range );
	if ( ! preg_match( '/(\d{1,2}:\d{2})\s*[-–—]\s*(\d{1,2}:\d{2})/u', $range, $m ) ) {
		return null;
	}
	return array(
		'opens'  => str_pad( $m[1], 5, '0', STR_PAD_LEFT ),
		'closes' => str_pad( $m[2], 5, '0', STR_PAD_LEFT ),
	);
}

/* ---------- Helper: openingHoursSpecification Lun-Sab dai due intervalli ---------- */
function humza_schema_opening_hours() {
	$days  = array( 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' );
	$specs = array();

	foreach ( array( humza_biz( 'hours_am' ), humza_biz( 'hours_pm' ) ) as $range ) {
		$interval = humza_schema_hours_interval( $range );
		if ( null === $interval ) {
			continue;
		}
		$specs[] = array(
			'@type'     => 'OpeningHoursSpecification',
			'dayOfWeek' => $days,
			'opens'     => $interval['opens'],
			'closes'    => $interval['closes'],
		);
	}

	return $specs;
}

/* ---------- Helper: meta description della pagina (excerpt → contenuto) ---------- */
function humza_schema_description( WP_Post $post ) {
	$desc = has_excerpt( $post ) ? get_the_excerpt( $post ) : '';

	if ( '' === trim( (string) $desc ) ) {
		$text = wp_strip_all_tags( excerpt_remove_blocks( strip_shortcodes( $post->post_content ) ) );
		$desc = wp_trim_words( $text, 32, '…' );
	}

	$desc = trim( wp_specialchars_decode( (string) $desc, ENT_QUOTES ) );

	// inc/meta.php può allineare la description dei meta tag via questo filtro.
	return (string) apply_filters( 'humza_schema_description', $desc, $post );
}

/* ---------- Helper: la pagina corrente è una pagina servizio? ---------- */
function humza_schema_is_service_page() {
	if ( ! is_page() ) {
		return false;
	}
	if ( is_page_template( 'template-service-single.php' ) ) {
		return true;
	}
	$post = get_queried_object();
	if ( ! $post instanceof WP_Post ) {
		return false;
	}
	if ( 'traduzioni' === $post->post_name ) {
		return true;
	}
	return $post->post_parent && 'servizi' === get_post_field( 'post_name', $post->post_parent );
}

/* ---------- Helper: appiattisce i blocchi contenitore (group/columns) ---------- */
function humza_schema_flatten_blocks( array $blocks ) {
	$flat       = array();
	$containers = array( 'core/group', 'core/columns', 'core/column' );

	foreach ( $blocks as $block ) {
		if ( in_array( $block['blockName'] ?? '', $containers, true ) && ! empty( $block['innerBlocks'] ) ) {
			$flat = array_merge( $flat, humza_schema_flatten_blocks( $block['innerBlocks'] ) );
		} else {
			$flat[] = $block;
		}
	}

	return $flat;
}

/* ---------- Helper: FAQ — h3 = Question, blocchi seguenti = acceptedAnswer ---------- */
function humza_schema_faq_entities( WP_Post $post ) {
	$blocks   = humza_schema_flatten_blocks( parse_blocks( $post->post_content ) );
	$entities = array();
	$question = '';
	$answer   = '';

	$flush = static function () use ( &$entities, &$question, &$answer ) {
		$question = trim( $question );
		$answer   = trim( preg_replace( '/\s+/u', ' ', $answer ) );
		if ( '' !== $question && '' !== $answer ) {
			$entities[] = array(
				'@type'          => 'Question',
				'name'           => $question,
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => mb_substr( $answer, 0, 1200 ),
				),
			);
		}
		$question = '';
		$answer   = '';
	};

	foreach ( $blocks as $block ) {
		$name = $block['blockName'] ?? '';

		if ( 'core/heading' === $name ) {
			$flush();
			$level = isset( $block['attrs']['level'] ) ? (int) $block['attrs']['level'] : 2;
			if ( 3 === $level || preg_match( '/<h3\b/i', (string) ( $block['innerHTML'] ?? '' ) ) ) {
				$question = wp_specialchars_decode( wp_strip_all_tags( (string) $block['innerHTML'] ), ENT_QUOTES );
			}
			continue;
		}

		if ( '' !== $question ) {
			$answer .= ' ' . wp_specialchars_decode( wp_strip_all_tags( render_block( $block ) ), ENT_QUOTES );
		}
	}
	$flush();

	return $entities;
}

/* ---------- Nodo #business (sitewide) ---------- */
function humza_schema_business_node( $business_id ) {
	$theme_uri = get_template_directory_uri();
	$phone     = preg_replace( '/\D/', '', humza_biz( 'phone1' ) );

	$node = array(
		'@type'         => array( 'LocalBusiness', 'ProfessionalService' ),
		'@id'           => $business_id,
		'name'          => humza_biz( 'name' ),
		'legalName'     => humza_biz( 'legalname' ),
		'vatID'         => humza_biz( 'piva' ),
		'url'           => home_url( '/' ),
		'image'         => $theme_uri . '/assets/img/og-default.png',
		'logo'          => $theme_uri . '/assets/img/logo-humza.svg',
		'address'       => array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => humza_biz( 'street' ),
			'postalCode'      => humza_biz( 'cap' ),
			'addressLocality' => humza_biz( 'city' ),
			'addressRegion'   => humza_biz( 'prov' ),
			'addressCountry'  => 'IT',
		),
		'knowsLanguage' => array( 'it', 'en', 'fr', 'ur', 'hi', 'pa' ),
	);

	if ( '' !== $phone ) {
		$node['telephone'] = '+39' . $phone;
	}
	if ( '' !== humza_biz( 'email' ) ) {
		$node['email'] = humza_biz( 'email' );
	}

	$hours = humza_schema_opening_hours();
	if ( array() !== $hours ) {
		$node['openingHoursSpecification'] = $hours;
	}

	$same_as = array_values( array_filter( array( humza_biz( 'tiktok' ), humza_biz( 'gbp' ) ) ) );
	if ( array() !== $same_as ) {
		$node['sameAs'] = $same_as;
	}

	$node['potentialAction'] = array(
		'@type'  => 'ReserveAction',
		'target' => array(
			'@type'       => 'EntryPoint',
			'urlTemplate' => home_url( '/prenota/' ),
		),
	);

	return $node;
}

/* ---------- Nodi legati alla pagina corrente ---------- */
function humza_schema_page_nodes( $business_id, $website_id ) {
	$nodes = array();
	$post  = get_queried_object();

	if ( ! $post instanceof WP_Post ) {
		return $nodes;
	}

	$permalink = get_permalink( $post );
	$title     = wp_specialchars_decode( get_the_title( $post ), ENT_QUOTES );

	// Pagine servizio → Service.
	if ( humza_schema_is_service_page() ) {
		$service = array(
			'@type'       => 'Service',
			'@id'         => $permalink . '#service',
			'name'        => $title,
			'serviceType' => $title,
			'url'         => $permalink,
			'provider'    => array( '@id' => $business_id ),
			'areaServed'  => __( 'Brescia e provincia', 'hamza-theme' ),
		);
		$description = humza_schema_description( $post );
		if ( '' !== $description ) {
			$service['description'] = $description;
		}
		$nodes[] = $service;
	}

	// Pagina FAQ → FAQPage (solo con almeno 2 domande).
	if ( is_page( 'faq' ) ) {
		$entities = humza_schema_faq_entities( $post );
		if ( count( $entities ) >= 2 ) {
			$nodes[] = array(
				'@type'      => 'FAQPage',
				'@id'        => $permalink . '#faq',
				'url'        => $permalink,
				'mainEntity' => $entities,
			);
		}
	}

	// Post singoli → Article.
	if ( is_singular( 'post' ) ) {
		$article = array(
			'@type'            => 'Article',
			'@id'              => $permalink . '#article',
			'headline'         => $title,
			'datePublished'    => get_the_date( 'c', $post ),
			'dateModified'     => get_the_modified_date( 'c', $post ),
			'mainEntityOfPage' => $permalink,
			'author'           => array( '@id' => $business_id ),
			'publisher'        => array( '@id' => $business_id ),
		);
		$thumb = get_the_post_thumbnail_url( $post, 'full' );
		if ( $thumb ) {
			$article['image'] = $thumb;
		}
		$nodes[] = $article;
	}

	// Contatti / Chi Siamo → WebPage tipizzata.
	if ( is_page( 'contatti' ) || is_page( 'chi-siamo' ) ) {
		$nodes[] = array(
			'@type'    => is_page( 'contatti' ) ? 'ContactPage' : 'AboutPage',
			'@id'      => $permalink . '#webpage',
			'url'      => $permalink,
			'name'     => $title,
			'isPartOf' => array( '@id' => $website_id ),
			'about'    => array( '@id' => $business_id ),
		);
	}

	return $nodes;
}

/* ---------- Nodo BreadcrumbList (mai in front page) ---------- */
function humza_schema_breadcrumb_node() {
	if ( is_front_page() || ! function_exists( 'humza_breadcrumb_items' ) ) {
		return null;
	}

	$items = humza_breadcrumb_items();
	if ( ! is_array( $items ) || count( $items ) < 2 ) {
		return null;
	}

	$list     = array();
	$position = 0;
	foreach ( $items as $item ) {
		$name = trim( wp_specialchars_decode( (string) ( $item['name'] ?? '' ), ENT_QUOTES ) );
		if ( '' === $name ) {
			continue;
		}
		$position++;
		$entry = array(
			'@type'    => 'ListItem',
			'position' => $position,
			'name'     => $name,
		);
		if ( ! empty( $item['url'] ) ) {
			$entry['item'] = $item['url'];
		}
		$list[] = $entry;
	}

	if ( count( $list ) < 2 ) {
		return null;
	}

	return array(
		'@type'           => 'BreadcrumbList',
		'itemListElement' => $list,
	);
}

/* ---------- Emissione in wp_head ---------- */
add_action( 'wp_head', 'humza_schema_print', 6 );
function humza_schema_print() {
	if ( is_admin() || is_feed() || is_robots() || is_embed() ) {
		return;
	}

	$home        = home_url( '/' );
	$business_id = $home . '#business';
	$website_id  = $home . '#website';

	$graph = array(
		humza_schema_business_node( $business_id ),
		array(
			'@type'     => 'WebSite',
			'@id'       => $website_id,
			'name'      => humza_biz( 'name' ),
			'url'       => $home,
			'publisher' => array( '@id' => $business_id ),
		),
	);

	if ( is_singular() ) {
		$graph = array_merge( $graph, humza_schema_page_nodes( $business_id, $website_id ) );
	}

	$breadcrumb = humza_schema_breadcrumb_node();
	if ( null !== $breadcrumb ) {
		$graph[] = $breadcrumb;
	}

	$json = wp_json_encode(
		array(
			'@context' => 'https://schema.org',
			'@graph'   => $graph,
		),
		JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
	);

	if ( ! is_string( $json ) ) {
		return;
	}

	// Impedisce la chiusura anticipata del tag script da contenuti utente ("</script>").
	$json = str_replace( '</', '<\/', $json );

	echo '<script type="application/ld+json">' . $json . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- JSON generato da wp_json_encode.
}
