<?php
/**
 * Humza Multiservizi — Customizer "Dati attività".
 *
 * Un setting + control per ogni chiave dei default di humza_biz()
 * (vedi functions.php). Il cliente aggiorna il NAP senza toccare codice.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sanifica un valore lasciando solo cifre (per il numero WhatsApp).
 *
 * @param mixed $value Valore grezzo dal Customizer.
 * @return string Solo cifre.
 */
if ( ! function_exists( 'humza_sanitize_digits' ) ) {
	function humza_sanitize_digits( $value ) {
		return preg_replace( '/\D/', '', (string) $value );
	}
}

add_action( 'customize_register', function ( WP_Customize_Manager $wp_customize ) {

	/* ---------- Pannello ---------- */
	$wp_customize->add_panel( 'humza_business', array(
		'title'       => __( 'Dati attività', 'hamza-theme' ),
		'description' => __( 'Recapiti, indirizzo, orari e link di Humza Multiservizi. Questi dati compaiono in tutto il sito: header, footer, contatti e dati strutturati.', 'hamza-theme' ),
		'priority'    => 30,
	) );

	/* ---------- Sezioni ---------- */
	$sections = array(
		'humza_business_sede'     => __( 'Attività e sede', 'hamza-theme' ),
		'humza_business_contatti' => __( 'Contatti', 'hamza-theme' ),
		'humza_business_orari'    => __( 'Orari di apertura', 'hamza-theme' ),
		'humza_business_link'     => __( 'Link e mappa', 'hamza-theme' ),
	);
	$section_priority = 10;
	foreach ( $sections as $section_id => $section_title ) {
		$wp_customize->add_section( $section_id, array(
			'panel'    => 'humza_business',
			'title'    => $section_title,
			'priority' => $section_priority,
		) );
		$section_priority += 10;
	}

	/* ---------- Campi: una voce per ogni chiave di humza_biz() ---------- */
	$fields = array(
		// Attività e sede.
		'name'      => array(
			'section'     => 'humza_business_sede',
			'label'       => __( 'Nome attività', 'hamza-theme' ),
			'description' => __( 'Nome commerciale mostrato sul sito (es. Humza Multiservizi).', 'hamza-theme' ),
			'default'     => 'Humza Multiservizi',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'text',
		),
		'legalname' => array(
			'section'     => 'humza_business_sede',
			'label'       => __( 'Ragione sociale', 'hamza-theme' ),
			'description' => __( 'Denominazione registrata della ditta, usata nei dati legali e nei dati strutturati.', 'hamza-theme' ),
			'default'     => 'ISHTIAQ HUMZA MULTISERVIZI',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'text',
		),
		'street'    => array(
			'section'     => 'humza_business_sede',
			'label'       => __( 'Indirizzo (via e civico)', 'hamza-theme' ),
			'description' => __( 'Es. Via Milano 7/D.', 'hamza-theme' ),
			'default'     => 'Via Milano 7/D',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'text',
		),
		'cap'       => array(
			'section'     => 'humza_business_sede',
			'label'       => __( 'CAP', 'hamza-theme' ),
			'description' => __( 'Codice di avviamento postale, 5 cifre (es. 25126).', 'hamza-theme' ),
			'default'     => '25126',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'text',
		),
		'city'      => array(
			'section'     => 'humza_business_sede',
			'label'       => __( 'Città', 'hamza-theme' ),
			'description' => __( 'Comune della sede (es. Brescia).', 'hamza-theme' ),
			'default'     => 'Brescia',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'text',
		),
		'prov'      => array(
			'section'     => 'humza_business_sede',
			'label'       => __( 'Provincia (sigla)', 'hamza-theme' ),
			'description' => __( 'Sigla di due lettere (es. BS).', 'hamza-theme' ),
			'default'     => 'BS',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'text',
		),
		'piva'      => array(
			'section'     => 'humza_business_sede',
			'label'       => __( 'Partita IVA', 'hamza-theme' ),
			'description' => __( '11 cifre, senza prefisso IT. Compare nel footer e nei dati legali.', 'hamza-theme' ),
			'default'     => '04586710982',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'text',
		),

		// Contatti.
		'phone1'    => array(
			'section'     => 'humza_business_contatti',
			'label'       => __( 'Telefono principale', 'hamza-theme' ),
			'description' => __( 'Numero mostrato sul sito, in formato leggibile (es. 324 092 0518). Il prefisso +39 viene aggiunto automaticamente ai link di chiamata.', 'hamza-theme' ),
			'default'     => '324 092 0518',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'tel',
		),
		'phone2'    => array(
			'section'     => 'humza_business_contatti',
			'label'       => __( 'Telefono secondario', 'hamza-theme' ),
			'description' => __( 'Secondo numero di telefono, in formato leggibile. Lascia vuoto se non serve.', 'hamza-theme' ),
			'default'     => '329 128 5317',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'tel',
		),
		'whatsapp'  => array(
			'section'     => 'humza_business_contatti',
			'label'       => __( 'Numero WhatsApp', 'hamza-theme' ),
			'description' => __( 'Solo cifre con prefisso 39, senza "+" né spazi (es. 393240920518). Usato per il pulsante "Scrivici su WhatsApp".', 'hamza-theme' ),
			'default'     => '393240920518',
			'sanitize'    => 'humza_sanitize_digits',
			'input'       => 'tel',
		),
		'email'     => array(
			'section'     => 'humza_business_contatti',
			'label'       => __( 'Email', 'hamza-theme' ),
			'description' => __( 'Indirizzo email di contatto mostrato sul sito.', 'hamza-theme' ),
			'default'     => 'centrovistibrescia@gmail.com',
			'sanitize'    => 'sanitize_email',
			'input'       => 'email',
		),

		// Orari di apertura.
		'hours_am'  => array(
			'section'     => 'humza_business_orari',
			'label'       => __( 'Orario mattina', 'hamza-theme' ),
			'description' => __( 'Fascia del mattino, es. 09:00 - 13:00.', 'hamza-theme' ),
			'default'     => '09:00 - 13:00',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'text',
		),
		'hours_pm'  => array(
			'section'     => 'humza_business_orari',
			'label'       => __( 'Orario pomeriggio', 'hamza-theme' ),
			'description' => __( 'Fascia del pomeriggio, es. 15:00 - 19:00.', 'hamza-theme' ),
			'default'     => '15:00 - 19:00',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'text',
		),
		'days'      => array(
			'section'     => 'humza_business_orari',
			'label'       => __( 'Giorni di apertura', 'hamza-theme' ),
			'description' => __( 'Es. Lun - Sab.', 'hamza-theme' ),
			'default'     => 'Lun - Sab',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'text',
		),

		// Link e mappa.
		'tiktok'    => array(
			'section'     => 'humza_business_link',
			'label'       => __( 'Profilo TikTok (URL)', 'hamza-theme' ),
			'description' => __( 'Indirizzo completo del profilo, es. https://www.tiktok.com/@nomeprofilo. Lascia vuoto per nascondere il link.', 'hamza-theme' ),
			'default'     => 'https://www.tiktok.com/@hamzamultiservizi',
			'sanitize'    => 'esc_url_raw',
			'input'       => 'url',
		),
		'gbp'       => array(
			'section'     => 'humza_business_link',
			'label'       => __( 'Recensioni Google (URL)', 'hamza-theme' ),
			'description' => __( 'Link alla scheda Google Business Profile o alle recensioni Google. Lascia vuoto per nascondere il link.', 'hamza-theme' ),
			'default'     => '',
			'sanitize'    => 'esc_url_raw',
			'input'       => 'url',
		),
		'maps_q'    => array(
			'section'     => 'humza_business_link',
			'label'       => __( 'Ricerca per la mappa', 'hamza-theme' ),
			'description' => __( 'Testo cercato su Google Maps per mostrare la mappa nella pagina Contatti (es. nome attività, via, città).', 'hamza-theme' ),
			'default'     => 'Humza Multiservizi, Via Milano, Brescia',
			'sanitize'    => 'sanitize_text_field',
			'input'       => 'text',
		),
	);

	$control_priority = 10;
	foreach ( $fields as $key => $field ) {
		$setting_id = 'humza_' . $key;

		$wp_customize->add_setting( $setting_id, array(
			'type'              => 'theme_mod',
			'capability'        => 'edit_theme_options',
			'default'           => $field['default'],
			'transport'         => 'refresh',
			'sanitize_callback' => $field['sanitize'],
		) );

		$wp_customize->add_control( $setting_id, array(
			'section'     => $field['section'],
			'label'       => $field['label'],
			'description' => $field['description'],
			'type'        => $field['input'],
			'priority'    => $control_priority,
		) );

		$control_priority += 10;
	}
} );
