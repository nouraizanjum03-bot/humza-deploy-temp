<?php
/**
 * Layer metadata: titoli documento, meta description, Open Graph/Twitter,
 * pulizia <head>, post meta SEO + metabox per redattori.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * 1. Titolo documento
 * ---------------------------------------------------------------------- */

add_filter( 'document_title_separator', function () {
	return '|';
} );

/**
 * Titolo personalizzato: post meta _humza_seo_title vince su tutto;
 * la front page ha un titolo brand fisso; il resto usa "{titolo} | Humza Multiservizi".
 */
add_filter( 'pre_get_document_title', function ( $title ) {
	if ( is_singular() ) {
		$custom = get_post_meta( get_queried_object_id(), '_humza_seo_title', true );
		if ( is_string( $custom ) && '' !== trim( $custom ) ) {
			return trim( $custom );
		}
	}
	if ( is_front_page() ) {
		return sprintf(
			/* translators: 1: nome attività, 2: descrittore servizi. */
			'%1$s — %2$s',
			humza_biz( 'name' ),
			__( 'Pratiche, CAF, Visti e Traduzioni a Brescia', 'hamza-theme' )
		);
	}
	return $title;
} );

// Le pagine interne compongono "{titolo} | Humza Multiservizi": niente tagline.
add_filter( 'document_title_parts', function ( $parts ) {
	$parts['site'] = humza_biz( 'name' );
	unset( $parts['tagline'] );
	return $parts;
} );

/* -------------------------------------------------------------------------
 * 2. Meta description (helper riusati anche da Open Graph)
 * ---------------------------------------------------------------------- */

/**
 * Tronca un testo a $limit caratteri senza spezzare l'ultima parola.
 *
 * @param string $text  Testo sorgente (può contenere HTML).
 * @param int    $limit Lunghezza massima in caratteri.
 * @return string Testo pulito, su una riga, entro il limite.
 */
function humza_truncate_at_word( $text, $limit = 155 ) {
	$text = wp_strip_all_tags( strip_shortcodes( (string) $text ) );
	$text = trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
	if ( '' === $text || mb_strlen( $text ) <= $limit ) {
		return $text;
	}
	$cut = mb_substr( $text, 0, $limit - 1 );
	// Elimina l'eventuale parola troncata in coda (se c'è almeno uno spazio).
	$cut = (string) preg_replace( '/\s+\S*$/u', '', $cut );
	return rtrim( $cut, " \t.,;:!?-" ) . '…';
}

/**
 * Descrizione generale di fallback (archivi, 404, home dei post).
 *
 * @return string
 */
function humza_default_description() {
	return sprintf(
		/* translators: 1: nome attività, 2: città. */
		__( '%1$s a %2$s: CAF, pratiche Prefettura e INPS, visti, servizi consolari e traduzioni. Assistenza in più lingue, su appuntamento.', 'hamza-theme' ),
		humza_biz( 'name' ),
		humza_biz( 'city' )
	);
}

/**
 * Meta description per la richiesta corrente.
 * Priorità su pagine/post: meta _humza_meta_desc → excerpt → contenuto troncato.
 *
 * @return string
 */
function humza_meta_description() {
	if ( is_singular() ) {
		$post_id = get_queried_object_id();
		$custom  = get_post_meta( $post_id, '_humza_meta_desc', true );
		if ( is_string( $custom ) && '' !== trim( $custom ) ) {
			return humza_truncate_at_word( $custom );
		}
		$post = get_post( $post_id );
		if ( $post instanceof WP_Post ) {
			$source = '' !== trim( $post->post_excerpt ) ? $post->post_excerpt : $post->post_content;
			$desc   = humza_truncate_at_word( $source );
			if ( '' !== $desc ) {
				return $desc;
			}
		}
	}
	return humza_truncate_at_word( humza_default_description() );
}

/**
 * URL canonico della richiesta corrente, con trailing slash.
 *
 * @return string
 */
function humza_canonical_url() {
	$url = '';

	if ( is_front_page() ) {
		$url = home_url( '/' );
	} elseif ( is_singular() ) {
		$url = get_permalink( get_queried_object_id() );
	} elseif ( is_home() ) {
		$page_for_posts = (int) get_option( 'page_for_posts' );
		$url            = $page_for_posts ? get_permalink( $page_for_posts ) : home_url( '/' );
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$term_link = get_term_link( get_queried_object() );
		$url       = is_wp_error( $term_link ) ? '' : $term_link;
	} elseif ( is_post_type_archive() ) {
		$url = (string) get_post_type_archive_link( get_query_var( 'post_type' ) );
	} elseif ( is_author() ) {
		$url = get_author_posts_url( (int) get_query_var( 'author' ) );
	}

	if ( ! is_string( $url ) || '' === $url ) {
		$url = home_url( '/' );
	}
	return trailingslashit( $url );
}

/**
 * Titolo "sociale" (senza suffisso brand: c'è già og:site_name).
 *
 * @return string
 */
function humza_og_title() {
	if ( is_singular() ) {
		$custom = get_post_meta( get_queried_object_id(), '_humza_seo_title', true );
		if ( is_string( $custom ) && '' !== trim( $custom ) ) {
			return trim( $custom );
		}
		if ( is_front_page() ) {
			return sprintf( '%1$s — %2$s', humza_biz( 'name' ), __( 'Pratiche, CAF, Visti e Traduzioni a Brescia', 'hamza-theme' ) );
		}
		return get_the_title( get_queried_object_id() );
	}
	if ( is_front_page() ) {
		return sprintf( '%1$s — %2$s', humza_biz( 'name' ), __( 'Pratiche, CAF, Visti e Traduzioni a Brescia', 'hamza-theme' ) );
	}
	if ( is_home() ) {
		$page_for_posts = (int) get_option( 'page_for_posts' );
		return $page_for_posts ? get_the_title( $page_for_posts ) : __( 'Novità', 'hamza-theme' );
	}
	if ( is_search() ) {
		return __( 'Risultati di ricerca', 'hamza-theme' );
	}
	if ( is_404() ) {
		return __( 'Pagina non trovata', 'hamza-theme' );
	}
	if ( is_archive() ) {
		return wp_strip_all_tags( get_the_archive_title() );
	}
	return humza_biz( 'name' );
}

/**
 * Immagine social: in evidenza della pagina se presente, altrimenti default 1200x630.
 *
 * @return array{url:string,width:int,height:int}
 */
function humza_og_image() {
	if ( is_singular() && has_post_thumbnail( get_queried_object_id() ) ) {
		$src = wp_get_attachment_image_src( get_post_thumbnail_id( get_queried_object_id() ), 'full' );
		if ( is_array( $src ) && ! empty( $src[0] ) ) {
			return array(
				'url'    => (string) $src[0],
				'width'  => (int) $src[1],
				'height' => (int) $src[2],
			);
		}
	}
	return array(
		'url'    => get_template_directory_uri() . '/assets/img/og-default.png',
		'width'  => 1200,
		'height' => 630,
	);
}

/* -------------------------------------------------------------------------
 * 3. Output in <head>: description + Open Graph + Twitter Card
 * ---------------------------------------------------------------------- */

add_action( 'wp_head', 'humza_output_meta_tags', 1 );

/**
 * Stampa i meta tag della richiesta corrente.
 */
function humza_output_meta_tags() {
	$desc    = humza_meta_description();
	$url     = humza_canonical_url();
	$title   = humza_og_title();
	$image   = humza_og_image();
	$is_post = is_singular( 'post' );
	$type    = $is_post ? 'article' : 'website';

	if ( '' !== $desc ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( $desc ) );
	}

	// Canonical per archivi/home blog: le singolari sono già coperte dal
	// rel_canonical di WP core (evitare il doppione).
	if ( ! is_singular() && '' !== $url ) {
		printf( '<link rel="canonical" href="%s">' . "\n", esc_url( $url ) );
	}

	printf( '<meta property="og:type" content="%s">' . "\n", esc_attr( $type ) );
	printf( '<meta property="og:url" content="%s">' . "\n", esc_url( $url ) );
	printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( $title ) );
	if ( '' !== $desc ) {
		printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( $desc ) );
	}
	printf( '<meta property="og:site_name" content="%s">' . "\n", esc_attr( humza_biz( 'name' ) ) );
	echo '<meta property="og:locale" content="it_IT">' . "\n";
	printf( '<meta property="og:image" content="%s">' . "\n", esc_url( $image['url'] ) );
	if ( $image['width'] > 0 && $image['height'] > 0 ) {
		printf( '<meta property="og:image:width" content="%d">' . "\n", (int) $image['width'] );
		printf( '<meta property="og:image:height" content="%d">' . "\n", (int) $image['height'] );
	}

	if ( $is_post ) {
		$post = get_post( get_queried_object_id() );
		if ( $post instanceof WP_Post ) {
			$published = get_post_time( DATE_W3C, true, $post );
			$modified  = get_post_modified_time( DATE_W3C, true, $post );
			if ( $published ) {
				printf( '<meta property="article:published_time" content="%s">' . "\n", esc_attr( $published ) );
			}
			if ( $modified ) {
				printf( '<meta property="article:modified_time" content="%s">' . "\n", esc_attr( $modified ) );
			}
		}
	}

	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	printf( '<meta name="twitter:title" content="%s">' . "\n", esc_attr( $title ) );
	if ( '' !== $desc ) {
		printf( '<meta name="twitter:description" content="%s">' . "\n", esc_attr( $desc ) );
	}
	printf( '<meta name="twitter:image" content="%s">' . "\n", esc_url( $image['url'] ) );
}

/* -------------------------------------------------------------------------
 * 4. Pulizia <head>
 * ---------------------------------------------------------------------- */

add_action( 'init', function () {
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'feed_links_extra', 3 ); // feed_links principale resta.
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	// rest_output_link_wp_head resta: serve al blocco iscrizione e all'editor.
} );

/* -------------------------------------------------------------------------
 * 5. Post meta SEO + metabox
 * ---------------------------------------------------------------------- */

const HUMZA_SEO_TITLE_MAX = 60;
const HUMZA_META_DESC_MAX = 155;

add_action( 'init', function () {
	$auth = function () {
		return current_user_can( 'edit_posts' );
	};
	foreach ( array( 'post', 'page' ) as $post_type ) {
		register_post_meta( $post_type, '_humza_seo_title', array(
			'type'              => 'string',
			'single'            => true,
			'default'           => '',
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
			'auth_callback'     => $auth,
		) );
		register_post_meta( $post_type, '_humza_meta_desc', array(
			'type'              => 'string',
			'single'            => true,
			'default'           => '',
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
			'auth_callback'     => $auth,
		) );
	}
} );

add_action( 'add_meta_boxes', function () {
	add_meta_box(
		'humza-seo',
		__( 'SEO', 'hamza-theme' ),
		'humza_seo_metabox_render',
		array( 'post', 'page' ),
		'normal',
		'default'
	);
} );

/**
 * Metabox SEO: titolo (max 60) e description (max 155), contatori statici.
 *
 * @param WP_Post $post Post in modifica.
 */
function humza_seo_metabox_render( $post ) {
	wp_nonce_field( 'humza_seo_save_' . $post->ID, 'humza_seo_nonce' );
	$title = (string) get_post_meta( $post->ID, '_humza_seo_title', true );
	$desc  = (string) get_post_meta( $post->ID, '_humza_meta_desc', true );
	?>
	<p>
		<label for="humza-seo-title"><strong><?php esc_html_e( 'Titolo SEO', 'hamza-theme' ); ?></strong></label><br>
		<input type="text" class="widefat" id="humza-seo-title" name="humza_seo_title"
			value="<?php echo esc_attr( $title ); ?>"
			maxlength="<?php echo (int) HUMZA_SEO_TITLE_MAX; ?>"
			aria-describedby="humza-seo-title-help">
		<span class="description" id="humza-seo-title-help">
			<?php
			printf(
				/* translators: 1: caratteri usati, 2: massimo consentito. */
				esc_html__( '%1$d/%2$d caratteri. Se vuoto, viene usato il titolo della pagina.', 'hamza-theme' ),
				(int) mb_strlen( $title ),
				(int) HUMZA_SEO_TITLE_MAX
			);
			?>
		</span>
	</p>
	<p>
		<label for="humza-meta-desc"><strong><?php esc_html_e( 'Meta description', 'hamza-theme' ); ?></strong></label><br>
		<textarea class="widefat" id="humza-meta-desc" name="humza_meta_desc" rows="3"
			maxlength="<?php echo (int) HUMZA_META_DESC_MAX; ?>"
			aria-describedby="humza-meta-desc-help"><?php echo esc_textarea( $desc ); ?></textarea>
		<span class="description" id="humza-meta-desc-help">
			<?php
			printf(
				/* translators: 1: caratteri usati, 2: massimo consentito. */
				esc_html__( '%1$d/%2$d caratteri. Se vuota, viene usato il riassunto della pagina.', 'hamza-theme' ),
				(int) mb_strlen( $desc ),
				(int) HUMZA_META_DESC_MAX
			);
			?>
		</span>
	</p>
	<?php
}

add_action( 'save_post', function ( $post_id, $post ) {
	if ( ! isset( $_POST['humza_seo_nonce'] )
		|| ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['humza_seo_nonce'] ) ), 'humza_seo_save_' . $post_id ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	if ( ! $post instanceof WP_Post || ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$fields = array(
		'humza_seo_title' => array( '_humza_seo_title', HUMZA_SEO_TITLE_MAX ),
		'humza_meta_desc' => array( '_humza_meta_desc', HUMZA_META_DESC_MAX ),
	);
	foreach ( $fields as $field => $spec ) {
		list( $meta_key, $max ) = $spec;
		$value = isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : '';
		$value = trim( mb_substr( $value, 0, $max ) );
		if ( '' !== $value ) {
			update_post_meta( $post_id, $meta_key, $value );
		} else {
			delete_post_meta( $post_id, $meta_key );
		}
	}
}, 10, 2 );

/* -------------------------------------------------------------------------
 * Allineamento con inc/schema.php: la description dei nodi Service/WebPage
 * dello schema usa la stessa meta description della pagina (quando esiste).
 * ---------------------------------------------------------------------- */
add_filter( 'humza_schema_description', function ( $desc, $post ) {
	if ( is_singular() ) {
		$meta = humza_meta_description();
		if ( '' !== $meta ) {
			return $meta;
		}
	}
	return $desc;
}, 10, 2 );
