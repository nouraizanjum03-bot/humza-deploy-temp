<?php
/**
 * Breadcrumb + fallback dei menu (quando i menu non sono assegnati).
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

/* ---------- Breadcrumb ---------- */

/**
 * Voce "Novità": pagina blog (page_for_posts) se impostata, altrimenti home.
 *
 * @return array{name:string,url:string}
 */
function humza_breadcrumb_blog_item(): array {
	$blog_id = (int) get_option( 'page_for_posts' );
	if ( $blog_id && 'publish' === get_post_status( $blog_id ) ) {
		return array(
			'name' => wp_specialchars_decode( get_the_title( $blog_id ), ENT_QUOTES ),
			'url'  => (string) get_permalink( $blog_id ),
		);
	}
	return array(
		'name' => __( 'Novità', 'hamza-theme' ),
		'url'  => home_url( '/' ),
	);
}

/**
 * Array ordinato di voci ['name','url']; l'ultima (pagina corrente) è senza 'url'.
 * Le pagine seguono la catena reale dei parent: niente antenati forzati.
 *
 * @return array<int, array{name:string, url?:string}>
 */
function humza_breadcrumb_items(): array {
	$items = array(
		array(
			'name' => __( 'Home', 'hamza-theme' ),
			'url'  => home_url( '/' ),
		),
	);

	if ( is_front_page() ) {
		return $items;
	}

	// Pagina blog ("Novità") come pagina corrente.
	if ( is_home() ) {
		$blog    = humza_breadcrumb_blog_item();
		$items[] = array( 'name' => $blog['name'] );
		return $items;
	}

	// Pagine: catena parent reale (es. Home > Servizi > Pratiche CAF).
	if ( is_page() ) {
		$page = get_queried_object();
		if ( $page instanceof WP_Post ) {
			foreach ( array_reverse( get_post_ancestors( $page ) ) as $ancestor_id ) {
				$items[] = array(
					'name' => wp_specialchars_decode( get_the_title( $ancestor_id ), ENT_QUOTES ),
					'url'  => (string) get_permalink( $ancestor_id ),
				);
			}
			$items[] = array( 'name' => wp_specialchars_decode( get_the_title( $page ), ENT_QUOTES ) );
		}
		return $items;
	}

	// Post: Home > Novità > titolo.
	if ( is_singular( 'post' ) ) {
		$items[] = humza_breadcrumb_blog_item();
		$items[] = array( 'name' => wp_specialchars_decode( get_the_title(), ENT_QUOTES ) );
		return $items;
	}

	// Archivi del blog: Home > Novità > nome.
	if ( is_category() || is_tag() || is_date() || is_author() ) {
		$items[] = humza_breadcrumb_blog_item();

		if ( is_category() || is_tag() ) {
			$name = single_term_title( '', false );
		} elseif ( is_day() ) {
			$name = get_the_date();
		} elseif ( is_month() ) {
			$name = get_the_date( 'F Y' );
		} elseif ( is_year() ) {
			$name = get_the_date( 'Y' );
		} else {
			$name = get_the_author();
		}

		$items[] = array( 'name' => wp_specialchars_decode( (string) $name, ENT_QUOTES ) );
		return $items;
	}

	if ( is_search() ) {
		$items[] = array(
			/* translators: %s: termine cercato. */
			'name' => sprintf( __( 'Ricerca: %s', 'hamza-theme' ), wp_specialchars_decode( get_search_query(), ENT_QUOTES ) ),
		);
		return $items;
	}

	if ( is_404() ) {
		$items[] = array( 'name' => __( 'Pagina non trovata', 'hamza-theme' ) );
		return $items;
	}

	// Altri singolari (allegati, CPT futuri).
	if ( is_singular() ) {
		$items[] = array( 'name' => wp_specialchars_decode( get_the_title(), ENT_QUOTES ) );
		return $items;
	}

	// Altri archivi: etichetta generica.
	$items[] = array( 'name' => wp_specialchars_decode( wp_strip_all_tags( get_the_archive_title() ), ENT_QUOTES ) );
	return $items;
}

/**
 * Stampa nav.breadcrumb (ol/li). Link su tutte le voci tranne l'ultima. Mai su front page.
 */
function humza_breadcrumb(): void {
	if ( is_front_page() ) {
		return;
	}

	$items = humza_breadcrumb_items();
	if ( count( $items ) < 2 ) {
		return;
	}

	$last = array_key_last( $items );

	echo '<nav class="breadcrumb" aria-label="' . esc_attr__( 'Percorso', 'hamza-theme' ) . '"><ol>';
	foreach ( $items as $i => $item ) {
		$name = isset( $item['name'] ) ? trim( (string) $item['name'] ) : '';
		if ( '' === $name ) {
			continue;
		}
		if ( $i !== $last && ! empty( $item['url'] ) ) {
			echo '<li><a href="' . esc_url( $item['url'] ) . '">' . esc_html( $name ) . '</a></li>';
		} else {
			$aria = ( $i === $last ) ? ' aria-current="page"' : '';
			echo '<li><span' . $aria . '>' . esc_html( $name ) . '</span></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $aria è letterale.
		}
	}
	echo '</ol></nav>';
}

/* ---------- Fallback dei menu ---------- */

/**
 * Risolve una pagina pubblicata per path in una voce di menu, o null se assente.
 *
 * @param string $path Slug/path della pagina.
 * @return array{name:string,url:string,id:int}|null
 */
function humza_page_menu_item( string $path ): ?array {
	$page = get_page_by_path( $path );
	if ( ! $page instanceof WP_Post || 'publish' !== $page->post_status ) {
		return null;
	}
	return array(
		'name' => wp_specialchars_decode( get_the_title( $page ), ENT_QUOTES ),
		'url'  => (string) get_permalink( $page ),
		'id'   => (int) $page->ID,
	);
}

/**
 * Stampa un elenco ul/li/a pulito con evidenza della voce corrente.
 *
 * @param array<int, array{name:string,url:string,id?:int,current?:bool}> $items Voci di menu.
 */
function humza_fallback_menu_print( array $items ): void {
	if ( empty( $items ) ) {
		return;
	}

	$current_id = (int) get_queried_object_id();

	echo '<ul class="menu">';
	foreach ( $items as $item ) {
		$name = isset( $item['name'] ) ? trim( (string) $item['name'] ) : '';
		$url  = isset( $item['url'] ) ? (string) $item['url'] : '';
		if ( '' === $name || '' === $url ) {
			continue;
		}
		$is_current = $item['current'] ?? ( ! empty( $item['id'] ) && $current_id === (int) $item['id'] );

		printf(
			'<li class="menu-item%1$s"><a href="%2$s"%3$s>%4$s</a></li>',
			$is_current ? ' current-menu-item' : '',
			esc_url( $url ),
			$is_current ? ' aria-current="page"' : '',
			esc_html( $name )
		);
	}
	echo '</ul>';
}

/**
 * Fallback menu principale: Home, Servizi, Chi Siamo, FAQ, Novità, Contatti.
 * Le pagine inesistenti vengono saltate.
 *
 * "Prenota" e "Area Clienti" sono volutamente esclusi: hanno gia' un posto
 * dedicato fuori dal menu (il bottone .header-cta nell'header e il link
 * .topbar__area nella topbar; su mobile la barra .mobile-actions e il blocco
 * .mobile-menu__contacts del drawer). Aggiungerli qui li duplicherebbe e
 * porterebbe la barra di navigazione a 8 voci, oltre il budget di larghezza
 * su cui e' calcolata .nav-main nella fascia 1024-1199px.
 *
 * @param array $args Argomenti di wp_nav_menu (non usati).
 */
function humza_nav_fallback( array $args = array() ): void {
	unset( $args );

	$items = array(
		array(
			'name'    => __( 'Home', 'hamza-theme' ),
			'url'     => home_url( '/' ),
			'current' => is_front_page(),
		),
	);

	foreach ( array( 'servizi', 'chi-siamo', 'faq' ) as $path ) {
		$item = humza_page_menu_item( $path );
		if ( $item ) {
			$items[] = $item;
		}
	}

	$blog_id = (int) get_option( 'page_for_posts' );
	if ( $blog_id && 'publish' === get_post_status( $blog_id ) ) {
		$items[] = array(
			'name' => wp_specialchars_decode( get_the_title( $blog_id ), ENT_QUOTES ),
			'url'  => (string) get_permalink( $blog_id ),
			'id'   => $blog_id,
		);
	}

	$item = humza_page_menu_item( 'contatti' );
	if ( $item ) {
		$items[] = $item;
	}

	humza_fallback_menu_print( $items );
}

/**
 * Fallback footer "Servizi": figlie di /servizi/ (menu_order) + pagina Traduzioni.
 *
 * @param array $args Argomenti di wp_nav_menu (non usati).
 */
function humza_footer_services_fallback( array $args = array() ): void {
	unset( $args );

	$service_pages = array();
	$servizi_page  = get_page_by_path( 'servizi' );
	if ( $servizi_page instanceof WP_Post && 'publish' === $servizi_page->post_status ) {
		$service_pages = (array) get_pages(
			array(
				'parent'      => $servizi_page->ID,
				'sort_column' => 'menu_order',
				'sort_order'  => 'asc',
			)
		);
	}

	$traduzioni = get_page_by_path( 'traduzioni' );
	if ( $traduzioni instanceof WP_Post && 'publish' === $traduzioni->post_status
		&& ! in_array( $traduzioni->ID, wp_list_pluck( $service_pages, 'ID' ), true ) ) {
		$service_pages[] = $traduzioni;
	}

	$items = array();
	foreach ( $service_pages as $sp ) {
		$items[] = array(
			'name' => wp_specialchars_decode( get_the_title( $sp ), ENT_QUOTES ),
			'url'  => (string) get_permalink( $sp ),
			'id'   => (int) $sp->ID,
		);
	}

	humza_fallback_menu_print( $items );
}

/**
 * Fallback footer "Link utili": Home, Chi Siamo, FAQ, Prenota, Area Clienti, Contatti, Privacy, Cookie.
 *
 * @param array $args Argomenti di wp_nav_menu (non usati).
 */
function humza_footer_links_fallback( array $args = array() ): void {
	unset( $args );

	$items = array(
		array(
			'name'    => __( 'Home', 'hamza-theme' ),
			'url'     => home_url( '/' ),
			'current' => is_front_page(),
		),
	);

	foreach ( array( 'chi-siamo', 'faq', 'prenota', 'area-clienti', 'contatti', 'privacy-policy', 'cookie-policy' ) as $path ) {
		$item = humza_page_menu_item( $path );
		if ( $item ) {
			$items[] = $item;
		}
	}

	humza_fallback_menu_print( $items );
}
