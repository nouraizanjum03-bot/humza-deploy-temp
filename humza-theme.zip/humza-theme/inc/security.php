<?php
/**
 * Humza Multiservizi — Hardening di sicurezza (fallback nel tema).
 *
 * Versione autonoma dell'hardening. Se è installato il mu-plugin
 * "humza-hardening.php" (che WordPress carica PRIMA del tema e che
 * definisce la costante HUMZA_HARDENING_LOADED), questo file esce
 * subito per evitare hook e funzioni duplicate.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * 8) Login fallito dal form dell'Area Clienti: riporta l'utente alla
 *    pagina del portale con un messaggio generico invece della schermata
 *    di errore di wp-login.php.
 *    Registrato PRIMA del guard sul mu-plugin: è una funzionalità del tema
 *    (il mu-plugin non la include) e deve restare attiva in ogni caso.
 * ---------------------------------------------------------------------- */
if ( ! function_exists( 'humza_login_failed_redirect' ) ) {
	function humza_login_failed_redirect() {
		$referrer = wp_get_referer();
		if ( $referrer && false !== strpos( $referrer, '/area-clienti' ) && ! isset( $_GET['loggedout'] ) ) {
			wp_safe_redirect( add_query_arg( 'login', 'failed', home_url( '/area-clienti/' ) ) );
			exit;
		}
	}
}
add_action( 'wp_login_failed', 'humza_login_failed_redirect' );

if ( defined( 'HUMZA_HARDENING_LOADED' ) ) {
	return; // Il mu-plugin è attivo: hardening già registrato altrove.
}

define( 'HUMZA_HARDENING_LOADED', true );

/* -------------------------------------------------------------------------
 * 1) REST API: nasconde l'elenco utenti ai visitatori non loggati.
 *    Si rimuovono SOLO gli endpoint /wp/v2/users (niente
 *    rest_authentication_errors: bloccherebbe anche plugin legittimi).
 * ---------------------------------------------------------------------- */
if ( ! function_exists( 'humza_rest_hide_users' ) ) {
	/**
	 * Rimuove gli endpoint utenti dalla REST API per i non autenticati.
	 *
	 * @param array $endpoints Endpoint REST registrati.
	 * @return array Endpoint filtrati.
	 */
	function humza_rest_hide_users( $endpoints ) {
		if ( is_user_logged_in() ) {
			return $endpoints;
		}
		unset(
			$endpoints['/wp/v2/users'],
			$endpoints['/wp/v2/users/(?P<id>[\d]+)']
		);
		return $endpoints;
	}
}
add_filter( 'rest_endpoints', 'humza_rest_hide_users' );

/* -------------------------------------------------------------------------
 * 2) Author enumeration: blocca ?author=N il prima possibile e
 *    reindirizza gli archivi autore alla home (301).
 * ---------------------------------------------------------------------- */
if ( ! function_exists( 'humza_block_author_query_string' ) ) {
	/**
	 * Blocca i tentativi di enumerazione via ?author=N prima del routing.
	 */
	function humza_block_author_query_string() {
		if ( is_admin() ) {
			return;
		}
		// Mai sulle richieste REST: qui "?author=N" è un filtro legittimo
		// (es. /wp-json/wp/v2/posts?author=1, block editor, plugin booking);
		// un redirect 301 HTML romperebbe i client JSON. L'enumerazione via
		// REST è già coperta dal filtro rest_endpoints (punto 1).
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( isset( $_GET['rest_route'] ) || false !== strpos( $request_uri, '/' . rest_get_url_prefix() . '/' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$author = isset( $_GET['author'] ) ? sanitize_text_field( wp_unslash( $_GET['author'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( '' !== $author ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}
}
add_action( 'parse_request', 'humza_block_author_query_string', 0 );

if ( ! function_exists( 'humza_block_author_archives' ) ) {
	/**
	 * Reindirizza gli archivi autore (e ogni query con author valorizzato)
	 * alla home page con 301.
	 */
	function humza_block_author_archives() {
		$author_var = get_query_var( 'author' );
		if ( is_author() || ( '' !== $author_var && null !== $author_var ) ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}
}
add_action( 'template_redirect', 'humza_block_author_archives', 0 );

/* -------------------------------------------------------------------------
 * 3) XML-RPC: disattivato (nessuna app remota lo usa) + header
 *    X-Pingback rimosso dalle risposte.
 * ---------------------------------------------------------------------- */
add_filter( 'xmlrpc_enabled', '__return_false' );

if ( ! function_exists( 'humza_remove_pingback_header' ) ) {
	/**
	 * Rimuove l'header X-Pingback dalle risposte HTTP.
	 *
	 * @param array $headers Header in uscita.
	 * @return array Header filtrati.
	 */
	function humza_remove_pingback_header( $headers ) {
		unset( $headers['X-Pingback'] );
		return $headers;
	}
}
add_filter( 'wp_headers', 'humza_remove_pingback_header' );

/* -------------------------------------------------------------------------
 * 4) Login: messaggio d'errore generico (non rivela se esiste l'utente)
 *    + oEmbed senza dati autore (niente user discovery indiretta).
 * ---------------------------------------------------------------------- */
if ( ! function_exists( 'humza_generic_login_error' ) ) {
	/**
	 * Sostituisce ogni errore di login con un messaggio generico.
	 *
	 * @param string $error Messaggio d'errore originale.
	 * @return string Messaggio generico.
	 */
	function humza_generic_login_error( $error ) {
		if ( '' === trim( (string) $error ) ) {
			return $error;
		}
		return esc_html__( 'Credenziali non valide.', 'hamza-theme' );
	}
}
add_filter( 'login_errors', 'humza_generic_login_error' );

if ( ! function_exists( 'humza_oembed_strip_author' ) ) {
	/**
	 * Rimuove nome e URL autore dalle risposte oEmbed.
	 *
	 * @param array $data Dati della risposta oEmbed.
	 * @return array Dati filtrati.
	 */
	function humza_oembed_strip_author( $data ) {
		if ( is_array( $data ) ) {
			unset( $data['author_url'], $data['author_name'] );
		}
		return $data;
	}
}
add_filter( 'oembed_response_data', 'humza_oembed_strip_author' );

/* -------------------------------------------------------------------------
 * 5) Security header sul frontend (non admin). HSTS NON va impostato
 *    qui: si attiva, consapevolmente, in .htaccess (vedi
 *    htaccess-additions.txt, blocco commentato).
 * ---------------------------------------------------------------------- */
if ( ! function_exists( 'humza_security_headers' ) ) {
	/**
	 * Invia gli header di sicurezza sulle risposte frontend.
	 */
	function humza_security_headers() {
		if ( is_admin() || headers_sent() ) {
			return;
		}
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
	}
}
add_action( 'send_headers', 'humza_security_headers' );

/* -------------------------------------------------------------------------
 * 6) Nasconde la versione di WordPress (meta generator + feed).
 * ---------------------------------------------------------------------- */
remove_action( 'wp_head', 'wp_generator' );
add_filter( 'the_generator', '__return_empty_string' );

/* -------------------------------------------------------------------------
 * 7) Pingback disattivati (spam vector); i commenti normali restano
 *    gestibili come sempre da wp-admin.
 * ---------------------------------------------------------------------- */
add_filter( 'pings_open', '__return_false', 20 );
