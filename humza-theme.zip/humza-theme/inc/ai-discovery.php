<?php
/**
 * Reperibilità sui motori di ricerca con IA.
 *
 * Serve /llms.txt (scheda dell'attività leggibile dagli assistenti come
 * ChatGPT, Perplexity e Google AI) senza creare file sul server, e dichiara
 * esplicitamente in robots.txt che i crawler delle IA sono benvenuti: per un
 * centro pratiche le risposte degli assistenti valgono quanto i risultati
 * di ricerca classici.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * /llms.txt generato al volo
 * ---------------------------------------------------------------------- */

add_action( 'init', function () {
	add_rewrite_rule( '^llms\.txt$', 'index.php?humza_llms=1', 'top' );
} );

add_filter( 'query_vars', function ( $vars ) {
	$vars[] = 'humza_llms';
	return $vars;
} );

add_action( 'template_redirect', function () {
	if ( ! get_query_var( 'humza_llms' ) ) {
		return;
	}

	nocache_headers();
	header( 'Content-Type: text/plain; charset=utf-8' );

	$righe   = array();
	$righe[] = '# ' . humza_biz( 'name' );
	$righe[] = '';
	$righe[] = '> Centro multiservizi a ' . humza_biz( 'city' ) . ': assistenza fiscale e CAF, pratiche di immigrazione, servizi consolari, visti e traduzioni certificate. Assistenza in 6 lingue (italiano, inglese, francese, urdu, hindi, punjabi).';
	$righe[] = '';
	$righe[] = '## Dati dell’attività';
	$righe[] = '';
	$righe[] = '- Ragione sociale: ' . humza_biz( 'legalname' );
	$righe[] = '- Partita IVA: ' . humza_biz( 'piva' );
	$righe[] = '- Indirizzo: ' . humza_biz( 'street' ) . ', ' . humza_biz( 'cap' ) . ' ' . humza_biz( 'city' ) . ' (' . humza_biz( 'prov' ) . '), Italia';
	$righe[] = '- Telefono: ' . humza_biz( 'phone1' ) . ( humza_biz( 'phone2' ) ? ' / ' . humza_biz( 'phone2' ) : '' );
	$righe[] = '- Email: ' . humza_biz( 'email' );
	$righe[] = '- Orari: ' . humza_biz( 'days' ) . ' ' . humza_biz( 'hours_am' ) . ' e ' . humza_biz( 'hours_pm' ) . '; domenica chiuso';
	$righe[] = '- Lingue parlate: italiano, inglese, francese, urdu, hindi, punjabi';
	$righe[] = '';
	$righe[] = '## Pagine principali';
	$righe[] = '';

	$servizi_page = get_page_by_path( 'servizi' );
	$pagine       = array();
	if ( $servizi_page instanceof WP_Post ) {
		$pagine = get_pages(
			array(
				'parent'      => $servizi_page->ID,
				'sort_column' => 'menu_order',
			)
		);
	}

	$righe[] = '- [Home](' . home_url( '/' ) . '): panoramica dei servizi e prenotazione appuntamento.';
	if ( $servizi_page instanceof WP_Post ) {
		$righe[] = '- [Servizi](' . get_permalink( $servizi_page ) . '): elenco completo dei servizi.';
	}
	foreach ( $pagine as $p ) {
		$desc = get_post_meta( $p->ID, '_humza_meta_desc', true );
		if ( '' === $desc ) {
			$desc = wp_strip_all_tags( get_the_excerpt( $p ) );
		}
		$righe[] = '- [' . get_the_title( $p ) . '](' . get_permalink( $p ) . '): ' . wp_trim_words( $desc, 24, '' );
	}

	foreach ( array(
		'chi-siamo' => 'Chi siamo e come lavoriamo.',
		'faq'       => 'Domande frequenti su documenti, tempi e appuntamenti.',
		'prenota'   => 'Prenotazione appuntamento online.',
		'contatti'  => 'Contatti, indirizzo e orari.',
		'novita'    => 'Avvisi, scadenze e novità.',
	) as $slug => $desc ) {
		$pg = get_page_by_path( $slug );
		if ( $pg instanceof WP_Post && 'publish' === $pg->post_status ) {
			$righe[] = '- [' . get_the_title( $pg ) . '](' . get_permalink( $pg ) . '): ' . $desc;
		}
	}

	$righe[] = '';
	$righe[] = '## Note';
	$righe[] = '';
	$righe[] = '- I contenuti sono in italiano; il sito offre traduzione automatica in inglese, francese, urdu, hindi e punjabi.';
	$righe[] = '- Per lo stato di una pratica il canale corretto è il contatto diretto (telefono o WhatsApp), non il sito.';
	$righe[] = '- Ultimo aggiornamento: ' . wp_date( 'Y-m-d' );

	echo implode( "\n", $righe ) . "\n";
	exit;
} );

/* -------------------------------------------------------------------------
 * robots.txt: crawler delle IA ammessi esplicitamente
 * ---------------------------------------------------------------------- */

add_filter( 'robots_txt', function ( $output ) {
	$extra   = array();
	$extra[] = '';
	$extra[] = '# Assistenti IA: contenuti liberamente consultabili.';
	foreach ( array( 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-Web', 'PerplexityBot', 'Google-Extended', 'Applebot-Extended', 'CCBot' ) as $bot ) {
		$extra[] = 'User-agent: ' . $bot;
		$extra[] = 'Allow: /';
		$extra[] = '';
	}
	$extra[] = 'Sitemap: ' . home_url( '/wp-sitemap.xml' );
	$extra[] = 'Llms: ' . home_url( '/llms.txt' );

	return $output . implode( "\n", $extra ) . "\n";
}, 20 );

/* -------------------------------------------------------------------------
 * Le regole di riscrittura vanno rigenerate una volta sola dopo l'attivazione.
 * ---------------------------------------------------------------------- */

add_action( 'after_switch_theme', function () {
	flush_rewrite_rules();
} );
