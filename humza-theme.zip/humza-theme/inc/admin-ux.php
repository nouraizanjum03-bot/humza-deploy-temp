<?php
/**
 * Humza Multiservizi — Pannello semplice per il titolare (admin UX).
 *
 * Obiettivo: chi gestisce il sito (non tecnico, spesso da smartphone, italiano
 * non madrelingua) deve riuscire da solo a pubblicare una novità, cambiare
 * orari e recapiti, aggiungere una domanda alle FAQ e correggere un testo,
 * senza chiamare nessuno.
 *
 * Indice del file:
 *  1. Helper (URL admin, rilevamento plugin prenotazioni, pagina FAQ)
 *  2. Foglio di stile del pannello
 *  3. Widget di bacheca "Gestisci il tuo sito"
 *  4. Pulizia della bacheca
 *  5. Pagina "Guida al sito"
 *  6. Pattern di blocchi pronti (categoria "Humza" + cartella /patterns)
 *  7. Semplificazioni dell'editor e delle liste
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

/** Slug della pagina "Guida al sito" nel menu di amministrazione. */
const HUMZA_ADMIN_GUIDE_SLUG = 'humza-guida';

/** Template della pagina FAQ (usato per trovarne l'ID). */
const HUMZA_ADMIN_FAQ_TEMPLATE = 'page-templates/template-faq.php';

/* -------------------------------------------------------------------------
 * 1. Helper
 * ---------------------------------------------------------------------- */

/**
 * Versione di un asset del tema (fallback se functions.php non è caricato).
 *
 * @param string $rel Percorso relativo alla root del tema.
 * @return string
 */
function humza_admin_asset_ver( $rel ) {
	if ( function_exists( 'humza_asset_ver' ) ) {
		return humza_asset_ver( $rel );
	}
	$file = get_template_directory() . $rel;
	return file_exists( $file ) ? (string) filemtime( $file ) : '2.0.0';
}

/**
 * URL della pagina "Guida al sito".
 *
 * @return string
 */
function humza_admin_guide_url() {
	return admin_url( 'admin.php?page=' . HUMZA_ADMIN_GUIDE_SLUG );
}

/**
 * URL del Customizer aperto direttamente sul pannello "Dati attività".
 *
 * @return string
 */
function humza_admin_business_url() {
	return add_query_arg(
		array(
			'autofocus[panel]' => 'humza_business',
			'return'           => admin_url( 'index.php' ),
		),
		admin_url( 'customize.php' )
	);
}

/**
 * Compone l'URL di una voce di menu admin a partire dal suo slug.
 *
 * @param string $slug   Slug della voce (può essere un file .php o uno slug di pagina).
 * @param string $parent Slug del menu genitore, per le sottovoci.
 * @return string URL assoluto in area amministrativa.
 */
function humza_admin_menu_url( $slug, $parent = '' ) {
	$slug = (string) $slug;

	// Voci che puntano già a un file dell'admin (es. edit.php?post_type=...).
	if ( false !== strpos( $slug, '.php' ) ) {
		return admin_url( $slug );
	}

	if ( '' !== $parent && false !== strpos( $parent, '.php' ) ) {
		$separator = ( false !== strpos( $parent, '?' ) ) ? '&' : '?';
		return admin_url( $parent . $separator . 'page=' . rawurlencode( $slug ) );
	}

	return admin_url( 'admin.php?page=' . rawurlencode( $slug ) );
}

/**
 * Cerca nel menu di amministrazione la pagina del plugin prenotazioni.
 *
 * Il tema non dipende dal plugin: se non è installato/attivo la voce
 * corrispondente semplicemente non viene mostrata.
 *
 * @return string URL della pagina prenotazioni, stringa vuota se assente.
 */
function humza_admin_booking_url() {
	static $cached = null;
	if ( null !== $cached ) {
		return $cached;
	}
	$cached = '';

	global $menu, $submenu;

	$needle  = '/(booking|prenotazion|prenota|appuntament|appointment)/i';
	$ignored = array( HUMZA_ADMIN_GUIDE_SLUG );

	if ( is_array( $menu ) ) {
		foreach ( $menu as $item ) {
			if ( ! is_array( $item ) || empty( $item[2] ) ) {
				continue;
			}
			$slug = (string) $item[2];
			if ( in_array( $slug, $ignored, true ) ) {
				continue;
			}
			$label = isset( $item[0] ) ? wp_strip_all_tags( (string) $item[0] ) : '';
			if ( ! preg_match( $needle, $slug ) && ! preg_match( $needle, $label ) ) {
				continue;
			}
			if ( ! empty( $item[1] ) && ! current_user_can( (string) $item[1] ) ) {
				continue;
			}
			$cached = humza_admin_menu_url( $slug );
			return $cached;
		}
	}

	if ( is_array( $submenu ) ) {
		foreach ( $submenu as $parent => $items ) {
			if ( ! is_array( $items ) ) {
				continue;
			}
			foreach ( $items as $item ) {
				if ( ! is_array( $item ) || empty( $item[2] ) ) {
					continue;
				}
				$slug = (string) $item[2];
				if ( in_array( $slug, $ignored, true ) ) {
					continue;
				}
				$label = isset( $item[0] ) ? wp_strip_all_tags( (string) $item[0] ) : '';
				if ( ! preg_match( $needle, $slug ) && ! preg_match( $needle, $label ) ) {
					continue;
				}
				if ( ! empty( $item[1] ) && ! current_user_can( (string) $item[1] ) ) {
					continue;
				}
				$cached = humza_admin_menu_url( $slug, (string) $parent );
				return $cached;
			}
		}
	}

	return $cached;
}

/**
 * ID della pagina FAQ (per template assegnato, con fallback sugli slug noti).
 *
 * @return int ID della pagina, 0 se non esiste.
 */
function humza_admin_faq_page_id() {
	static $cached = null;
	if ( null !== $cached ) {
		return $cached;
	}
	$cached = 0;

	$found = get_posts(
		array(
			'post_type'        => 'page',
			'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future' ),
			'numberposts'      => 1,
			'fields'           => 'ids',
			'meta_key'         => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'       => HUMZA_ADMIN_FAQ_TEMPLATE, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'no_found_rows'    => true,
			'suppress_filters' => false,
		)
	);

	if ( ! empty( $found ) ) {
		$cached = (int) $found[0];
		return $cached;
	}

	foreach ( array( 'faq', 'domande-frequenti' ) as $slug ) {
		$page = get_page_by_path( $slug );
		if ( $page instanceof WP_Post ) {
			$cached = (int) $page->ID;
			return $cached;
		}
	}

	return $cached;
}

/**
 * Azioni rapide mostrate nel widget di bacheca e in cima alla guida.
 *
 * Ogni voce è filtrata sui permessi dell'utente corrente: chi non può fare
 * una cosa non ne vede il pulsante.
 *
 * @return array<int,array<string,string>> Elenco di azioni.
 */
function humza_admin_actions() {
	$actions = array();

	if ( current_user_can( 'edit_posts' ) ) {
		$actions[] = array(
			'url'   => admin_url( 'post-new.php' ),
			'icon'  => 'dashicons-edit',
			'title' => __( 'Scrivi una novità', 'hamza-theme' ),
			'desc'  => __( 'Avvisi, scadenze, chiusure: compaiono in home e nella pagina Novità.', 'hamza-theme' ),
		);
	}

	if ( current_user_can( 'edit_theme_options' ) ) {
		$actions[] = array(
			'url'   => humza_admin_business_url(),
			'icon'  => 'dashicons-phone',
			'title' => __( 'Modifica orari e telefoni', 'hamza-theme' ),
			'desc'  => __( 'Cambi il dato una volta e si aggiorna in tutto il sito.', 'hamza-theme' ),
		);
	}

	$faq_id = humza_admin_faq_page_id();
	if ( $faq_id && current_user_can( 'edit_post', $faq_id ) ) {
		$faq_link = get_edit_post_link( $faq_id, 'raw' );
		if ( $faq_link ) {
			$actions[] = array(
				'url'   => $faq_link,
				'icon'  => 'dashicons-editor-help',
				'title' => __( 'Modifica le FAQ', 'hamza-theme' ),
				'desc'  => __( 'Aggiungi una domanda e la sua risposta alle domande frequenti.', 'hamza-theme' ),
			);
		}
	}

	$booking_url = humza_admin_booking_url();
	if ( '' !== $booking_url ) {
		$actions[] = array(
			'url'   => $booking_url,
			'icon'  => 'dashicons-calendar-alt',
			'title' => __( 'Vedi le prenotazioni', 'hamza-theme' ),
			'desc'  => __( 'Giorno, ora e recapito di chi ha prenotato un appuntamento.', 'hamza-theme' ),
		);
	}

	if ( current_user_can( 'edit_pages' ) ) {
		$actions[] = array(
			'url'   => admin_url( 'edit.php?post_type=page' ),
			'icon'  => 'dashicons-admin-page',
			'title' => __( 'Modifica le pagine', 'hamza-theme' ),
			'desc'  => __( 'Testi dei servizi, Chi siamo, Contatti.', 'hamza-theme' ),
		);
		$actions[] = array(
			'url'   => humza_admin_guide_url(),
			'icon'  => 'dashicons-book',
			'title' => __( 'Guida all\'uso', 'hamza-theme' ),
			'desc'  => __( 'Istruzioni passo passo, in italiano semplice.', 'hamza-theme' ),
		);
	}

	return $actions;
}

/**
 * Stampa la griglia delle azioni rapide.
 */
function humza_admin_render_actions() {
	$actions = humza_admin_actions();
	if ( empty( $actions ) ) {
		return;
	}
	?>
	<nav class="humza-actions" aria-label="<?php esc_attr_e( 'Azioni rapide', 'hamza-theme' ); ?>">
		<?php foreach ( $actions as $action ) : ?>
			<a class="humza-action" href="<?php echo esc_url( $action['url'] ); ?>">
				<span class="humza-action__icon dashicons <?php echo esc_attr( $action['icon'] ); ?>" aria-hidden="true"></span>
				<span class="humza-action__text">
					<span class="humza-action__title"><?php echo esc_html( $action['title'] ); ?></span>
					<span class="humza-action__desc"><?php echo esc_html( $action['desc'] ); ?></span>
				</span>
			</a>
		<?php endforeach; ?>
	</nav>
	<?php
}

/* -------------------------------------------------------------------------
 * 2. Foglio di stile del pannello
 * ---------------------------------------------------------------------- */

/**
 * Carica assets/css/admin.css solo dove serve davvero:
 * bacheca, liste contenuti, editor (per il riquadro Riassunto) e guida.
 *
 * @param string $hook Hook della schermata corrente.
 */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	$screens = array(
		'index.php',
		'edit.php',
		'post.php',
		'post-new.php',
		'toplevel_page_' . HUMZA_ADMIN_GUIDE_SLUG,
	);
	if ( ! in_array( $hook, $screens, true ) ) {
		return;
	}
	wp_enqueue_style(
		'humza-admin',
		get_template_directory_uri() . '/assets/css/admin.css',
		array(),
		humza_admin_asset_ver( '/assets/css/admin.css' )
	);
} );

/**
 * Font del sito anche dentro l'editor a blocchi: così il titolare vede
 * il testo come apparirà davvero online (editor.css usa gli stessi font).
 * `enqueue_block_assets` in admin inietta lo stile nell'iframe dell'editor.
 */
add_action( 'enqueue_block_assets', function () {
	if ( ! is_admin() ) {
		return;
	}
	wp_enqueue_style(
		'humza-fonts',
		'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap',
		array(),
		null // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion — CDN con versione nell'URL.
	);
} );

/* -------------------------------------------------------------------------
 * 3. Widget di bacheca "Gestisci il tuo sito"
 * ---------------------------------------------------------------------- */

/**
 * Registra il widget e lo sposta in cima alla colonna principale.
 */
add_action( 'wp_dashboard_setup', function () {
	if ( ! current_user_can( 'edit_posts' ) ) {
		return;
	}

	wp_add_dashboard_widget(
		'humza_dashboard_guide',
		__( 'Gestisci il tuo sito', 'hamza-theme' ),
		'humza_admin_dashboard_widget_render'
	);

	// wp_add_dashboard_widget accoda: riportiamo il riquadro al primo posto.
	global $wp_meta_boxes;
	if ( ! isset( $wp_meta_boxes['dashboard']['normal']['core']['humza_dashboard_guide'] ) ) {
		return;
	}
	$core = $wp_meta_boxes['dashboard']['normal']['core'];
	$ours = array( 'humza_dashboard_guide' => $core['humza_dashboard_guide'] );
	unset( $core['humza_dashboard_guide'] );
	$wp_meta_boxes['dashboard']['normal']['core'] = array_merge( $ours, $core );
}, 99 );

/**
 * Contenuto del widget: poche azioni grandi, spiegate in una riga.
 */
function humza_admin_dashboard_widget_render() {
	?>
	<div class="humza-panel">
		<p class="humza-panel__intro">
			<?php esc_html_e( 'Le cose che servono più spesso. Tocca un pulsante e sei già al punto giusto.', 'hamza-theme' ); ?>
		</p>
		<?php humza_admin_render_actions(); ?>
		<p class="humza-panel__foot">
			<?php esc_html_e( 'Il sito pubblico:', 'hamza-theme' ); ?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener noreferrer">
				<?php echo esc_html( wp_parse_url( home_url( '/' ), PHP_URL_HOST ) ); ?>
			</a>
		</p>
	</div>
	<?php
}

/* -------------------------------------------------------------------------
 * 4. Pulizia della bacheca
 * ---------------------------------------------------------------------- */

/**
 * Toglie i riquadri che non servono a chi gestisce questo sito
 * (notizie di WordPress, Attività, Bozza rapida, eventi).
 * Nessuna voce di menu viene nascosta: l'amministratore tecnico
 * continua a vedere tutto il resto di WordPress.
 */
add_action( 'wp_dashboard_setup', function () {
	$boxes = array(
		'dashboard_primary',     // Eventi e notizie di WordPress.
		'dashboard_secondary',   // Altre notizie WordPress.
		'dashboard_quick_press', // Bozza rapida.
		'dashboard_activity',    // Attività.
	);
	// Il contesto di questi riquadri è cambiato tra le versioni di WordPress:
	// li togliamo da entrambe le colonne (rimuovere un riquadro assente è
	// un'operazione neutra).
	foreach ( $boxes as $box ) {
		remove_meta_box( $box, 'dashboard', 'normal' );
		remove_meta_box( $box, 'dashboard', 'side' );
	}

	// Pannello "Benvenuto in WordPress": rumore per il titolare. La rimozione
	// va fatta qui: l'hook viene registrato quando WordPress carica l'API
	// della bacheca, cioè dopo l'azione load-index.php.
	remove_action( 'welcome_panel', 'wp_welcome_panel' );
}, 100 );

/* -------------------------------------------------------------------------
 * 5. Pagina "Guida al sito"
 * ---------------------------------------------------------------------- */

/**
 * Voce di menu con icona, subito sotto la Bacheca: dev'essere trovabile
 * a colpo d'occhio anche da smartphone (una sottovoce nascosta non lo è).
 */
add_action( 'admin_menu', function () {
	add_menu_page(
		__( 'Guida al sito', 'hamza-theme' ),
		__( 'Guida al sito', 'hamza-theme' ),
		'edit_pages',
		HUMZA_ADMIN_GUIDE_SLUG,
		'humza_admin_guide_page_render',
		'dashicons-book',
		3
	);
} );

/**
 * Riquadro informativo riutilizzato nella guida.
 *
 * @param string $text  Testo del riquadro.
 * @param string $type  'note' (arancio), 'warn' (rosso) o 'ok' (verde).
 */
function humza_admin_note( $text, $type = 'note' ) {
	$allowed = array( 'note', 'warn', 'ok' );
	$type    = in_array( $type, $allowed, true ) ? $type : 'note';
	printf(
		'<p class="humza-note humza-note--%1$s">%2$s</p>',
		esc_attr( $type ),
		esc_html( $text )
	);
}

/**
 * Contenuto della pagina "Guida al sito": italiano semplice, frasi corte.
 */
function humza_admin_guide_page_render() {
	if ( ! current_user_can( 'edit_pages' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per vedere questa pagina.', 'hamza-theme' ) );
	}

	$biz_phone = function_exists( 'humza_biz' ) ? humza_biz( 'phone1' ) : '';
	$biz_hours = function_exists( 'humza_biz' ) ? humza_biz( 'hours_am' ) . ' / ' . humza_biz( 'hours_pm' ) : '';
	$faq_id    = humza_admin_faq_page_id();
	?>
	<div class="wrap humza-guide">

		<h1 class="humza-guide__title"><?php esc_html_e( 'Guida al sito', 'hamza-theme' ); ?></h1>
		<p class="humza-guide__lead">
			<?php esc_html_e( 'Qui trovi tutto quello che serve per gestire il sito da solo, anche dal telefono. Non serve toccare il codice.', 'hamza-theme' ); ?>
		</p>

		<?php humza_admin_render_actions(); ?>

		<div class="humza-guide__grid">

			<section class="humza-guide__card">
				<h2><?php esc_html_e( '1. Pubblicare una novità', 'hamza-theme' ); ?></h2>
				<p><?php esc_html_e( 'Le "Novità" compaiono in homepage e nella pagina Novità. Usale per scadenze fiscali (730, ISEE), chiusure per ferie, nuovi servizi, cambi di orario dei consolati.', 'hamza-theme' ); ?></p>
				<ol>
					<li><?php esc_html_e( 'Menu a sinistra: Articoli, poi "Aggiungi articolo".', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Scrivi il titolo, chiaro e breve (es. "Dichiarazione 730: da quando si può fare").', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Scrivi il testo con frasi corte. Per gli elenchi usa il tasto + e scegli "Elenco".', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'A destra scegli una Categoria (es. CAF e Fiscale, Consolati, Avvisi).', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Premi Pubblica, in alto a destra, e conferma.', 'hamza-theme' ); ?></li>
				</ol>
				<?php humza_admin_note( __( 'Scorciatoia: premi il tasto + in alto a sinistra, apri "Modelli" e scegli la categoria "Humza". Trovi la novità già impostata: sostituisci i testi di esempio e pubblica.', 'hamza-theme' ) ); ?>
				<p><?php esc_html_e( 'Per correggere un articolo già pubblicato: Articoli, Tutti gli articoli, poi clicca sul titolo.', 'hamza-theme' ); ?></p>
			</section>

			<section class="humza-guide__card">
				<h2><?php esc_html_e( '2. Cambiare telefono, orari, indirizzo, email', 'hamza-theme' ); ?></h2>
				<p><?php esc_html_e( 'Questi dati compaiono in tutto il sito: intestazione, fondo pagina, pagina Contatti e informazioni che legge Google. Si cambiano in un posto solo.', 'hamza-theme' ); ?></p>
				<ol>
					<li><?php esc_html_e( 'Aspetto, poi Personalizza, poi "Dati attività".', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Cambia il dato (per esempio l\'orario del pomeriggio).', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Premi Pubblica in alto.', 'hamza-theme' ); ?></li>
				</ol>
				<?php if ( '' !== $biz_phone ) : ?>
					<p class="humza-guide__current">
						<?php
						printf(
							/* translators: 1: telefono attuale, 2: orari attuali. */
							esc_html__( 'Adesso il sito mostra: telefono %1$s, orari %2$s.', 'hamza-theme' ),
							esc_html( $biz_phone ),
							esc_html( $biz_hours )
						);
						?>
					</p>
				<?php endif; ?>
				<p>
					<a class="button button-primary" href="<?php echo esc_url( humza_admin_business_url() ); ?>">
						<?php esc_html_e( 'Apri "Dati attività"', 'hamza-theme' ); ?>
					</a>
				</p>
			</section>

			<section class="humza-guide__card">
				<h2><?php esc_html_e( '3. Aggiungere una domanda alle FAQ', 'hamza-theme' ); ?></h2>
				<p><?php esc_html_e( 'La pagina delle domande frequenti è una pagina normale. Ogni domanda è un titolo H3, la risposta è il paragrafo sotto: il sito le trasforma da solo in fisarmonica apri e chiudi.', 'hamza-theme' ); ?></p>
				<ol>
					<li><?php esc_html_e( 'Apri la pagina delle domande frequenti.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Vai in fondo alla categoria giusta e premi il tasto +.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Scegli il modello "Blocco: domanda e risposta" nella categoria Humza.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Scrivi la domanda al posto del titolo e la risposta al posto del testo.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Premi Aggiorna.', 'hamza-theme' ); ?></li>
				</ol>
				<?php if ( $faq_id && get_edit_post_link( $faq_id, 'raw' ) ) : ?>
					<p>
						<a class="button" href="<?php echo esc_url( get_edit_post_link( $faq_id, 'raw' ) ); ?>">
							<?php esc_html_e( 'Apri la pagina delle FAQ', 'hamza-theme' ); ?>
						</a>
					</p>
				<?php endif; ?>
			</section>

			<section class="humza-guide__card">
				<h2><?php esc_html_e( '4. Modificare il testo di una pagina', 'hamza-theme' ); ?></h2>
				<ol>
					<li><?php esc_html_e( 'Pagine, poi Tutte le pagine, poi clicca sul nome della pagina.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Clicca sul testo da cambiare e scrivi.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Premi Aggiorna in alto a destra.', 'hamza-theme' ); ?></li>
				</ol>
				<?php humza_admin_note( __( 'Non cancellare i titoli delle sezioni (le righe in grande): servono ai clienti e anche a Google.', 'hamza-theme' ), 'warn' ); ?>
				<?php humza_admin_note( __( 'Nella pagina Prenota c\'è un codice tra parentesi quadre: non toccarlo, è il modulo di prenotazione.', 'hamza-theme' ), 'warn' ); ?>
			</section>

			<section class="humza-guide__card">
				<h2><?php esc_html_e( '5. Il Riassunto e Google', 'hamza-theme' ); ?></h2>
				<p><?php esc_html_e( 'Il "Riassunto" è la frase breve che compare nelle anteprime del sito e nei risultati di Google. Se lo lasci vuoto, viene preso l\'inizio del testo: quasi sempre è meno chiaro.', 'hamza-theme' ); ?></p>
				<ol>
					<li><?php esc_html_e( 'Mentre scrivi una pagina o un articolo, apri il pannello a destra.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Cerca la voce "Riassunto" e scrivi una o due righe.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Nel riquadro SEO, più in basso, puoi scrivere un titolo e una descrizione ancora più precisi per Google.', 'hamza-theme' ); ?></li>
				</ol>
				<p><?php esc_html_e( 'Negli elenchi di Pagine e Articoli c\'è la colonna "Riassunto": ti dice a colpo d\'occhio dove manca.', 'hamza-theme' ); ?></p>
			</section>

			<section class="humza-guide__card">
				<h2><?php esc_html_e( '6. Le prenotazioni', 'hamza-theme' ); ?></h2>
				<p><?php esc_html_e( 'Nel menu a sinistra trovi la voce delle prenotazioni: lì vedi giorno, ora, nome e telefono di chi ha prenotato.', 'hamza-theme' ); ?></p>
				<p><?php esc_html_e( 'Ricevi anche un\'email per ogni prenotazione. Controlla che non finisca nello spam e, se succede, segna l\'indirizzo come "non spam".', 'hamza-theme' ); ?></p>
			</section>

			<section class="humza-guide__card">
				<h2><?php esc_html_e( '7. Le foto', 'hamza-theme' ); ?></h2>
				<p><?php esc_html_e( 'Per cambiare la foto principale di una pagina: apri la pagina, pannello a destra, voce "Immagine in evidenza".', 'hamza-theme' ); ?></p>
				<ul>
					<li><?php esc_html_e( 'Usa foto vere dell\'ufficio o del team: valgono più di mille parole.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Formato consigliato: orizzontale, almeno 1200 pixel di larghezza.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Il sito ridimensiona le foto da solo: non serve fare nulla.', 'hamza-theme' ); ?></li>
				</ul>
			</section>

			<section class="humza-guide__card">
				<h2><?php esc_html_e( '8. Cosa NON fare', 'hamza-theme' ); ?></h2>
				<ul>
					<li><?php esc_html_e( 'Non installare plugin senza motivo: rallentano il sito e possono creare problemi di sicurezza.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Non cambiare tema.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Non modificare i file del sito: la modifica dei file è disattivata apposta.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Non cancellare le pagine Privacy Policy e Cookie Policy: sono obbligatorie per legge.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Non pubblicare recensioni inventate: chiedi ai clienti soddisfatti una recensione su Google.', 'hamza-theme' ); ?></li>
				</ul>
			</section>

			<section class="humza-guide__card">
				<h2><?php esc_html_e( '9. Se qualcosa non funziona', 'hamza-theme' ); ?></h2>
				<ol>
					<li><?php esc_html_e( 'Ricarica la pagina (sul computer: Ctrl + F5).', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Prova da un altro telefono o computer.', 'hamza-theme' ); ?></li>
					<li><?php esc_html_e( 'Se il problema resta, dal pannello Hostinger puoi ripristinare un backup: Siti web, Gestisci, Backup.', 'hamza-theme' ); ?></li>
				</ol>
				<?php humza_admin_note( __( 'La Partita IVA deve restare visibile in fondo al sito: c\'è già, non toglierla.', 'hamza-theme' ), 'ok' ); ?>
			</section>

		</div>
	</div>
	<?php
}

/* -------------------------------------------------------------------------
 * 6. Pattern di blocchi pronti (categoria Humza)
 * ---------------------------------------------------------------------- */

/**
 * Categoria "Humza" nell'inseritore di blocchi.
 *
 * I modelli veri e propri stanno in /patterns (un file per modello):
 * WordPress li registra da solo leggendo l'intestazione di ogni file.
 * Priorità 9: la categoria esiste prima che i modelli la richiamino.
 */
add_action( 'init', function () {
	if ( ! function_exists( 'register_block_pattern_category' ) ) {
		return;
	}
	register_block_pattern_category(
		'humza',
		array(
			'label'       => __( 'Humza — modelli pronti', 'hamza-theme' ),
			'description' => __( 'Strutture già pronte per novità, elenchi di documenti, domande frequenti e avvisi.', 'hamza-theme' ),
		)
	);
}, 9 );

/**
 * Niente pattern scaricati da wordpress.org: sono in inglese, non c'entrano
 * con questo sito e aggiungono una richiesta di rete a ogni apertura
 * dell'editor. Restano i pattern di WordPress e quelli "Humza".
 */
add_filter( 'should_load_remote_block_patterns', '__return_false' );

/* -------------------------------------------------------------------------
 * 7. Semplificazioni dell'editor e delle liste
 * ---------------------------------------------------------------------- */

/**
 * Riquadro nella colonna laterale dell'editor che spiega il Riassunto
 * e ne mostra lo stato. Non duplica il campo (per non creare due punti
 * di salvataggio dello stesso dato): indica dove trovarlo.
 */
add_action( 'add_meta_boxes', function () {
	add_meta_box(
		'humza-excerpt-hint',
		__( 'Riassunto: a cosa serve', 'hamza-theme' ),
		'humza_admin_excerpt_hint_render',
		array( 'post', 'page' ),
		'side',
		'default'
	);
} );

/**
 * Contenuto del riquadro di aiuto sul Riassunto.
 *
 * @param WP_Post $post Contenuto in modifica.
 */
function humza_admin_excerpt_hint_render( $post ) {
	$has_excerpt = ( $post instanceof WP_Post ) && '' !== trim( (string) $post->post_excerpt );
	?>
	<div class="humza-hint">
		<p><?php esc_html_e( 'Il "Riassunto" è la frase breve che compare nelle anteprime del sito e nei risultati di Google. Una o due righe bastano.', 'hamza-theme' ); ?></p>
		<p>
			<?php if ( $has_excerpt ) : ?>
				<span class="humza-flag humza-flag--ok">
					<span class="dashicons dashicons-yes" aria-hidden="true"></span>
					<?php esc_html_e( 'Riassunto scritto', 'hamza-theme' ); ?>
				</span>
			<?php else : ?>
				<span class="humza-flag humza-flag--missing">
					<span class="dashicons dashicons-warning" aria-hidden="true"></span>
					<?php esc_html_e( 'Riassunto mancante', 'hamza-theme' ); ?>
				</span>
			<?php endif; ?>
		</p>
		<p class="humza-hint__where"><?php esc_html_e( 'Dove si scrive: in questa colonna, riquadro "Riassunto". Se non lo vedi, apri la scheda "Articolo" o "Pagina" qui sopra.', 'hamza-theme' ); ?></p>
	</div>
	<?php
}

/**
 * Schede di aiuto (menu "Aiuto" in alto) sugli elenchi di articoli e pagine.
 *
 * @param WP_Screen $screen Schermata corrente.
 */
add_action( 'current_screen', function ( $screen ) {
	if ( ! $screen instanceof WP_Screen ) {
		return;
	}
	if ( ! in_array( $screen->base, array( 'edit', 'post' ), true ) ) {
		return;
	}
	if ( ! in_array( $screen->post_type, array( 'post', 'page' ), true ) ) {
		return;
	}

	$basics = '<p>' . esc_html__( 'Scrivi frasi corte. Un\'idea per paragrafo. Per gli elenchi usa il tasto + e scegli "Elenco".', 'hamza-theme' ) . '</p>'
		. '<p>' . esc_html__( 'Con il tasto + puoi anche aprire "Modelli" e scegliere la categoria Humza: trovi novità, elenchi di documenti e domande frequenti già pronti.', 'hamza-theme' ) . '</p>'
		. '<p>' . esc_html__( 'Ricordati di premere Pubblica (o Aggiorna) in alto a destra: senza quello le modifiche non si vedono online.', 'hamza-theme' ) . '</p>';

	$seo = '<p>' . esc_html__( 'Riassunto: la frase breve che compare nelle anteprime e su Google. Se è vuoto viene preso l\'inizio del testo.', 'hamza-theme' ) . '</p>'
		. '<p>' . esc_html__( 'Riquadro SEO: "Titolo SEO" è il titolo che compare su Google (massimo 60 caratteri), "Meta description" è la descrizione sotto il titolo (massimo 155 caratteri). Se li lasci vuoti il sito li crea da solo.', 'hamza-theme' ) . '</p>';

	$screen->add_help_tab(
		array(
			'id'      => 'humza-help-basics',
			'title'   => __( 'Come si scrive', 'hamza-theme' ),
			'content' => $basics,
		)
	);
	$screen->add_help_tab(
		array(
			'id'      => 'humza-help-seo',
			'title'   => __( 'Riassunto e Google', 'hamza-theme' ),
			'content' => $seo,
		)
	);
	$screen->set_help_sidebar(
		'<p><strong>' . esc_html__( 'Serve altro?', 'hamza-theme' ) . '</strong></p>'
		. '<p><a href="' . esc_url( humza_admin_guide_url() ) . '">' . esc_html__( 'Apri la Guida al sito', 'hamza-theme' ) . '</a></p>'
	);
} );

/**
 * Colonna "Riassunto" negli elenchi di articoli e pagine: si vede subito
 * dove manca la frase che Google mostra nei risultati.
 *
 * @param array<string,string> $columns   Colonne registrate.
 * @param string               $post_type Tipo di contenuto (solo per gli articoli).
 * @return array<string,string>
 */
function humza_admin_excerpt_column( $columns, $post_type = 'page' ) {
	if ( ! in_array( $post_type, array( 'post', 'page' ), true ) ) {
		return $columns;
	}

	$new = array();
	foreach ( $columns as $key => $label ) {
		if ( 'date' === $key ) {
			$new['humza_excerpt'] = __( 'Riassunto', 'hamza-theme' );
		}
		$new[ $key ] = $label;
	}
	if ( ! isset( $new['humza_excerpt'] ) ) {
		$new['humza_excerpt'] = __( 'Riassunto', 'hamza-theme' );
	}
	return $new;
}
add_filter( 'manage_posts_columns', 'humza_admin_excerpt_column', 10, 2 );
add_filter( 'manage_pages_columns', 'humza_admin_excerpt_column' );

/**
 * Contenuto della colonna "Riassunto".
 *
 * @param string $column  Chiave della colonna.
 * @param int    $post_id ID del contenuto.
 */
function humza_admin_excerpt_column_render( $column, $post_id ) {
	if ( 'humza_excerpt' !== $column ) {
		return;
	}
	$post = get_post( $post_id );
	$has  = ( $post instanceof WP_Post ) && '' !== trim( (string) $post->post_excerpt );

	if ( $has ) {
		printf(
			'<span class="humza-flag humza-flag--ok"><span class="dashicons dashicons-yes" aria-hidden="true"></span>%s</span>',
			esc_html__( 'Sì', 'hamza-theme' )
		);
		return;
	}
	printf(
		'<span class="humza-flag humza-flag--missing"><span class="dashicons dashicons-warning" aria-hidden="true"></span>%s</span>',
		esc_html__( 'Manca', 'hamza-theme' )
	);
}
add_action( 'manage_posts_custom_column', 'humza_admin_excerpt_column_render', 10, 2 );
add_action( 'manage_pages_custom_column', 'humza_admin_excerpt_column_render', 10, 2 );

/**
 * Editor dei file di tema e plugin sempre disattivato: un errore di battitura
 * lì dentro manda offline il sito e nessuno può più entrare nel pannello.
 *
 * Questo filtro lo blocca lato tema. La protezione più solida resta quella
 * a livello di server: aggiungere in wp-config.php la riga
 *   define( 'DISALLOW_FILE_EDIT', true );
 *
 * @param array<int,string> $caps Capacità richieste.
 * @param string            $cap  Capacità in verifica.
 * @return array<int,string>
 */
add_filter( 'map_meta_cap', function ( $caps, $cap ) {
	if ( in_array( $cap, array( 'edit_files', 'edit_plugins', 'edit_themes' ), true ) ) {
		return array( 'do_not_allow' );
	}
	return $caps;
}, 10, 2 );

/* -------------------------------------------------------------------------
 * Icona del servizio: campo selezionabile in wp-admin.
 *
 * Le card dei servizi (home, /servizi/, footer) leggono la meta 'humza_icon'.
 * Senza questo campo la meta era impostabile solo da riga di comando e ogni
 * card ricadeva sull'icona generica.
 * ---------------------------------------------------------------------- */

/**
 * Icone disponibili per le pagine servizio: id nello sprite => etichetta.
 *
 * @return array<string,string>
 */
function humza_service_icons() {
	return array(
		'ic-prefettura'   => __( 'Prefettura (permesso di soggiorno)', 'hamza-theme' ),
		'ic-inps'         => __( 'INPS (tutele e prestazioni)', 'hamza-theme' ),
		'ic-consolato-pk' => __( 'Consolato pakistano (passaporto)', 'hamza-theme' ),
		'ic-consolato-in' => __( 'Consolato indiano (OCI card)', 'hamza-theme' ),
		'ic-visti'        => __( 'Visti (aereo)', 'hamza-theme' ),
		'ic-caf'          => __( 'CAF e fisco (calcolatrice)', 'hamza-theme' ),
		'ic-tribunale'    => __( 'Tribunale (bilancia)', 'hamza-theme' ),
		'ic-traduzioni'   => __( 'Traduzioni (dialogo)', 'hamza-theme' ),
		'ic-altri'        => __( 'Altri servizi (fascicolo)', 'hamza-theme' ),
	);
}

// La meta è registrata anche per REST/editor a blocchi.
add_action( 'init', function () {
	register_post_meta( 'page', 'humza_icon', array(
		'type'              => 'string',
		'single'            => true,
		'show_in_rest'      => true,
		'sanitize_callback' => 'humza_sanitize_service_icon',
		'auth_callback'     => function () {
			return current_user_can( 'edit_pages' );
		},
	) );
} );

/**
 * Accetta solo id presenti nello sprite; qualsiasi altro valore diventa vuoto.
 *
 * @param string $value Valore inviato.
 * @return string
 */
function humza_sanitize_service_icon( $value ) {
	$value = sanitize_key( (string) $value );
	return array_key_exists( $value, humza_service_icons() ) ? $value : '';
}

add_action( 'add_meta_boxes', function () {
	add_meta_box(
		'humza-service-icon',
		__( 'Icona del servizio', 'hamza-theme' ),
		'humza_service_icon_metabox',
		'page',
		'side',
		'default'
	);
} );

/**
 * Campo di scelta dell'icona.
 *
 * @param WP_Post $post Pagina in modifica.
 */
function humza_service_icon_metabox( $post ) {
	$current = (string) get_post_meta( $post->ID, 'humza_icon', true );
	wp_nonce_field( 'humza_service_icon_save', 'humza_service_icon_nonce' );
	?>
	<p class="description" style="margin-top:0">
		<?php esc_html_e( 'Compare nel riquadro del servizio in home e nella pagina Servizi.', 'hamza-theme' ); ?>
	</p>
	<label class="screen-reader-text" for="humza_icon"><?php esc_html_e( 'Icona del servizio', 'hamza-theme' ); ?></label>
	<select name="humza_icon" id="humza_icon" class="widefat">
		<option value=""><?php esc_html_e( '— Nessuna (icona generica) —', 'hamza-theme' ); ?></option>
		<?php foreach ( humza_service_icons() as $id => $label ) : ?>
			<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $current, $id ); ?>>
				<?php echo esc_html( $label ); ?>
			</option>
		<?php endforeach; ?>
	</select>
	<?php
}

add_action( 'save_post_page', function ( $post_id ) {
	if ( ! isset( $_POST['humza_service_icon_nonce'] )
		|| ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['humza_service_icon_nonce'] ) ), 'humza_service_icon_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_page', $post_id ) ) {
		return;
	}
	$icon = isset( $_POST['humza_icon'] ) ? humza_sanitize_service_icon( wp_unslash( $_POST['humza_icon'] ) ) : '';
	if ( '' === $icon ) {
		delete_post_meta( $post_id, 'humza_icon' );
	} else {
		update_post_meta( $post_id, 'humza_icon', $icon );
	}
} );

