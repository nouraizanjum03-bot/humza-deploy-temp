<?php
/**
 * Title: Blocco: documenti necessari
 * Slug: hamza-theme/blocco-documenti
 * Description: Titolo con l'elenco dei documenti che il cliente deve portare in ufficio.
 * Categories: humza
 * Keywords: documenti, elenco, servizio, pratica
 * Viewport Width: 800
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php esc_html_e( 'Documenti necessari', 'hamza-theme' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item -->
<li><?php esc_html_e( 'Documento d\'identità in corso di validità', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'Codice fiscale o tessera sanitaria', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'Permesso di soggiorno, se richiesto per la pratica', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'Marca da bollo, se prevista', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->
