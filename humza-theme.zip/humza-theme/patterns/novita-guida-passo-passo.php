<?php
/**
 * Title: Novità: guida passo passo
 * Slug: hamza-theme/novita-guida-passo-passo
 * Description: Articolo completo: introduzione, passaggi numerati, documenti necessari e invito a prenotare.
 * Categories: humza
 * Keywords: novità, guida, passi, documenti, 730, prenota
 * Viewport Width: 800
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:paragraph -->
<p><?php esc_html_e( 'Da quest\'anno la dichiarazione dei redditi 730 si può presentare da aprile. Ecco come funziona da noi, passo per passo.', 'hamza-theme' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e( 'Come si fa, passo per passo', 'hamza-theme' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true} -->
<ol class="wp-block-list">
<!-- wp:list-item -->
<li><?php esc_html_e( 'Prenoti un appuntamento: online, per telefono o su WhatsApp.', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'Vieni in ufficio con i documenti dell\'elenco qui sotto.', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'Controlliamo insieme i dati e prepariamo la pratica.', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'Firmi e ricevi la tua copia. Ti avvisiamo quando è tutto trasmesso.', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->
</ol>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e( 'Documenti da portare', 'hamza-theme' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item -->
<li><?php esc_html_e( 'Documento d\'identità e tessera sanitaria', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'Certificazione Unica (CU) del datore di lavoro', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'Spese mediche, affitto o mutuo, spese scolastiche', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'La dichiarazione dell\'anno scorso, se ce l\'hai', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'Parliamo italiano, inglese, urdu, punjabi, hindi e arabo: ti spieghiamo tutto con parole semplici.', 'hamza-theme' ); ?> <a href="<?php echo esc_url( home_url( '/prenota/' ) ); ?>"><?php esc_html_e( 'Prenota un appuntamento', 'hamza-theme' ); ?></a>.</p>
<!-- /wp:paragraph -->
