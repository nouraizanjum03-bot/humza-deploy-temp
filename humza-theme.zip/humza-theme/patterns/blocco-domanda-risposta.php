<?php
/**
 * Title: Blocco: domanda e risposta
 * Slug: hamza-theme/blocco-domanda-risposta
 * Description: Una domanda (titolo) con la sua risposta. Nella pagina FAQ diventa da sola una voce apri e chiudi.
 * Categories: humza
 * Keywords: faq, domanda, risposta, domande frequenti
 * Viewport Width: 800
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php esc_html_e( 'Quanto tempo ci vuole per il rinnovo del permesso di soggiorno?', 'hamza-theme' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'Prepariamo e inviamo la pratica in giornata. I tempi della Questura variano da alcune settimane ad alcuni mesi: appena arriva una comunicazione ti avvisiamo.', 'hamza-theme' ); ?></p>
<!-- /wp:paragraph -->
