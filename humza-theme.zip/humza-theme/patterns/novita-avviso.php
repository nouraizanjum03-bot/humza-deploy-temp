<?php
/**
 * Title: Novità: avviso breve
 * Slug: hamza-theme/novita-avviso
 * Description: Comunicazione corta con un riquadro di date: chiusure, cambi di orario, scadenze.
 * Categories: humza
 * Keywords: novità, avviso, chiusura, scadenza, ferie
 * Viewport Width: 800
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:paragraph -->
<p><strong><?php esc_html_e( 'In breve:', 'hamza-theme' ); ?></strong> <?php esc_html_e( 'l\'ufficio resta chiuso per ferie da lunedì 10 a sabato 22 agosto. Riapriamo lunedì 24 agosto con i soliti orari.', 'hamza-theme' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'Le pratiche già consegnate proseguono regolarmente. Per un\'urgenza scrivici su WhatsApp: rispondiamo appena possibile.', 'hamza-theme' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"aside-box","layout":{"type":"constrained"}} -->
<div class="wp-block-group aside-box">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php esc_html_e( 'Date da ricordare', 'hamza-theme' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item -->
<li><strong><?php esc_html_e( 'Chiusura:', 'hamza-theme' ); ?></strong> <?php esc_html_e( 'da lunedì 10 agosto', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong><?php esc_html_e( 'Riapertura:', 'hamza-theme' ); ?></strong> <?php esc_html_e( 'lunedì 24 agosto, ore 09:00', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong><?php esc_html_e( 'Scadenza da non perdere:', 'hamza-theme' ); ?></strong> <?php esc_html_e( '30 settembre', 'hamza-theme' ); ?></li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
