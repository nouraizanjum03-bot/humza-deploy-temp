<?php
/**
 * Title: Blocco: avviso importante
 * Slug: hamza-theme/blocco-avviso-importante
 * Description: Riquadro evidenziato per una cosa che il cliente non deve dimenticare.
 * Categories: humza
 * Keywords: avviso, attenzione, importante, nota
 * Viewport Width: 800
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:quote -->
<blockquote class="wp-block-quote">
<!-- wp:paragraph -->
<p><strong><?php esc_html_e( 'Attenzione:', 'hamza-theme' ); ?></strong> <?php esc_html_e( 'per questa pratica serve l\'appuntamento. Senza prenotazione non possiamo garantire il servizio in giornata.', 'hamza-theme' ); ?></p>
<!-- /wp:paragraph -->
<cite><?php esc_html_e( 'Humza Multiservizi', 'hamza-theme' ); ?></cite></blockquote>
<!-- /wp:quote -->
