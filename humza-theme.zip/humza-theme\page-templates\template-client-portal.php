<?php
/**
 * Template Name: Area Clienti
 *
 * Ospiti: tre schede accessibili Accedi / Registrati / Password, a tutta
 * larghezza su smartphone. Le form mantengono id, nomi campo e nonce del
 * portale esistente (hamza-login-form / hamza-register-form): l'invio AJAX
 * è gestito da main.js, con fallback senza JavaScript verso wp-login.php e
 * admin-ajax.php.
 * Loggati: benvenuto, stato onesto (le pratiche non sono online) e azioni
 * chiare (WhatsApp, prenota, esci).
 *
 * Il contenuto della pagina viene stampato in fondo: è lì che il cliente
 * incolla lo shortcode "i miei appuntamenti" del plugin hamza-booking.
 * Se la pagina è vuota, il blocco non viene creato affatto.
 *
 * @package hamza-theme
 */

defined( 'ABSPATH' ) || exit;

get_header();

$humza_portal_url = get_permalink();
$humza_phone      = humza_biz( 'phone1' );
$humza_phone_url  = humza_phone_href( $humza_phone );

// Parametri di stato in sola lettura (nessuna azione eseguita: nonce non richiesto).
// phpcs:disable WordPress.Security.NonceVerification.Recommended
$humza_reset_sent   = isset( $_GET['reset'] ) && 'sent' === sanitize_key( wp_unslash( $_GET['reset'] ) );
$humza_login_failed = isset( $_GET['login'] ) && 'failed' === sanitize_key( wp_unslash( $_GET['login'] ) );
// phpcs:enable WordPress.Security.NonceVerification.Recommended
?>

<main id="main">

	<?php while ( have_posts() ) : the_post(); ?>

		<?php
		/*
		 * Contenuto pagina (shortcode del plugin): raccolto in un buffer per
		 * non stampare un blocco vuoto quando la pagina non ha contenuto.
		 */
		ob_start();
		the_content();
		$humza_portal_content = trim( (string) ob_get_clean() );
		?>

		<section class="page-hero">
			<div class="container">
				<?php if ( function_exists( 'humza_breadcrumb' ) ) : ?>
					<?php humza_breadcrumb(); ?>
				<?php else : ?>
					<nav class="breadcrumb" aria-label="<?php esc_attr_e( 'Percorso di navigazione', 'hamza-theme' ); ?>">
						<ol>
							<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'hamza-theme' ); ?></a></li>
							<li aria-current="page"><?php the_title(); ?></li>
						</ol>
					</nav>
				<?php endif; ?>
				<h1><?php the_title(); ?></h1>
				<p class="page-hero__sub"><?php esc_html_e( 'Qui trovi i tuoi appuntamenti. Per lo stato di una pratica scrivici su WhatsApp: rispondiamo noi.', 'hamza-theme' ); ?></p>
			</div>
		</section>

		<section class="section">
			<div class="container">

				<?php if ( is_user_logged_in() ) : ?>

					<?php
					$humza_user    = wp_get_current_user();
					$humza_wa_user = humza_wa_href(
						sprintf(
							/* translators: %s: nome dell'utente. */
							__( 'Ciao, sono %s: vorrei sapere lo stato della mia pratica.', 'hamza-theme' ),
							$humza_user->display_name
						)
					);
					?>

					<div class="auth-wrap">
						<h2>
							<?php
							/* translators: %s: nome dell'utente. */
							printf( esc_html__( 'Ciao, %s', 'hamza-theme' ), esc_html( $humza_user->display_name ) );
							?>
						</h2>
						<p><?php esc_html_e( 'Questo è il tuo profilo su humzamultiservizi.it. Da qui vedi gli appuntamenti che hai prenotato e puoi fissarne di nuovi.', 'hamza-theme' ); ?></p>

						<div class="auth-help">
							<h3><?php esc_html_e( 'Vuoi sapere a che punto è la tua pratica?', 'hamza-theme' ); ?></h3>
							<p><?php esc_html_e( 'Le pratiche non sono online: le seguiamo noi in ufficio. Scrivici su WhatsApp con il tuo nome e ti diciamo subito a che punto siamo.', 'hamza-theme' ); ?></p>
							<div class="auth-actions">
								<a class="btn btn--wa btn--block-mobile" href="<?php echo esc_url( $humza_wa_user ); ?>" target="_blank" rel="noopener noreferrer">
									<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>
									<?php esc_html_e( 'Scrivici su WhatsApp', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
								</a>
								<?php if ( '' !== $humza_phone_url ) : ?>
								<a class="btn btn--ghost btn--block-mobile" href="<?php echo esc_url( $humza_phone_url ); ?>">
									<?php echo humza_icon( 'ic-tel', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>
									<?php echo esc_html( $humza_phone ); ?>
								</a>
								<?php endif; ?>
							</div>
						</div>

						<?php if ( '' !== $humza_portal_content ) : ?>
							<div class="auth-block">
								<h2><?php esc_html_e( 'I tuoi appuntamenti', 'hamza-theme' ); ?></h2>
								<?php echo $humza_portal_content; // phpcs:ignore WordPress.Security.EscapeOutput -- contenuto pagina già filtrato da the_content. ?>
							</div>
						<?php endif; ?>

						<div class="auth-block">
							<h2><?php esc_html_e( 'Altre azioni', 'hamza-theme' ); ?></h2>
							<div class="auth-actions">
								<a class="btn btn--primary btn--block-mobile" href="<?php echo esc_url( home_url( '/prenota/' ) ); ?>"><?php esc_html_e( 'Prenota un appuntamento', 'hamza-theme' ); ?></a>
								<a class="btn btn--ghost btn--block-mobile" href="<?php echo esc_url( wp_logout_url( $humza_portal_url ) ); ?>"><?php esc_html_e( 'Esci dal profilo', 'hamza-theme' ); ?></a>
							</div>
						</div>
					</div>

				<?php else : ?>

					<div class="auth-wrap">

						<?php if ( $humza_reset_sent ) : ?>
							<div class="form-msg form-msg--ok" role="status"><?php esc_html_e( 'Ti abbiamo inviato un’email con le istruzioni per reimpostare la password. Controlla anche la posta indesiderata.', 'hamza-theme' ); ?></div>
						<?php endif; ?>
						<?php if ( $humza_login_failed ) : ?>
							<div class="form-msg form-msg--err" role="alert"><?php esc_html_e( 'Accesso non riuscito: controlla email e password e riprova.', 'hamza-theme' ); ?></div>
						<?php endif; ?>

						<div class="auth-intro">
							<h2><?php esc_html_e( 'A cosa serve il profilo', 'hamza-theme' ); ?></h2>
							<ul class="checklist">
								<li><?php echo humza_icon( 'ic-vidimato', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?><span><?php esc_html_e( 'Ritrovi gli appuntamenti che hai prenotato, senza cercare l’email di conferma.', 'hamza-theme' ); ?></span></li>
								<li><?php echo humza_icon( 'ic-vidimato', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?><span><?php esc_html_e( 'Prenoti più in fretta: i tuoi dati sono già salvati.', 'hamza-theme' ); ?></span></li>
								<li><?php echo humza_icon( 'ic-vidimato', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?><span><?php esc_html_e( 'Lo stato delle pratiche non è online: quello te lo diciamo noi su WhatsApp o in ufficio.', 'hamza-theme' ); ?></span></li>
							</ul>
						</div>

						<noscript>
							<p class="auth-note">
								<?php esc_html_e( 'Con JavaScript disattivato puoi comunque:', 'hamza-theme' ); ?>
								<a href="<?php echo esc_url( wp_registration_url() ); ?>"><?php esc_html_e( 'registrarti', 'hamza-theme' ); ?></a> &middot;
								<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'recuperare la password', 'hamza-theme' ); ?></a>
							</p>
						</noscript>

						<div class="tabs tabs--auth" role="tablist" aria-label="<?php esc_attr_e( 'Accesso e registrazione', 'hamza-theme' ); ?>">
							<button class="tab" type="button" role="tab" id="tab-login" aria-selected="true" aria-controls="panel-login"><?php esc_html_e( 'Accedi', 'hamza-theme' ); ?></button>
							<button class="tab" type="button" role="tab" id="tab-register" aria-selected="false" aria-controls="panel-register" tabindex="-1"><?php esc_html_e( 'Registrati', 'hamza-theme' ); ?></button>
							<button class="tab" type="button" role="tab" id="tab-lost" aria-selected="false" aria-controls="panel-lost" tabindex="-1"><?php esc_html_e( 'Password', 'hamza-theme' ); ?></button>
						</div>

						<!-- Accedi -->
						<div class="tabpanel" id="panel-login" role="tabpanel" aria-labelledby="tab-login" tabindex="0">
							<p><?php esc_html_e( 'Inserisci le tue credenziali per accedere al profilo.', 'hamza-theme' ); ?></p>
							<div id="login-error-msg" class="form-msg form-msg--err" role="alert" hidden><?php esc_html_e( 'Nome utente o password non corretti. Riprova.', 'hamza-theme' ); ?></div>
							<form id="hamza-login-form" class="form-grid" method="post" action="<?php echo esc_url( wp_login_url() ); ?>">
								<?php // L'azione del nonce deve restare 'hamza_ajax_login': la verifica lato server è in mu-plugins/humza-forms.php. ?>
								<?php wp_nonce_field( 'hamza_ajax_login', 'hamza_login_nonce' ); ?>
								<input type="hidden" name="action" value="hamza_ajax_login">
								<input type="hidden" name="redirect_to" value="<?php echo esc_url( $humza_portal_url ); ?>">
								<div class="field">
									<label for="hamza-login-user"><?php esc_html_e( 'Email o nome utente', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
									<input type="text" id="hamza-login-user" name="log" required autocomplete="username" autocapitalize="none" spellcheck="false">
								</div>
								<div class="field">
									<label for="hamza-login-pass"><?php esc_html_e( 'Password', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
									<input type="password" id="hamza-login-pass" name="pwd" required autocomplete="current-password">
								</div>
								<label class="consent" for="hamza-login-remember">
									<input type="checkbox" id="hamza-login-remember" name="rememberme" value="forever">
									<span><?php esc_html_e( 'Ricordami su questo dispositivo', 'hamza-theme' ); ?></span>
								</label>
								<button type="submit" class="btn btn--primary btn--block"><?php esc_html_e( 'Accedi', 'hamza-theme' ); ?></button>
							</form>
						</div>

						<!-- Registrati -->
						<div class="tabpanel" id="panel-register" role="tabpanel" aria-labelledby="tab-register" tabindex="0" hidden>
							<p><?php esc_html_e( 'Crea un profilo con i tuoi contatti: bastano nome, email e telefono.', 'hamza-theme' ); ?></p>
							<form id="hamza-register-form" class="form-grid" method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>">
								<?php wp_nonce_field( 'hamza_register', 'hamza_register_nonce' ); ?>
								<input type="hidden" name="action" value="hamza_register">
								<div class="field">
									<label for="reg-name"><?php esc_html_e( 'Nome e cognome', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
									<input type="text" id="reg-name" name="hamza_reg_name" required autocomplete="name">
								</div>
								<div class="field">
									<label for="reg-email"><?php esc_html_e( 'Email', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
									<input type="email" id="reg-email" name="hamza_reg_email" required autocomplete="email">
								</div>
								<div class="field">
									<label for="reg-phone"><?php esc_html_e( 'Telefono', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
									<input type="tel" id="reg-phone" name="hamza_reg_phone" required autocomplete="tel">
								</div>
								<div class="field">
									<label for="reg-cf"><?php esc_html_e( 'Codice fiscale (facoltativo)', 'hamza-theme' ); ?></label>
									<input type="text" id="reg-cf" name="hamza_reg_cf" class="input-upper" maxlength="16" autocomplete="off" autocapitalize="characters" spellcheck="false">
								</div>
								<div class="field">
									<label for="reg-password"><?php esc_html_e( 'Password', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
									<input type="password" id="reg-password" name="hamza_reg_password" required minlength="8" autocomplete="new-password" aria-describedby="reg-password-hint">
									<p class="field-hint" id="reg-password-hint"><?php esc_html_e( 'Almeno 8 caratteri. Meglio se con numeri e simboli.', 'hamza-theme' ); ?></p>
								</div>
								<div class="field">
									<label for="reg-password-confirm"><?php esc_html_e( 'Conferma password', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
									<input type="password" id="reg-password-confirm" name="hamza_reg_password_confirm" required minlength="8" autocomplete="new-password">
								</div>
								<div class="consent">
									<input type="checkbox" id="reg-privacy" name="hamza_reg_privacy" required>
									<span>
										<label for="reg-privacy"><?php esc_html_e( 'Ho letto e accetto la Privacy Policy.', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
										<a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Leggi la Privacy Policy', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span></a>
									</span>
								</div>
								<div class="hp-field" aria-hidden="true">
									<label for="reg-website">Website</label>
									<input type="text" id="reg-website" name="hamza_website" tabindex="-1" autocomplete="off">
								</div>
								<button type="submit" class="btn btn--primary btn--block"><?php esc_html_e( 'Crea il profilo', 'hamza-theme' ); ?></button>
								<div id="register-form-message" class="form-msg" role="alert" aria-live="polite" hidden></div>
							</form>
						</div>

						<!-- Password dimenticata -->
						<div class="tabpanel" id="panel-lost" role="tabpanel" aria-labelledby="tab-lost" tabindex="0" hidden>
							<p><?php esc_html_e( 'Hai dimenticato la password? Scrivi la tua email: ti mandiamo un link per sceglierne una nuova.', 'hamza-theme' ); ?></p>
							<form class="form-grid" method="post" action="<?php echo esc_url( wp_lostpassword_url() ); ?>">
								<input type="hidden" name="redirect_to" value="<?php echo esc_url( add_query_arg( 'reset', 'sent', $humza_portal_url ) ); ?>">
								<div class="field">
									<label for="lost-email"><?php esc_html_e( 'Email', 'hamza-theme' ); ?> <span class="req" aria-hidden="true">*</span></label>
									<input type="email" id="lost-email" name="user_login" required autocomplete="email">
								</div>
								<button type="submit" class="btn btn--primary btn--block"><?php esc_html_e( 'Invia il link di recupero', 'hamza-theme' ); ?></button>
							</form>
						</div>

						<div class="auth-help">
							<h2><?php esc_html_e( 'Non ricordi come accedere?', 'hamza-theme' ); ?></h2>
							<p><?php esc_html_e( 'Non perdere tempo: scrivici su WhatsApp con il tuo nome e ti aiutiamo noi, anche nella tua lingua.', 'hamza-theme' ); ?></p>
							<div class="auth-actions">
								<a class="btn btn--wa btn--block-mobile" href="<?php echo esc_url( humza_wa_href( __( 'Ciao! Ho un problema con l’accesso all’area clienti.', 'hamza-theme' ) ) ); ?>" target="_blank" rel="noopener noreferrer">
									<?php echo humza_icon( 'ic-wa', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>
									<?php esc_html_e( 'Scrivici su WhatsApp', 'hamza-theme' ); ?><span class="screen-reader-text"> (<?php esc_html_e( 'si apre in una nuova scheda', 'hamza-theme' ); ?>)</span>
								</a>
								<?php if ( '' !== $humza_phone_url ) : ?>
								<a class="btn btn--ghost btn--block-mobile" href="<?php echo esc_url( $humza_phone_url ); ?>">
									<?php echo humza_icon( 'ic-tel', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG generato dal tema. ?>
									<?php echo esc_html( $humza_phone ); ?>
								</a>
								<?php endif; ?>
							</div>
						</div>

						<?php if ( '' !== $humza_portal_content ) : ?>
							<div class="auth-block">
								<h2><?php esc_html_e( 'Cerca un appuntamento con la tua email', 'hamza-theme' ); ?></h2>
								<?php echo $humza_portal_content; // phpcs:ignore WordPress.Security.EscapeOutput -- contenuto pagina già filtrato da the_content. ?>
							</div>
						<?php endif; ?>

						<p class="auth-note">
							<?php esc_html_e( 'Per prenotare un appuntamento non serve un profilo:', 'hamza-theme' ); ?>
							<a href="<?php echo esc_url( home_url( '/prenota/' ) ); ?>"><?php esc_html_e( 'vai alla pagina Prenota', 'hamza-theme' ); ?></a>.
						</p>

					</div>

				<?php endif; ?>

			</div>
		</section>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>
