<?php
/**
 * Plugin Name: Humza Multiservizi — Modulo contatti
 * Description: Gestore del modulo contatti, indipendente dal tema. Prima viveva dentro il tema: al cambio tema il modulo smetteva di funzionare. Accesso, registrazione e pratiche restano al plugin hamza-client-portal.
 * Version: 1.0.0
 * Author: Humza Multiservizi
 *
 * @package humza-forms
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * Utilità
 * ---------------------------------------------------------------------- */

/**
 * Limite di invii per indirizzo IP: il modulo è pubblico e senza CAPTCHA.
 *
 * @param string $key  Nome del contatore.
 * @param int    $max  Invii consentiti nella finestra.
 * @param int    $secs Ampiezza della finestra, in secondi.
 * @return bool True se la richiesta è entro il limite.
 */
function humza_forms_rate_ok( $key, $max = 5, $secs = 900 ) {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'sconosciuto';
	$id = 'humza_rl_' . $key . '_' . md5( $ip );
	$n  = (int) get_transient( $id );
	if ( $n >= $max ) {
		return false;
	}
	set_transient( $id, $n + 1, $secs );
	return true;
}

/**
 * Destinatario dei messaggi: l'email configurata nel tema, con ripiego
 * sull'indirizzo amministratore.
 *
 * @return string
 */
function humza_forms_destination() {
	$email = function_exists( 'humza_biz' ) ? humza_biz( 'email' ) : '';
	if ( ! is_email( $email ) ) {
		$email = get_option( 'admin_email' );
	}
	return $email;
}

/* -------------------------------------------------------------------------
 * Modulo contatti
 * ---------------------------------------------------------------------- */

add_action( 'wp_ajax_hamza_contact_form', 'humza_handle_contact_form' );
add_action( 'wp_ajax_nopriv_hamza_contact_form', 'humza_handle_contact_form' );

/**
 * Riceve il modulo contatti e inoltra il messaggio all'ufficio.
 */
function humza_handle_contact_form() {
	check_ajax_referer( 'hamza_contact_form', 'hamza_contact_nonce' );

	// Campo trappola: lo compilano solo i bot.
	if ( ! empty( $_POST['hamza_website'] ) ) {
		wp_send_json_error( array( 'message' => __( 'Richiesta non valida.', 'hamza-theme' ) ) );
	}

	if ( ! humza_forms_rate_ok( 'contact', 5, 900 ) ) {
		wp_send_json_error( array( 'message' => __( 'Hai già inviato più messaggi. Riprova tra un quarto d’ora oppure scrivici su WhatsApp.', 'hamza-theme' ) ) );
	}

	$name    = sanitize_text_field( wp_unslash( $_POST['hamza_name'] ?? '' ) );
	$email   = sanitize_email( wp_unslash( $_POST['hamza_email'] ?? '' ) );
	$prefix  = sanitize_text_field( wp_unslash( $_POST['hamza_phone_prefix'] ?? '' ) );
	$phone   = sanitize_text_field( wp_unslash( $_POST['hamza_phone'] ?? '' ) );
	$service = sanitize_text_field( wp_unslash( $_POST['hamza_service'] ?? '' ) );
	$message = sanitize_textarea_field( wp_unslash( $_POST['hamza_message'] ?? '' ) );

	if ( '' === $name || ! is_email( $email ) || '' === $message ) {
		wp_send_json_error( array( 'message' => __( 'Compila nome, email e messaggio.', 'hamza-theme' ) ) );
	}

	$name    = mb_substr( $name, 0, 120 );
	$message = mb_substr( $message, 0, 5000 );

	$attachments = humza_forms_collect_attachments();
	if ( is_wp_error( $attachments ) ) {
		wp_send_json_error( array( 'message' => $attachments->get_error_message() ) );
	}

	$body = sprintf(
		"Nome: %s\nEmail: %s\nTelefono: %s %s\nServizio: %s\n\nMessaggio:\n%s\n\n---\nInviato dal modulo contatti di %s",
		$name,
		$email,
		$prefix,
		$phone,
		'' !== $service ? $service : '(non indicato)',
		$message,
		home_url( '/' )
	);

	$sent = wp_mail(
		humza_forms_destination(),
		sprintf( 'Richiesta dal sito: %s', $name ),
		$body,
		array( 'Reply-To: ' . $name . ' <' . $email . '>' ),
		$attachments
	);

	// Gli allegati stanno in una cartella temporanea: vanno rimossi comunque.
	foreach ( $attachments as $file ) {
		if ( file_exists( $file ) ) {
			wp_delete_file( $file );
		}
	}

	if ( $sent ) {
		wp_send_json_success( array( 'message' => __( 'Messaggio inviato. Ti rispondiamo il prima possibile.', 'hamza-theme' ) ) );
	}

	wp_send_json_error( array( 'message' => __( 'Non siamo riusciti a inviare il messaggio. Scrivici su WhatsApp o chiamaci.', 'hamza-theme' ) ) );
}

/**
 * Salva gli allegati ammessi in una cartella temporanea.
 *
 * Il gestore precedente accettava qualunque tipo consentito da WordPress:
 * qui l'elenco è ristretto ai formati che servono davvero e si controlla
 * il contenuto del file, non la sola estensione.
 *
 * @return array<int,string>|WP_Error Percorsi dei file, oppure errore.
 */
function humza_forms_collect_attachments() {
	$out = array();
	if ( empty( $_FILES['hamza_files'] ) || ! is_array( $_FILES['hamza_files']['name'] ) ) {
		return $out;
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';

	$allowed  = array( 'pdf', 'jpg', 'jpeg', 'png', 'webp', 'doc', 'docx' );
	$max_size = 10 * MB_IN_BYTES;
	$files    = $_FILES['hamza_files']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- validati sotto.
	$count    = min( count( $files['name'] ), 5 );

	for ( $i = 0; $i < $count; $i++ ) {
		if ( UPLOAD_ERR_NO_FILE === (int) $files['error'][ $i ] ) {
			continue;
		}
		if ( UPLOAD_ERR_OK !== (int) $files['error'][ $i ] ) {
			return new WP_Error( 'upload', __( 'Uno degli allegati non è stato caricato correttamente.', 'hamza-theme' ) );
		}
		if ( (int) $files['size'][ $i ] > $max_size ) {
			return new WP_Error( 'size', __( 'Ogni allegato deve pesare meno di 10 MB.', 'hamza-theme' ) );
		}

		$name = sanitize_file_name( $files['name'][ $i ] );
		$ext  = strtolower( (string) pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, $allowed, true ) ) {
			return new WP_Error( 'type', __( 'Allegati ammessi: PDF, JPG, PNG, WEBP, DOC, DOCX.', 'hamza-theme' ) );
		}

		$check = wp_check_filetype_and_ext( $files['tmp_name'][ $i ], $name );
		if ( empty( $check['type'] ) ) {
			return new WP_Error( 'type', __( 'Uno degli allegati non è un file valido.', 'hamza-theme' ) );
		}

		$upload = wp_handle_upload(
			array(
				'name'     => $name,
				'type'     => $check['type'],
				'tmp_name' => $files['tmp_name'][ $i ],
				'error'    => $files['error'][ $i ],
				'size'     => $files['size'][ $i ],
			),
			array(
				'test_form' => false,
				'mimes'     => array(
					'pdf'      => 'application/pdf',
					'jpg|jpeg' => 'image/jpeg',
					'png'      => 'image/png',
					'webp'     => 'image/webp',
					'doc'      => 'application/msword',
					'docx'     => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				),
			)
		);

		if ( isset( $upload['error'] ) ) {
			return new WP_Error( 'upload', __( 'Allegato non accettato.', 'hamza-theme' ) );
		}
		if ( ! empty( $upload['file'] ) ) {
			$out[] = $upload['file'];
		}
	}

	return $out;
}

/* -------------------------------------------------------------------------
 * Accesso, registrazione, pratiche e documenti NON sono gestiti qui.
 *
 * Se ne occupa il plugin "hamza-client-portal" (Portal_Auth e shortcode
 * [hamza_portal]), già attivo sul sito: duplicare quei gestori produrrebbe
 * due risposte per la stessa richiesta. Il template dell'area clienti si
 * limita a ospitare lo shortcode del plugin.
 * ---------------------------------------------------------------------- */
