<?php
/**
 * Plugin Name: Humza Multiservizi — Moduli del sito
 * Description: Gestori dei moduli (contatti, accesso, registrazione) indipendenti dal tema. Prima vivevano dentro il tema: al cambio tema i moduli smettevano di funzionare.
 * Version: 1.0.0
 * Author: Humza Multiservizi
 *
 * @package humza-forms
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * Utilità comuni
 * ---------------------------------------------------------------------- */

/**
 * Limite di invii per indirizzo IP, per non lasciare i moduli aperti ai bot.
 *
 * @param string $key   Nome del contatore (es. 'contact').
 * @param int    $max   Invii consentiti nella finestra.
 * @param int    $secs  Ampiezza della finestra in secondi.
 * @return bool True se la richiesta è entro il limite.
 */
function humza_forms_rate_ok( $key, $max = 5, $secs = 900 ) {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'sconosciuto';
	$id = 'humza_rl_' . $key . '_' . md5( $ip );
	$n  = (int) get_transient( $id );
	if ( $n >= $max ) {
		return false;
	}
	set_transient( $id, $n + 1, $secs );
	return true;
}

/**
 * Indirizzo a cui recapitare i moduli: quello configurato nel tema, con
 * ripiego sull'email amministratore.
 *
 * @return string
 */
function humza_forms_destination() {
	$email = function_exists( 'humza_biz' ) ? humza_biz( 'email' ) : '';
	if ( ! is_email( $email ) ) {
		$email = get_option( 'admin_email' );
	}
	return $email;
}

/**
 * Mittente sul dominio del sito: le email inviate con un mittente Gmail
 * falso finiscono quasi sempre nello spam.
 */
add_filter( 'wp_mail_from', function ( $from ) {
	$host = wp_parse_url( home_url(), PHP_URL_HOST );
	$host = preg_replace( '/^www\./', '', (string) $host );
	return $host ? 'no-reply@' . $host : $from;
} );

add_filter( 'wp_mail_from_name', function () {
	return function_exists( 'humza_biz' ) ? humza_biz( 'name' ) : get_bloginfo( 'name' );
} );

/* -------------------------------------------------------------------------
 * 1) Modulo contatti
 * ---------------------------------------------------------------------- */

add_action( 'wp_ajax_hamza_contact_form', 'humza_handle_contact_form' );
add_action( 'wp_ajax_nopriv_hamza_contact_form', 'humza_handle_contact_form' );

/**
 * Riceve il modulo contatti e inoltra il messaggio all'ufficio.
 */
function humza_handle_contact_form() {
	check_ajax_referer( 'hamza_contact_form', 'hamza_contact_nonce' );

	// Campo trappola: compilato solo dai bot.
	if ( ! empty( $_POST['hamza_website'] ) ) {
		wp_send_json_error( array( 'message' => __( 'Richiesta non valida.', 'hamza-theme' ) ) );
	}

	if ( ! humza_forms_rate_ok( 'contact', 5, 900 ) ) {
		wp_send_json_error( array( 'message' => __( 'Hai già inviato più messaggi. Riprova tra un quarto d’ora oppure scrivici su WhatsApp.', 'hamza-theme' ) ) );
	}

	$name    = sanitize_text_field( wp_unslash( $_POST['hamza_name'] ?? '' ) );
	$email   = sanitize_email( wp_unslash( $_POST['hamza_email'] ?? '' ) );
	$prefix  = sanitize_text_field( wp_unslash( $_POST['hamza_phone_prefix'] ?? '' ) );
	$phone   = sanitize_text_field( wp_unslash( $_POST['hamza_phone'] ?? '' ) );
	$service = sanitize_text_field( wp_unslash( $_POST['hamza_service'] ?? '' ) );
	$message = sanitize_textarea_field( wp_unslash( $_POST['hamza_message'] ?? '' ) );

	if ( '' === $name || ! is_email( $email ) || '' === $message ) {
		wp_send_json_error( array( 'message' => __( 'Compila nome, email e messaggio.', 'hamza-theme' ) ) );
	}

	// Limiti difensivi: il modulo è pubblico.
	$name    = mb_substr( $name, 0, 120 );
	$message = mb_substr( $message, 0, 5000 );

	$attachments = humza_forms_collect_attachments();
	if ( is_wp_error( $attachments ) ) {
		wp_send_json_error( array( 'message' => $attachments->get_error_message() ) );
	}

	$body = sprintf(
		"Nome: %s\nEmail: %s\nTelefono: %s %s\nServizio: %s\n\nMessaggio:\n%s\n\n---\nInviato dal modulo contatti di %s",
		$name,
		$email,
		$prefix,
		$phone,
		'' !== $service ? $service : '(non indicato)',
		$message,
		home_url( '/' )
	);

	$sent = wp_mail(
		humza_forms_destination(),
		sprintf( 'Richiesta dal sito: %s', $name ),
		$body,
		array( 'Reply-To: ' . $name . ' <' . $email . '>' ),
		$attachments
	);

	// Gli allegati vivono in una cartella temporanea: vanno rimossi comunque.
	foreach ( $attachments as $file ) {
		if ( file_exists( $file ) ) {
			wp_delete_file( $file );
		}
	}

	if ( $sent ) {
		wp_send_json_success( array( 'message' => __( 'Messaggio inviato. Ti rispondiamo il prima possibile.', 'hamza-theme' ) ) );
	}

	wp_send_json_error( array( 'message' => __( 'Non siamo riusciti a inviare il messaggio. Scrivici su WhatsApp o chiamaci.', 'hamza-theme' ) ) );
}

/**
 * Salva gli allegati ammessi in una cartella temporanea.
 *
 * Il gestore precedente accettava qualunque tipo consentito da WordPress:
 * qui l'elenco è ristretto ai formati che servono davvero.
 *
 * @return array<int,string>|WP_Error Percorsi dei file, o errore.
 */
function humza_forms_collect_attachments() {
	$out = array();
	if ( empty( $_FILES['hamza_files'] ) || ! is_array( $_FILES['hamza_files']['name'] ) ) {
		return $out;
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';

	$allowed  = array( 'pdf', 'jpg', 'jpeg', 'png', 'webp', 'doc', 'docx' );
	$max_size = 10 * MB_IN_BYTES;
	$files    = $_FILES['hamza_files']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- validati sotto.
	$count    = min( count( $files['name'] ), 5 );

	for ( $i = 0; $i < $count; $i++ ) {
		if ( UPLOAD_ERR_NO_FILE === (int) $files['error'][ $i ] ) {
			continue;
		}
		if ( UPLOAD_ERR_OK !== (int) $files['error'][ $i ] ) {
			return new WP_Error( 'upload', __( 'Uno degli allegati non è stato caricato correttamente.', 'hamza-theme' ) );
		}
		if ( (int) $files['size'][ $i ] > $max_size ) {
			return new WP_Error( 'size', __( 'Ogni allegato deve pesare meno di 10 MB.', 'hamza-theme' ) );
		}

		$name = sanitize_file_name( $files['name'][ $i ] );
		$ext  = strtolower( (string) pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, $allowed, true ) ) {
			return new WP_Error( 'type', __( 'Allegati ammessi: PDF, JPG, PNG, WEBP, DOC, DOCX.', 'hamza-theme' ) );
		}

		// Controllo del contenuto reale, non della sola estensione.
		$check = wp_check_filetype_and_ext( $files['tmp_name'][ $i ], $name );
		if ( empty( $check['type'] ) ) {
			return new WP_Error( 'type', __( 'Uno degli allegati non è un file valido.', 'hamza-theme' ) );
		}

		$upload = wp_handle_upload(
			array(
				'name'     => $name,
				'type'     => $check['type'],
				'tmp_name' => $files['tmp_name'][ $i ],
				'error'    => $files['error'][ $i ],
				'size'     => $files['size'][ $i ],
			),
			array(
				'test_form' => false,
				'mimes'     => array(
					'pdf'          => 'application/pdf',
					'jpg|jpeg'     => 'image/jpeg',
					'png'          => 'image/png',
					'webp'         => 'image/webp',
					'doc'          => 'application/msword',
					'docx'         => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				),
			)
		);

		if ( isset( $upload['error'] ) ) {
			return new WP_Error( 'upload', __( 'Allegato non accettato.', 'hamza-theme' ) );
		}
		if ( ! empty( $upload['file'] ) ) {
			$out[] = $upload['file'];
		}
	}

	return $out;
}

/* -------------------------------------------------------------------------
 * 2) Accesso all'area clienti
 * ---------------------------------------------------------------------- */

add_action( 'wp_ajax_nopriv_hamza_ajax_login', 'humza_handle_ajax_login' );
add_action( 'wp_ajax_hamza_ajax_login', 'humza_handle_ajax_login' );

/**
 * Accesso via AJAX dal modulo dell'area clienti.
 */
function humza_handle_ajax_login() {
	check_ajax_referer( 'hamza_ajax_login', 'hamza_login_nonce' );

	if ( is_user_logged_in() ) {
		wp_send_json_success( array( 'redirect' => home_url( '/area-clienti/' ) ) );
	}

	if ( ! humza_forms_rate_ok( 'login', 10, 900 ) ) {
		wp_send_json_error( array( 'message' => __( 'Troppi tentativi di accesso. Riprova tra un quarto d’ora.', 'hamza-theme' ) ) );
	}

	$username = sanitize_user( wp_unslash( $_POST['log'] ?? '' ) );
	$password = (string) ( $_POST['pwd'] ?? '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- la password non va alterata.

	if ( '' === $username || '' === $password ) {
		wp_send_json_error( array( 'message' => __( 'Inserisci email e password.', 'hamza-theme' ) ) );
	}

	$user = wp_signon(
		array(
			'user_login'    => $username,
			'user_password' => $password,
			'remember'      => ! empty( $_POST['rememberme'] ),
		),
		is_ssl()
	);

	if ( is_wp_error( $user ) ) {
		// Messaggio unico: non rivelare se l'utenza esiste.
		wp_send_json_error( array( 'message' => __( 'Email o password non corretti.', 'hamza-theme' ) ) );
	}

	wp_send_json_success(
		array(
			'message'  => __( 'Accesso effettuato.', 'hamza-theme' ),
			'redirect' => home_url( '/area-clienti/' ),
		)
	);
}

/* -------------------------------------------------------------------------
 * 3) Registrazione
 * ---------------------------------------------------------------------- */

add_action( 'wp_ajax_nopriv_hamza_register', 'humza_handle_register' );

/**
 * Crea un profilo cliente. Prima non esisteva alcun gestore: il modulo
 * di registrazione inviava a vuoto.
 */
function humza_handle_register() {
	check_ajax_referer( 'hamza_register', 'hamza_register_nonce' );

	if ( ! empty( $_POST['hamza_website'] ) ) {
		wp_send_json_error( array( 'message' => __( 'Richiesta non valida.', 'hamza-theme' ) ) );
	}

	if ( ! get_option( 'users_can_register' ) ) {
		wp_send_json_error(
			array(
				'message' => __( 'La registrazione online è chiusa. Scrivici su WhatsApp: creiamo noi il tuo profilo.', 'hamza-theme' ),
			)
		);
	}

	if ( ! humza_forms_rate_ok( 'register', 3, 3600 ) ) {
		wp_send_json_error( array( 'message' => __( 'Troppe registrazioni da questo dispositivo. Riprova più tardi.', 'hamza-theme' ) ) );
	}

	$name  = sanitize_text_field( wp_unslash( $_POST['hamza_reg_name'] ?? '' ) );
	$email = sanitize_email( wp_unslash( $_POST['hamza_reg_email'] ?? '' ) );
	$phone = sanitize_text_field( wp_unslash( $_POST['hamza_reg_phone'] ?? '' ) );

	if ( '' === $name || ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => __( 'Inserisci nome ed email validi.', 'hamza-theme' ) ) );
	}
	if ( email_exists( $email ) ) {
		wp_send_json_error( array( 'message' => __( 'Esiste già un profilo con questa email. Prova ad accedere o a recuperare la password.', 'hamza-theme' ) ) );
	}

	$user_id = wp_insert_user(
		array(
			'user_login'   => sanitize_user( current( explode( '@', $email ) ) . '_' . wp_generate_password( 4, false ), true ),
			'user_email'   => $email,
			'user_pass'    => wp_generate_password( 16 ),
			'display_name' => mb_substr( $name, 0, 80 ),
			'first_name'   => mb_substr( $name, 0, 80 ),
			'role'         => 'subscriber',
		)
	);

	if ( is_wp_error( $user_id ) ) {
		wp_send_json_error( array( 'message' => __( 'Non è stato possibile creare il profilo. Scrivici su WhatsApp.', 'hamza-theme' ) ) );
	}

	if ( '' !== $phone ) {
		update_user_meta( $user_id, 'humza_phone', $phone );
	}

	// L'utente imposta la password dal link ricevuto via email.
	wp_new_user_notification( $user_id, null, 'user' );

	wp_send_json_success(
		array(
			'message' => __( 'Profilo creato. Ti abbiamo inviato un’email per scegliere la password: controlla anche la posta indesiderata.', 'hamza-theme' ),
		)
	);
}

/* -------------------------------------------------------------------------
 * 4) Accesso fallito: ritorno alla pagina Area Clienti
 * ---------------------------------------------------------------------- */

add_action( 'wp_login_failed', function () {
	$referrer = wp_get_referer();
	$target   = home_url( '/area-clienti/' );

	if ( $referrer && false !== strpos( $referrer, 'area-clienti' ) ) {
		wp_safe_redirect( add_query_arg( 'login', 'failed', $target ) );
		exit;
	}
} );

add_filter( 'authenticate', function ( $user, $username, $password ) {
	if ( '' === $username || '' === $password ) {
		$referrer = wp_get_referer();
		if ( $referrer && false !== strpos( $referrer, 'area-clienti' ) ) {
			wp_safe_redirect( add_query_arg( 'login', 'failed', home_url( '/area-clienti/' ) ) );
			exit;
		}
	}
	return $user;
}, 30, 3 );
